package com.businessApp.controller;


import java.util.List;

import org.json.JSONException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.businessApp.bean.ResponseBean;
import com.businessApp.constants.StatusConstants;
import com.businessApp.model.AppointmentCalendar;
import com.businessApp.service.AndroidPushNotificationsService;


@RestController
public class FcmController {
	
	@Autowired
	AndroidPushNotificationsService androidService;
	@Autowired
	ApplicationContext applicationContext;
	
	
	String userDeviceIdKey=  "entrBcM0lnY:APA91bFg4NVlnECHUY4_qhfHG15GwR5yFNPHsh8A8GC62qaV8UxBmqbbotPvY_RLoat4dR7IFpY2liMT3B97aeJZOZKU7LX6whxCxsRpCZzJxgn-G9pOVFO6j8z7IuFh45dBgd8G4uDh";
                              
	private final String str = "sfdgddgdste fgdgsdf dfgdgfsdg kfdsg tkgfdk ckvbdkg sdkkkgsfd gkdfsgkd gkdfkgdgk dgksgksdg";
	
	@RequestMapping(value = "/send", method = RequestMethod.GET, produces = "application/json")
	public ResponseBean send() throws JSONException
	{
		ResponseBean respBean = this.applicationContext
				.getBean(ResponseBean.class);
		
		try
		{
			//androidService.sendAppointmentNotification(userDeviceIdKey,str);
		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}
	
	


	
	
	
	
	
	
//	HttpClient client = HttpClientBuilder.create().build();
//	HttpPost post = new HttpPost("https://fcm.googleapis.com/fcm/send");
//	
//	
//	//post.setHeader("Content-type", "application/json");
//	//post.setHeader("Authorization", "key=AIzaSyBSxxxxsXevRq0trDbA9mhnY_2jqMoeChA");
//
//	JSONObject message = new JSONObject();
//	message.put("to", "dBbB2BFT-VY:APA91bHrvgfXbZa-K5eg9vVdUkIsHbMxxxxxc8dBAvoH_3ZtaahVVeMXP7Bm0iera5s37ChHmAVh29P8aAVa8HF0I0goZKPYdGT6lNl4MXN0na7xbmvF25c4ZLl0JkCDm_saXb51Vrte");
//	message.put("priority", "high");
//
//	JSONObject notification = new JSONObject();
//	notification.put("title", "Java");
//	notification.put("body", "Notificação do Java");
//
//	message.put("notification", notification);
//
//	post.setEntity(new StringEntity(message.toString(), "UTF-8"));
//	HttpResponse response = client.execute(post);
//	System.out.println(response);
//	System.out.println(message);
	

}

package com.businessApp.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.MediaType;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.businessApp.bean.ResponseBean;
import com.businessApp.constants.StatusConstants;
import com.businessApp.model.Business;
import com.businessApp.service.BusinessService;

@RestController
@RequestMapping("/business")
public class BusinessController
{
	private static Logger logger = LoggerFactory.getLogger(BusinessController.class);

	@Value("${upload.business.folderPath}")
	private String  dir = "C:/Users/user/Desktop/BusinessMiniatures_1.1-master/bin/src/main/uploads";

	String url = "localhost:27017/BusinessMiniatures/business/geticon/";

	@Autowired
	BusinessService businessService;

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	ServletContext context;

	@Autowired
	MongoTemplate template;

	@Autowired
	private Environment env;

	/**
	 * To Create the Business
	 * 
	 * @param business
	 * @return To get the message like "Business has been successfully Created"
	 */
	@RequestMapping(value = "/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean saveBusiness(@RequestBody Business business)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (business.getCreatedTime() == null)
			{
				Date date = new Date();
				business.setCreatedTime(date);
				business.setModifiedTime(date);
				business.setIcon("");
			}

			this.businessService.save(business);

			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage("Business has been successfully Created");
			respBean.setResult(null);

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To Update the Business data based on given Business Object
	 * 
	 * @param business
	 * @return To get the message like "Business has been successfully updated"
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean updateBusiness(@RequestBody Business business)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			if (business.getModifiedTime() == null)
			{
				Date dt = new java.util.Date();
				business.setModifiedTime(dt);
			}

			String report = this.businessService.update(business);

			if (report.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Business has been successfully updated");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Business has not been  updated !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To get the list of all Template Business
	 * 
	 * @return To get the list of all Business
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean list()
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			List<Business> business = this.businessService.businessList();

			if ((business != null) && !(business).isEmpty())
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(business);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No Business data found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To get the Business data based on TemplatebusinessId
	 * 
	 * @param businessId
	 * @return To get the Business data based on businessId
	 */

	@RequestMapping(value = "/servicecategory/list/{businessId}", method = RequestMethod.GET,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean serviceCategorylist(@PathVariable("businessId") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			Object result = this.businessService.listServiceCategories(businessId);

			if (result != null)
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			e.printStackTrace();
		}
		return respBean;
	}

	@RequestMapping(value = "/servicecategory/{businessId}", method = RequestMethod.GET,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean serviceCategoryByBId(@PathVariable("businessId") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			List<Business> result = this.businessService.listServiceCategoriesByBId(businessId);

			if ((result != null) && !(result.isEmpty()))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "/allservicecategories", produces = "application/json")
	public ResponseBean allBusinessServiceCategories()
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			List<Business> result = this.businessService.allBusinessServiceCategories();

			if ((result != null) && !(result.isEmpty()))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;

	}

	@DeleteMapping(value = "/delete/{id}", produces = "application/json")
	public ResponseBean removeBusinessById(@PathVariable("id") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			String report = this.businessService.deleteBusinessById(businessId);

			if (report.equals("UNSUCCESS"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Business has not  been  deleted !");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Business has been successfully deleted ");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/iconsave", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = "application/json")

    public ResponseBean iconSave(@RequestParam("file") MultipartFile file, @RequestParam("id") String bId)
    {
        ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

        try
        {

            Business business = new Business();
            String path = null;

            String image = this.businessService.getIcon(bId);
            if (!(image.equals("")))
            {

                String ext = FilenameUtils.getExtension(image);

                String filePath = bId + "." + ext;

                File oldFile = new File(this.dir + File.separator + filePath);
                if (oldFile.delete())
                {
                    File f = new File(this.dir + File.separator + bId + "."
                            + FilenameUtils.getExtension(file.getOriginalFilename()));
                    file.transferTo(f);

                    path = this.url + bId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

                    business.setIcon(path);
                    business.setId(bId);
                }
            }

            else if ((image.equals("INVALID")))
            {

                respBean.setCode(StatusConstants.NOT_VALID);
                respBean.setMessage("Image has not been uploaded !");
                respBean.setResult(null);

            }
            else
            {

                File f = new File(
                        this.dir + File.separator + bId + "." + FilenameUtils.getExtension(file.getOriginalFilename()));
                file.transferTo(f);

                path = this.url + bId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

                business.setIcon(path);
                business.setId(bId);
            }
            String report = this.businessService.saveIcon(business);

            if (report.equals("UNSUCCESS"))
            {

                respBean.setCode(StatusConstants.NOT_VALID);
                respBean.setMessage("Image has not been uploaded !");
                respBean.setResult(null);

            }
            else
            {

                respBean.setCode(StatusConstants.SUCCESS_CODE);
                respBean.setMessage("Image has been successfully uploaded ");
                respBean.setResult(path);
            }

        }
        catch (Exception e)
        {
            respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
            respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
            respBean.setResult(null);
            e.printStackTrace();
        }
        return respBean;
    }

	@GetMapping(value = "geticon/{id}")
	public void getIcon(HttpServletRequest request, HttpServletResponse response, @PathVariable("id") String businessId)
	{

		try
		{

			String imagePath = this.businessService.getIcon(businessId);

			if (!(imagePath.equals("")))
			{
				String ext = FilenameUtils.getExtension(imagePath);

				String filePath = businessId + "." + ext;

				String path = this.dir + File.separator + filePath;
				File file = new File(path);

				if (file.exists())
				{

					String mimeType = URLConnection.guessContentTypeFromName(file.getName());
					if (mimeType == null)
					{

						mimeType = "application/octet-stream";
					}

					response.setContentType(mimeType);

					response.setHeader("Content-Disposition",
					        String.format("inline; filename=\"" + file.getName() + "\""));

					response.setContentLength((int) file.length());

					InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

					FileCopyUtils.copy(inputStream, response.getOutputStream());

				}
			}

		}
		catch (Exception e)
		{

			e.printStackTrace();
		}

	}

}


package com.businessApp.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.businessApp.bean.AppointmentBean;
import com.businessApp.bean.BusinessReport;
import com.businessApp.bean.ResponseBean;
import com.businessApp.constants.StatusConstants;
import com.businessApp.service.ReportsService;

@RestController
@RequestMapping("/admin")
public class ReportsController
{
	private static Logger logger = LoggerFactory.getLogger(ReportsController.class);

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	ReportsService reportsService;

	@PostMapping(value = "/reports", consumes = MediaType.APPLICATION_JSON_VALUE,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean adminReports(@RequestBody AppointmentBean appointmentBean)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		// Object
		// result=this.reportsService.consumersForEachPublisher(appointmentBean);
		Object result = null;

		try
		{
			if (appointmentBean.getReportId() == 2 || appointmentBean.getReportId() == 3)
			{
				if (appointmentBean.getTypeId() == 11 || appointmentBean.getTypeId() == 15
				        || appointmentBean.getTypeId() == 14)
				{
					result = this.reportsService.dateToDateReport(appointmentBean);

					if (result != "invalid")
					{
						List<Object> finalResult = new ArrayList<>();
						finalResult.add(result);

						respBean.setCode(StatusConstants.SUCCESS_CODE);
						respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
						respBean.setResult(finalResult);
					}
					else
					{
						respBean.setCode(StatusConstants.NOT_VALID);
						respBean.setMessage(StatusConstants.INVALID_DETAILS);
						respBean.setResult(null);
					}
				}
				else if (appointmentBean.getTypeId() == 12)
				{
					result = this.reportsService.weeklyReport(appointmentBean);

					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
					respBean.setResult(result);
				}
				else if (appointmentBean.getTypeId() == 13)
				{
					result = this.reportsService.monthlyReport(appointmentBean);

					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
					respBean.setResult(result);
				}
				else if (appointmentBean.getTypeId() == 10)
				{
					List<Object> finalResult = new ArrayList<>();
					result = this.reportsService.totalUsersCount(appointmentBean);
					finalResult.add(result);

					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
					respBean.setResult(finalResult);
				}
				else
				{
					respBean.setCode(StatusConstants.NOT_VALID);
					respBean.setMessage("Invalid type id!");
					respBean.setResult(null);
				}
			}
			else
			{
				result = "invalidReportId";

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid report id!");
				respBean.setResult(null);
			}
		}
		catch (Exception e)
		{
			respBean.setCode(500);
			respBean.setMessage("server busy!");
			respBean.setResult(null);
		}

		return respBean;
	}

	@PostMapping(value = "/reports/consumersOfEachPublisher", consumes = MediaType.APPLICATION_JSON_VALUE,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean consumersOfPublishers(@RequestBody AppointmentBean appointmentBean)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		Object result = this.reportsService.consumersForEachPublisher(appointmentBean);

		try
		{
			if (result.equals("noPublishers"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Sorry, no publishers!");
				respBean.setResult(null);
			}
			else if (result.equals("invalidType"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid type!");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}
		}
		catch (Exception e)
		{
			respBean.setCode(500);
			respBean.setMessage("server busy!");
			respBean.setResult(null);
		}

		return respBean;
	}

	@PostMapping(value = "reports/revenue", consumes = MediaType.APPLICATION_JSON_VALUE,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean revenueOfEachPublisher(@RequestBody AppointmentBean appointmentBean)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		Object result = this.reportsService.revenueOfPublishers(appointmentBean);

		try
		{
			if (result.equals("noPublishers"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Sorry, no publishers!");
				respBean.setResult(null);
			}
			else if (result.equals("invalidType"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid type!");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}
		}
		catch (Exception e)
		{
			respBean.setCode(500);
			respBean.setMessage("server busy!");
			respBean.setResult(null);
		}

		return respBean;
	}

	@PostMapping(value = "reports/businessenquiryreport", consumes = MediaType.APPLICATION_JSON_VALUE,
	        produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean businessEnquiryReport(@RequestBody BusinessReport businessReport)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			Object result = this.reportsService.getBusinessEnqiryReport(businessReport);

			if (result.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);
			}
			else if (result.equals("NO_BUSINESSES"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("No businesses found!");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}
		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);

			e.printStackTrace();
		}

		return respBean;
	}

}

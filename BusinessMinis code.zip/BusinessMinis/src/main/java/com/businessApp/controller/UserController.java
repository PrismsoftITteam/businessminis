package com.businessApp.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.MediaType;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.businessApp.bean.LoginResult;
import com.businessApp.bean.ResponseBean;
import com.businessApp.bean.SaveConsumerBusinessDetails;
import com.businessApp.bean.UserBean;
import com.businessApp.constants.StatusConstants;
import com.businessApp.model.ConsumerBusinessDetails;
import com.businessApp.model.Messages;
import com.businessApp.model.TrackReport;
import com.businessApp.model.User;
import com.businessApp.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController
{

	private static Logger logger = LoggerFactory.getLogger(UserController.class);

	@Value("${upload.user.folderPath}")
	private String dir;

	String url = "http://ec2-52-15-130-228.us-east-2.compute.amazonaws.com/BusinessMiniatures/user/geticon/";

	@Autowired
	UserService userService;

	@Autowired
	LoginResult loginResult;

	@Autowired
	UserBean userBean;

	@Autowired
	ApplicationContext applicationContext;
	@Autowired
	User user;
	@Autowired
	TrackReport trackReport;

	@Autowired
	MongoTemplate mongoTemplate;

	/**
	 * To Create New User
	 * 
	 * @param user
	 *            object
	 * 
	 * @return To get Message like "User has been successfully created"
	 */
	@PostMapping(path = "/create", consumes = "application/json")
	public ResponseBean saveUser(@RequestBody User user)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		int code = 200;
		Date dt = new Date();
		try
		{

			if ((user.getModifiedTime() == null) && (user.getCreatedTime() == null))
			{

				user.setModifiedTime(dt);
				user.setCreatedTime(dt);
				user.setIcon("");
			}

			// To save user
			Map<String, String> report = this.userService.toSaveUser(user);

			if (report.containsKey("id"))
			{

				this.userBean.setId(report.get("id"));
				this.userBean.setType(Integer.parseInt(report.get("type")));
			}

			if (report.containsKey("active"))
			{
				int result = Integer.parseInt(report.get("active"));

				if (result == 0)
				{
					code = 200;
					this.userBean.setOtp(report.get("otp"));
				}

				else if (result == 1)
				{
					code = 204;
				}

				else if (result == 2)
				{
					code = 209;
				}
			}

			if (report.containsKey("trackId"))
			{
				this.trackReport.setId(report.get("trackId"));
			}

			if (report.get("message").equalsIgnoreCase("INVALID_Email"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid mobile or email !");
				respBean.setResult(null);
			}

			else if (report.get("message").equalsIgnoreCase("INVALID_MOBILE"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid mobile or email !");
				respBean.setResult(null);
			}

			else if (report.get("message").equalsIgnoreCase("EmailOrPhoneRequired"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Mobile or email required !");
				respBean.setResult(null);
			}

			else if (report.get("message").equalsIgnoreCase("Email_Exist"))
			{

				respBean.setCode(code);
				respBean.setMessage("Email already exist !");
				respBean.setResult(this.userBean);

			}
			else if (report.get("message").equalsIgnoreCase("Phone_Exist"))
			{

				respBean.setCode(code);
				respBean.setMessage("Phone number already exist !");
				respBean.setResult(this.userBean);

			}

			else if (report.get("message").equalsIgnoreCase("SUCCESS"))
			{

				this.userBean.setOtp(report.get("otp"));

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("User has been successfully created");
				respBean.setResult(userBean);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		// Tracking Start
		this.trackReport.setResponce(respBean);
		this.userService.updateTrackReport(this.trackReport);
		// this.trackReport = null;
		// Tracking Close

		return respBean;
	}

	/**
	 * To get the list of publisher
	 * 
	 * @return List of All Users
	 */
	@GetMapping(path = "type/{usertype}", produces = "application/json")
	public ResponseBean list(@PathVariable("usertype") String type)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		Object report = null;
		try
		{

			report = this.userService.publisherList(type);

			if ((report != null))
			{

				if ((report.equals("INVALID_TYPE")))
				{
					respBean.setCode(StatusConstants.NOT_VALID);
					respBean.setMessage("Invalid user type !");
					respBean.setResult(report);
				}

				else
				{

					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
					respBean.setResult(report);
				}
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * User Login with his/him Credentials
	 * 
	 * @param user
	 * @return User data and his/him Business Data
	 */
	@PostMapping(path = "/login", consumes = "application/json", produces = "application/json")
	public ResponseBean logIn(@RequestBody UserBean user)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			int code = 200;
			String report = this.userService.loginUserWithId(user);

		if (report.equals("Success"))
			{
			
				respBean.setCode(code);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);

			
				//Object obj = null;


				respBean.setResult(user.getPhonenumber());

			HashMap<String, Object> resultData = new HashMap<>();
			 resultData.put("userData", this.loginResult.getUserData());

			 if ((this.loginResult.getBusinessData() != null)
				&& !(this.loginResult.getBusinessData().isEmpty()))
			 {
			 resultData.put("businessData",
			 this.loginResult.getBusinessData());
		 }
				
			 else
				 {
			 resultData.put("businessData", null);
				 }
				
				 if ((this.loginResult.getMenuData() != null)
				 && !(this.loginResult.getMenuData().isEmpty()))
				 {
				 resultData.put("menuData", this.loginResult.getMenuData());
				 }

				 else
				 {
				 resultData.put("menuData", null);
				 }

			}
		else if(report.equals("LOGIN FAILED"))
		{
			int code1=401;
			respBean.setCode(code1);
			respBean.setMessage(StatusConstants.INVALID_DETAILS);

		}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;

	}

	/**
	 * To get the User Data based on userId
	 * 
	 * @param userId
	 * @return User data of given userId
	 */
	@GetMapping(path = "/{id}", produces = "application/json")
	public ResponseBean getUserById(@PathVariable("id") String userId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			User user = this.userService.getUserByIdCustomized(userId);

			if (user != null)
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(user);
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Invalid user !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To Update User data
	 * 
	 * @param updateUser
	 * @return To get the Message like "User has been Successfully Updated "
	 */
	@PostMapping(path = "/update", consumes = "application/json")
	public ResponseBean updateUser(@RequestBody User updateUser)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (updateUser.getModifiedTime() == null)
			{
				updateUser.setModifiedTime(new java.util.Date());
			}

			Object report = this.userService.updateUser(updateUser);

			if (report != null)
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("User details has been successfully updated");
				respBean.setResult(null);

			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("User details not found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "/verifyotp", consumes = "application/json")
	public ResponseBean verifyOTP(@RequestBody User verifyOpt)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (verifyOpt.getModifiedTime() == null)
			{
				Date dt = new Date();
				verifyOpt.setModifiedTime(dt);
			}

			Object report = this.userService.verifyOTP(verifyOpt);

			if (report != null)
			{
				if (report.equals("INVALID"))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Invalid details !");
					respBean.setResult(null);
				}
				else if (report.equals("INVALID_OTP"))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Invalid OTP !");
					respBean.setResult(null);
				}
				else if (report.equals("UNABLE"))
				{
					respBean.setCode(StatusConstants.NOT_VALID);
					respBean.setMessage("Device limit is exceded for this plan !");
					respBean.setResult(null);
				}
				else
				{
					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage("Success");
					respBean.setResult(report);
				}

			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Invalid details !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	/**
	 * To delete the particular user based on userId
	 * 
	 * @param userId
	 * @return To get the message like "User has been successfully deleted"
	 */
	@DeleteMapping(value = "/delete/{id}", produces = "application/json")
	public ResponseBean deleteUserById(@PathVariable("id") String userId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			String report = this.userService.deleteUserById(userId);

			if ((report.equals("ID_REQ")))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);
			}
			if ((report.equals("INVALID")))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("No user found !");
				respBean.setResult(null);
			}

			else if ((report.equals("UNSUCCESS")))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("User has not been deleted");
				respBean.setResult(null);

			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("User has been successfully deleted");
				respBean.setResult(null);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/insert-consumer-device-id", consumes = "application/json")
	public ResponseBean saveConsumerDeviceId(@RequestBody ConsumerBusinessDetails consumerBusiness)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			Map<String, String> report = this.userService.insertConsumerDeviceId(consumerBusiness);

			if (report.containsKey("message"))
			{

				if ("DEVID_REQ".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.NO_CONTENT);
					respBean.setMessage("Consumer device MAC id required !");
					respBean.setResult(null);
				}

				else if ("EXIST".equals(report.get("message")))
				{
					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage("Consumer device Id exist");
					respBean.setResult(report.get("id"));
				}
				else
				{

					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage("Consumer device Id inserted");
					respBean.setResult(report.get("id"));

				}

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "/verify-device-id", consumes = "application/json")
	public ResponseBean verifyDeviceId(@RequestBody ConsumerBusinessDetails consumer)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			String report = this.userService.verifyDeviceId(consumer);

			if (report != null)
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Consumer device Id available");
				respBean.setResult(report);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Consumer device Id not available");
				respBean.setResult(report);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "/saveconsumerbusinessdetails", consumes = "application/json")
	public ResponseBean saveConsumerBusinessDetails(@RequestBody SaveConsumerBusinessDetails consumerBusiness)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (consumerBusiness.getModifiedTime() == null)
			{
				Date dt = new Date();
				consumerBusiness.setModifiedTime(dt);
			}

			Object report = this.userService.saveConsumerBusinessDetails(consumerBusiness);

			if (report.equals("SUCCESS"))
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Consumer business details added");
				respBean.setResult(null);

			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Invalid consumer details !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	@GetMapping(path = "/consumerbusinesslist/{id}", produces = "application/json")
	public ResponseBean consumerBusinessList(@PathVariable("id") String macId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		Object obj = null;
		try
		{

			obj = this.userService.consumerBusinessList(macId);

			if (obj.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Consumer business details");
				respBean.setResult(obj);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@GetMapping(path = "/countrieslist", produces = "application/json")
	public ResponseBean countriesList()
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage("Country  List");
			respBean.setResult(this.userService.countriesList());

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "iconsave", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = "application/json")

	public ResponseBean iconSave(@RequestParam("file") MultipartFile file, @RequestParam("id") String userId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			if (!file.isEmpty())
			{

				String path = null;

				String image = this.userService.getIcon(userId);

				if (!(image.equals("")))
				{

					String ext = FilenameUtils.getExtension(image);

					String filePath = userId + "." + ext;

					File oldFile = new File(this.dir + File.separator + filePath);

					if (oldFile.delete())
					{

						File f = new File(this.dir + File.separator + userId + "."
						        + FilenameUtils.getExtension(file.getOriginalFilename()));
						file.transferTo(f);

						path = this.url + userId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

						this.user.setIcon(path);
						this.user.setId(userId);
					}

				}

				else if ((image.equals("INVALID")))
				{

					respBean.setCode(StatusConstants.NOT_VALID);
					respBean.setMessage("Image has not been uploaded !");
					respBean.setResult(null);

				}

				else
				{

					File f = new File(this.dir + File.separator + userId + "."
					        + FilenameUtils.getExtension(file.getOriginalFilename()));
					file.transferTo(f);

					path = this.url + userId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

					this.user.setIcon(path);
					this.user.setId(userId);

				}

				String report = this.userService.saveIcon(user);

				if (report.equals("UNSUCCESS"))
				{

					respBean.setCode(StatusConstants.NOT_VALID);
					respBean.setMessage("Image has not been uploaded !");
					respBean.setResult(null);

				}
				else
				{

					respBean.setCode(StatusConstants.SUCCESS_CODE);
					respBean.setMessage("Image has been successfully uploaded");
					respBean.setResult(path);
				}
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Image reqiured !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "geticon/{id}")
	public void getIcon(HttpServletRequest request, HttpServletResponse response, @PathVariable("id") String userId)
	{

		try
		{

			String imagePath = this.userService.getIcon(userId);

			if (!(imagePath.equals("")))
			{
				String ext = FilenameUtils.getExtension(imagePath);

				// logger.info("exrtt ----" + ext);

				String filePath = userId + "." + ext;

				String path = this.dir + File.separator + filePath;
				File file = new File(path);

				if (file.exists())
				{

					String mimeType = URLConnection.guessContentTypeFromName(file.getName());
					if (mimeType == null)
					{

						mimeType = "application/octet-stream";
					}

					response.setContentType(mimeType);

					response.setHeader("Content-Disposition",
					        String.format("inline; filename=\"" + file.getName() + "\""));

					response.setContentLength((int) file.length());

					InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

					FileCopyUtils.copy(inputStream, response.getOutputStream());

				}
			}

		}
		catch (Exception e)
		{

			e.printStackTrace();
		}

	}

	@DeleteMapping(value = "/consumerbusiness/remove", produces = "application/json", consumes = "application/json")
	public ResponseBean removeConsumerBusiness(@RequestBody SaveConsumerBusinessDetails cBD)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			String report = this.userService.removeConsumerBusiness(cBD);

			if ((report.equals("INVALID")))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);

			}

			else if ((report.equals("UNSUCCESS")))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No data found !");
				respBean.setResult(null);

			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("consumer businessr has been successfully removed");
				respBean.setResult(null);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/available/", produces = "application/json", consumes = "application/json")

	public ResponseBean userAvailable(@RequestBody User user)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			boolean flag = this.userService.userAvailable(user);

			if (flag == true)
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("User available!");
				respBean.setResult(flag);
			}

			else
			{
				respBean.setCode(202);
				respBean.setMessage("User not available!");
				respBean.setResult(flag);

			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "/messages/", produces = "application/json", consumes = "application/json")
	public ResponseBean listOfMessagesByPId(@RequestBody User conId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			List<Messages> messageList = this.userService.listOfMessagesByConsumerId(conId.getId());

			if (messageList.size() != 0)
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(messageList);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Message list emply");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@DeleteMapping(value = "/messages/removenotification/{id}", produces = "application/json",
	        consumes = "application/json")
	public ResponseBean removeMessage(@PathVariable("id") String id)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			Object report = this.userService.removeMessage(id);

			if ((report.equals("INVALID")))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);
			}

			else if ((report.equals("UNSUCCESS")))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Notification not found !");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Notification been successfully removed");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/logout", produces = MediaType.APPLICATION_JSON_VALUE,
	        consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean logout(@RequestBody User logoutData)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			String report = this.userService.logoutFromDevice(logoutData);

			if (report.equals("INVALID") && report.equals("INVALID_TYPE"))

			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid data or user!");
				respBean.setResult(null);
			}
			else if (report.equals("INVALID_DEVICEID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid device!");
				respBean.setResult(null);
			}
			else if (report.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(null);
			}
		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	@PutMapping(path = "/updatepublishertoken", consumes = "application/json")
	public ResponseBean updatePublisherToken(@RequestBody User updateToken)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			String report = this.userService.updateToken(updateToken);

			if (report.equals("INVALID"))
			{

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);

			}
			else if (report.equals("INVALID_USER"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid user!");
				respBean.setResult(null);
			}
			else if (report.equals("INVALID_DEVICEID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid device!");
				respBean.setResult(null);
			}
			else if (report.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	@PostMapping(path = "/getPublisherToken", consumes = "application/json")
	public ResponseBean getPublisherToken(@RequestBody User getToken)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			HashMap<String, String> report = this.userService.getToken(getToken);

			if (report.get("response").equals("INVALID"))
			{

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);

			}
			else if (report.get("response").equals("INVALID_USER"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid user!");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(report);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

	// ------Not Used This Service ------

	@PutMapping(path = "/saveotpdetails", consumes = "application/json")
	public ResponseBean saveOTPDetails(@RequestBody User saveOTP)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (saveOTP.getModifiedTime() == null)
			{
				saveOTP.setModifiedTime(new java.util.Date());
			}

			Object report = this.userService.saveOTPDetails(saveOTP);

			if (report != null)
			{
			HashMap<String, Object> resultData = new HashMap<>();
				 resultData.put("userData", report);

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Publisher details has been Successfully  Updated");
				respBean.setResult(report);

			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Publisher details not found !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}
		return respBean;
	}

}

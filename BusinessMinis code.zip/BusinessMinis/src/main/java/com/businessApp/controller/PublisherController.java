package com.businessApp.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.http.MediaType;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.businessApp.bean.AppointmentBean;
import com.businessApp.bean.PublisherBusinessServices;
import com.businessApp.bean.QRCodeBean;
import com.businessApp.bean.ResponseBean;
import com.businessApp.bean.UpdatePBColor;
import com.businessApp.constants.StatusConstants;
import com.businessApp.model.BusinessBreakConfig;
import com.businessApp.model.Messages;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.model.RaiseRequest;
import com.businessApp.service.PublisherService;

@RestController
@RequestMapping("/publisher")
public class PublisherController
{

	private static Logger logger = LoggerFactory.getLogger(PublisherController.class);

	@Value("${upload.business.folderPath}")
	private String dir;

	// @Value("${upload.notification.folderPath}")
	// private String notificationDir;

	String notificationDir = "F:/workSpaceForJAVA/BusinessMiniatures/src/main/uploads";

	String url = "http://ec2-52-15-130-228.us-east-2.compute.amazonaws.com/BusinessMiniatures/publisher/geticon/";

	String notificationImageUrl = "http://ec2-52-15-130-228.us-east-2.compute.amazonaws.com/BusinessMiniatures/publisher/getnotificationicon/";

	@Autowired
	ApplicationContext applicationContext;

	@Autowired
	PublisherService publisherService;
	@Autowired
	Messages msg;

	/**
	 * To Save the Publisher Business
	 * 
	 * @param publBusiness
	 * @return To get the message like "Successfully Created Publisher Business"
	 */
	@RequestMapping(value = "/business/create", method = RequestMethod.POST,
	        produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean save(@RequestBody PublisherBusiness publBusiness)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			if (publBusiness.getCreatedTime() == null)
			{
				Date dt = new Date();
				publBusiness.setCreatedTime(dt);
				publBusiness.setUpdateTime(dt);
				publBusiness.setIcon("");

			}
			String report = this.publisherService.save(publBusiness);

			if (report.equals("UNSUCCESS"))

			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Publisher id  / Business id   invalid !");
				respBean.setResult(null);
			}
			else if (report.equals("NOTALLOWED"))
			{
				respBean.setCode(StatusConstants.REDIRECT);
				respBean.setMessage("Please upgade the your plan !");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(" Publisher business has been successfully created");
				respBean.setResult(report);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To add the service to the particular business and particular Service Category
	 * 
	 * @param addService
	 * @return To Get the message like " Service has been successfully added "
	 */

	@PostMapping(path = "/business/addservice", consumes = "application/json")
	public ResponseBean addService(@RequestBody PublisherBusinessServices addService)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			String report = this.publisherService.addServiceToPublisherBusiness(addService);

			if (report.equals("UnSuccess"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Service has not  been  added  !");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Service has been  successfully added ");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * To remove the service from the particular business and particular Service
	 * Category
	 * 
	 * @param removeService
	 * @return To get the message like "Service has not been removed !"
	 */
	@PostMapping(path = "/business/removeservice", consumes = "application/json")
	public ResponseBean removeService(@RequestBody PublisherBusinessServices removeService)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			String report = this.publisherService.removeServiceFromPublisherBusiness(removeService);

			if (report.equals("UnSuccess"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Service has not been  removed !");
				respBean.setResult(null);
			}

			if (report.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Publisher business not found !");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(" Service has been successfully removed !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}

		return respBean;
	}

	/**
	 * To get the Publisher Businesses Based on publisherId for Consumer App
	 * 
	 * @param publisherId
	 * @return List Of Publisher Businesses
	 */
	@GetMapping(value = "/business/consumerwise/{id}", produces = "application/json")
	public ResponseBean businessListById(@PathVariable("id") String pbId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		Object result = null;

		try
		{

			result = this.publisherService.pBusinessConsumerwiseBypbId(pbId);

			if ((result.equals("NOEMP")))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No employee available in this business !");
				respBean.setResult(null);
			}

			else if ((result.equals("INVALID")))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "/businessdata/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseBean getPubBusinessDatabyPuubBusinessId(@PathVariable("id") String id)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			Object result = this.publisherService.publisherBusinessByBId(id);

			if (result != null)
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}

			else
			{

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid business Id!");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * Delete the Publisher Business Based on PublisherId
	 * 
	 * @param businessId
	 * @return To get the message like "Publisher Business has been Successfully
	 *         Deleted "
	 */
	@DeleteMapping(value = "/business/delete/{id}", produces = "application/json")
	public ResponseBean deletePbBusinessById(@PathVariable("id") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			String report = this.publisherService.deletePbBusinessById(businessId);

			if (report.equals("UNSUCCESS"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Publisher business has not  been  deleted !");
				respBean.setResult(null);
			}

			else if (report.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Publisher business  not  found !");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Publisher business has been successfully deleted ");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * To update the publisher Business based on given Publisher business object
	 * 
	 * @param updatePublBusiness
	 * @return To get the message like "Publisher Business has been Successfully
	 *         Updated "
	 */
	@PutMapping(value = "/business/update", produces = "application/json", consumes = "application/json")
	public ResponseBean updatePubisherBusiness(@RequestBody PublisherBusiness updatePublBusiness)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (updatePublBusiness.getUpdateTime() == null)
			{
				Date dt = new java.util.Date();
				updatePublBusiness.setUpdateTime(dt);
			}

			String reoprt = this.publisherService.updatePublisherBusiness(updatePublBusiness);

			if (reoprt.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Pubilsher Business has been successfully updated");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Pubilsher Business  has not been  updated !");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;
	}

	/**
	 * To Get List Of Business Based AdminBusinessId
	 * 
	 * @param businessId
	 * @return
	 */
	@GetMapping(value = "/publisherbusiness/list/{id}", produces = "application/json")
	public ResponseBean publisherBusinessListByBId(@PathVariable("id") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			List<Object> result = this.publisherService.publisherBusinessListByAdminBId(businessId);

			if ((result != null) && !(result).isEmpty())
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("No publisher data found !");
				respBean.setResult(null);

			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * List Of Publisher Businesses Based on publisherId
	 * 
	 * @param publisherId
	 * @return List Of Publisher Businesses
	 */

	@GetMapping(value = "/business/list/{id}", produces = "application/json")
	public ResponseBean publisherBusinessByBId(@PathVariable("id") String publisherId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			List<Object> obj = this.publisherService.businessListBypublisherId(publisherId);

			// Object obj = this.publisherService
			// .publisherBusinessByBId(publisherId);

			if ((obj != null))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(obj);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);

			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	/**
	 * UpdatePubisherBusinessServiceCatColor
	 * 
	 * @param updatePublBusinessColor
	 * @return
	 */
	@PutMapping(value = "/business/updatecolor", produces = "application/json", consumes = "application/json")
	public ResponseBean updatePubisherBusinessServiceCatColor(@RequestBody UpdatePBColor updatePublBusinessColor)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			String reoprt = this.publisherService.updatePubisherBusinessServiceCatColor(updatePublBusinessColor);
			if (reoprt.equals("Success"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Colour has been updated successfully");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Colour has not been updated !");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;
	}

	/**
	 * To Save Code
	 * 
	 * @param qrb
	 * @return
	 */

	@PostMapping(path = "/business/qrcode", consumes = "application/json")

	public ResponseBean uploadFile(@RequestBody QRCodeBean qrb)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			this.publisherService.saveQRCode(qrb);
			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
			respBean.setResult(null);

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;

	}

	/**
	 * 
	 * To Get QRCode By Publisher BusinessId
	 * 
	 * @param businessId
	 * @return
	 */
	@GetMapping(value = "/business/qrcode/{id}", produces = "application/json")
	public ResponseBean publisherBusinessQRCode(@PathVariable("id") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
			respBean.setResult(this.publisherService.getpublisherBusinessQRCode(businessId));
		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/business/breakconfig", consumes = "application/json")
	public ResponseBean breakConfig(@RequestBody BusinessBreakConfig businesBreak)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			String report = this.publisherService.saveBreakConfig(businesBreak);

			if (report.equals("SUCCES"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Break config details has been successfully stored");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Break config details has not been  stored !");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;

	}

	@PutMapping(value = "/business/updatebreakconfig", produces = "application/json", consumes = "application/json")
	public ResponseBean updateBreakConfig(@RequestBody BusinessBreakConfig businesBreak)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			String reoprt = this.publisherService.updateBreakConfig(businesBreak);
			if (reoprt.equals("Success"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Break config details  has been updated successfully");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Break config details has not been updated !");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;
	}

	@GetMapping(value = "/business/getbreakconfig/{id}", produces = "application/json")
	public ResponseBean getBreakConfigDetails(@PathVariable("id") String businessId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			Object obj = this.publisherService.getBreakConfigDetails(businessId);

			if (obj != null)
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(obj);
			}
			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage(StatusConstants.UNSUCCESS_MESSAGE);
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PutMapping(value = "/business/updateservicecategories", produces = "application/json",
	        consumes = "application/json")
	public ResponseBean updateServicCategories(@RequestBody PublisherBusiness updatePublBusiness)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (updatePublBusiness.getUpdateTime() == null)
			{
				Date dt = new java.util.Date();
				updatePublBusiness.setUpdateTime(dt);
			}

			String reoprt = this.publisherService.updateServicCategories(updatePublBusiness);

			if (reoprt.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Services has been successfully updated ");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Services has not been updated ! ");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;
	}

	@PutMapping(value = "/business/updateparticularservice", produces = "application/json",
	        consumes = "application/json")
	public ResponseBean updateParticularService(@RequestBody PublisherBusinessServices updatePubService)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			String reoprt = this.publisherService.updateParticularService(updatePubService);

			if (reoprt.equals("SUCCESS"))
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Service has been successfully updated");
				respBean.setResult(null);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Service has not been  updated !");
				respBean.setResult(null);
			}

		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();

		}

		return respBean;
	}

	@PostMapping(path = "/iconsave", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = "application/json")

	public ResponseBean iconSave(@RequestParam("file") MultipartFile file, @RequestParam("id") String bId)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{

			PublisherBusiness pBusiness = new PublisherBusiness();
			String path = null;

			String image = this.publisherService.getIcon(bId);

			if (!(image.equals("")))
			{

				String ext = FilenameUtils.getExtension(image);

				String filePath = bId + "." + ext;

				File oldFile = new File(this.dir + File.separator + filePath);
				if (oldFile.delete())
				{

					File f = new File(this.dir + File.separator + bId + "."
					        + FilenameUtils.getExtension(file.getOriginalFilename()));
					file.transferTo(f);

					path = this.url + bId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

					pBusiness.setIcon(path);
					pBusiness.setId(bId);
				}
			}
			else if ((image.equals("INVALID")))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Image has not been uploaded !");
				respBean.setResult(null);
			}
			else
			{
				File f = new File(
				        this.dir + File.separator + bId + "." + FilenameUtils.getExtension(file.getOriginalFilename()));
				file.transferTo(f);

				path = this.url + bId + "." + FilenameUtils.getExtension(file.getOriginalFilename());

				pBusiness.setIcon(path);
				pBusiness.setId(bId);
			}

			String report = this.publisherService.saveIcon(pBusiness);

			if (report.equals("UNSUCCESS"))
			{

				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Image has not been uploaded !");
				respBean.setResult(null);

			}
			else
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Image has been successfully uploaded ");
				respBean.setResult(path);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "geticon/{id}")
	public void getIcon(HttpServletRequest request, HttpServletResponse response, @PathVariable("id") String businessId)
	{

		try
		{

			// logger.info("businessId" + businessId);
			String imagePath = this.publisherService.getIcon(businessId);

			if (!(imagePath.equals("")))
			{
				String ext = FilenameUtils.getExtension(imagePath);

				String filePath = businessId + "." + ext;

				String path = this.dir + File.separator + filePath;
				File file = new File(path);

				if (file.exists())
				{

					String mimeType = URLConnection.guessContentTypeFromName(file.getName());
					if (mimeType == null)
					{
						mimeType = "application/octet-stream";
					}

					response.setContentType(mimeType);

					response.setHeader("Content-Disposition",
					        String.format("inline; filename=\"" + file.getName() + "\""));

					response.setContentLength((int) file.length());

					InputStream inputStream = new BufferedInputStream(new FileInputStream(file));

					FileCopyUtils.copy(inputStream, response.getOutputStream());

				}
			}

		}
		catch (Exception e)
		{

			e.printStackTrace();
		}

	}

	@PostMapping(value = "reports", produces = "application/json", consumes = "application/json")
	public ResponseBean reports(@RequestBody AppointmentBean appointmentBean)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		List<Object> object = new ArrayList<>();
		String message = null;

		if (appointmentBean.getType().equalsIgnoreCase("daily"))
		{
			Object result = this.publisherService.getOnedayReport(appointmentBean);
			if (result == "holiday")
			{
				message = "Sorry, Today is holiday!";
				object = null;
			}
			else if (result == "invalid")
			{
				message = "Invalid business id!";
				object = null;
			}
			else if (result == "noService")
			{
				message = "No services in the business!";
				object = null;
			}
			else
			{
				message = StatusConstants.SUCCESS_MESSAGE;
				object.add(result);
			}
		}
		else if (appointmentBean.getType().equalsIgnoreCase("custom"))
		{
			Object result = this.publisherService.reportFromDateToDate(appointmentBean);
			if (result == "invalid")
			{
				message = "Invalid business id!";
				object = null;
			}
			else if (result == "noService")
			{
				message = "No services in the business!";
				object = null;
			}
			else
			{
				message = StatusConstants.SUCCESS_MESSAGE;
				object.add(result);
			}
		}
		else if (appointmentBean.getType().equalsIgnoreCase("weekly"))
		{
			Object result = this.publisherService.weeklyReportofPublisher(appointmentBean);

			if (result == null)
			{
				message = "Invalid business id!";
				object = null;
			}
			else if (result == "noService")
			{
				message = "No services in the business!";
				object = null;
			}
			else
			{
				message = StatusConstants.SUCCESS_MESSAGE;

				respBean.setCode(200);
				respBean.setMessage(message);
				respBean.setResult(result);

				return respBean;
			}
		}
		else if (appointmentBean.getType().equalsIgnoreCase("monthly"))
		{
			Object result = this.publisherService.monthlyReportofPublisher(appointmentBean);
			if (result == null)
			{
				message = "Invalid business id!";
				object = null;
			}
			else if (result == "noService")
			{
				message = "No services in the business!";
				object = null;
			}
			else
			{
				message = StatusConstants.SUCCESS_MESSAGE;

				respBean.setCode(200);
				respBean.setMessage(message);
				respBean.setResult(result);

				return respBean;
			}
		}
		else if (appointmentBean.getType().equals("yearly"))
		{
			Object year = this.publisherService.yearlyReportofPublisher(appointmentBean);
			if (year == "invalid")
			{
				message = "Invalid business id!";
				object = null;
			}
			else if (year == "noService")
			{
				message = "No services in the business!";
				object = null;
			}
			else
			{
				message = StatusConstants.SUCCESS_MESSAGE;
				object.add(year);
			}
		}

		try
		{
			respBean.setCode(200);
			respBean.setMessage(message);
			respBean.setResult(object);
		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/messages/", produces = "application/json", consumes = "application/json")
	public ResponseBean listOfMessagesByPId(@RequestBody PublisherBusiness messageOb)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			List<Messages> messageList = this.publisherService.listOfMessagesByPId(messageOb);

			if (messageList.size() != 0)
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(messageList);
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Message list emply");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@PostMapping(path = "/raise-request", produces = "application/json", consumes = "application/json")
	public ResponseBean raiseRequest(@RequestBody RaiseRequest raiseReq)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			if (raiseReq.getCreatedTime() == null)
			{
				Date dt = new Date();
				raiseReq.setCreatedTime(dt);
				raiseReq.setModifiedTime(dt);
			}

			Object result = this.publisherService.raiseRequest(raiseReq);

			if ("SUCCESS".equals(result))
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult("Raise request has been successfully sent");
			}

			else
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Raise request error");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "/raise-request/get", produces = "application/json")
	public ResponseBean getRaiseRequest()
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);

		try
		{
			respBean.setCode(StatusConstants.SUCCESS_CODE);
			respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
			respBean.setResult(this.publisherService.getRaiseRequest());
		}

		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	// @PostMapping(path = "/sendnotificationsallconsumers/", consumes =
	// MediaType.MULTIPART_FORM_DATA_VALUE,
	// produces = "application/json")

	// public ResponseBean sendNotificationsToAllConsumerOfBusiness(
	// @RequestParam(value = "file", required = false) MultipartFile file,
	// @RequestParam("uId") String uId,
	// @RequestParam("bId") String bId, @RequestParam("message") String message)

	@PostMapping(path = "/sendnotificationsallconsumers/", consumes = "application/json", produces = "application/json")

	public ResponseBean sendNotificationsToAllConsumerOfBusiness(@RequestBody Messages msg)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{

			// this.msg.setuId(uId);
			// this.msg.setbId(bId);
			// this.msg.setMessage(message);
			// String path;
			// ObjectId fId = new ObjectId();

			// if (!file.isEmpty())
			// {
			// File f = new File(this.notificationDir + File.separator + fId + "."
			// + FilenameUtils.getExtension(file.getOriginalFilename()));
			// file.transferTo(f);
			// path = this.notificationImageUrl + fId + "." +
			// FilenameUtils.getExtension(file.getOriginalFilename());
			// this.msg.setImage(path);
			//
			// }

			Object result = this.publisherService.sendNotificationsToAllConsumerOfBusiness(msg);

			if (result.equals("Fail"))
			{
				respBean.setCode(StatusConstants.NO_CONTENT);
				respBean.setMessage("Message has not been send !");
				respBean.setResult(null);

			}

			else
			{

				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage("Message has been successfully send");
				respBean.setResult(null);
			}

		}
		catch (Exception e)
		{

			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

	@GetMapping(value = "getnotificationicon/{id}")
	public void getNotificationIcon(HttpServletRequest request, HttpServletResponse response,
	        @PathVariable("id") String imageId)
	{

		try
		{

			// String imagePath;
			//
			// if (!(imageId.equals("")))
			// {
			//
			// String filePath = imageId + "." + ext;
			//
			// String path = this.notificationDir + File.separator + filePath;
			// File file = new File(path);
			//
			// if (file.exists())
			// {
			//
			// String mimeType = URLConnection.guessContentTypeFromName(file.getName());
			// if (mimeType == null)
			// {
			// mimeType = "application/octet-stream";
			// }
			//
			// response.setContentType(mimeType);
			//
			// response.setHeader("Content-Disposition",
			// String.format("inline; filename=\"" + file.getName() + "\""));
			//
			// response.setContentLength((int) file.length());
			//
			// InputStream inputStream = new BufferedInputStream(new FileInputStream(file));
			//
			// FileCopyUtils.copy(inputStream, response.getOutputStream());
			//
			// }
			// }

		}
		catch (Exception e)
		{

			e.printStackTrace();
		}

	}

	@PostMapping(value = "reports/servicebasedreport", produces = "application/json", consumes = "application/json")
	public ResponseBean getServiceBasedReport(@RequestBody AppointmentBean appointmentBean)
	{
		ResponseBean respBean = this.applicationContext.getBean(ResponseBean.class);
		try
		{
			Object result = this.publisherService.getServiceBasedRevenueReport(appointmentBean);

			if (result.equals("INVALID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage(StatusConstants.INVALID_DETAILS);
				respBean.setResult(null);
			}
			else if (result.equals("INVALID_BUSINESSID"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid Business Id!");
				respBean.setResult(null);
			}
			else if (result.equals("INVALID_TYPE"))
			{
				respBean.setCode(StatusConstants.NOT_VALID);
				respBean.setMessage("Invalid Type!");
				respBean.setResult(null);
			}
			else
			{
				respBean.setCode(StatusConstants.SUCCESS_CODE);
				respBean.setMessage(StatusConstants.SUCCESS_MESSAGE);
				respBean.setResult(result);
			}

		}
		catch (Exception e)
		{
			respBean.setCode(StatusConstants.INTERNAL_SERVER_ERROR);
			respBean.setMessage(StatusConstants.INTERNAL_SERVER_ERROR_MESSAGE);
			respBean.setResult(null);
			e.printStackTrace();
		}
		return respBean;
	}

}

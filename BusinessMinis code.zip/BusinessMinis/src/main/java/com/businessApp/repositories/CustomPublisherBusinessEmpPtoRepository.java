package com.businessApp.repositories;

import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface CustomPublisherBusinessEmpPtoRepository
{

}

package com.businessApp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.businessApp.model.RaiseRequest;

@Transactional
public interface RaiseRequestRepository extends MongoRepository<RaiseRequest, Long>
{

}

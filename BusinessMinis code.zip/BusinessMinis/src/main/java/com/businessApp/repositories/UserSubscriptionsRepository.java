package com.businessApp.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.businessApp.model.UserSubscriptions;

public interface UserSubscriptionsRepository extends MongoRepository<UserSubscriptions, Long> {

}

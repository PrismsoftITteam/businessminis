package com.businessApp.bean;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Component

@JsonInclude(Include.NON_EMPTY)
public class UserBean
{
	private String logInId;
	private String password;
    private String userType;
	private int type;
	private String id;
	private String otp;
	private String phonenumber;
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	
	
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getLogInId()
	{
		return this.logInId;
	}

	public void setLogInId(String logInId)
	{
		this.logInId = logInId;
	}

	public String getPassword()
	{
		return this.password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public int getType()
	{
		return this.type;
	}

	public void setType(int type)
	{
		this.type = type;
	}

	public String getId()
	{
		return this.id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getOtp()
	{
		return this.otp;
	}

	public void setOtp(String otp)
	{
		this.otp = otp;
	}

}

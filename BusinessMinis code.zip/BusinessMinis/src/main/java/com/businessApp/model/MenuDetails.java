package com.businessApp.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "menuDetails")
public class MenuDetails
{
	@Id
	private String id;
	private String menuName;
	private int status;
	private int order;
	private boolean menuAuthStatus;
	public String getId()
	{
		return this.id;
	}
	public int getOrder()
	{
		return this.order;
	}
	public void setOrder(int order)
	{
		this.order = order;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getMenuName()
	{
		return this.menuName;
	}
	public void setMenuName(String menuName)
	{
		this.menuName = menuName;
	}
	public int getStatus()
	{
		return this.status;
	}
	public void setStatus(int status)
	{
		this.status = status;
	}
	public boolean isMenuAuthStatus() {
		return menuAuthStatus;
	}
	public void setMenuAuthStatus(boolean menuAuthStatus) {
		this.menuAuthStatus = menuAuthStatus;
	}

}

package com.businessApp.model;

public class ConsumerRegisteredBusiness
{
	private String bId;

	public String getbId()
	{
		return this.bId;
	}

	public void setbId(String bId)
	{
		this.bId = bId;
	}

}

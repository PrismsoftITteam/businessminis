package com.businessApp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Document(collection = "user")
@Component
// @JsonInclude(Include.NON_EMPTY)
@JsonInclude(Include.NON_NULL)
public class User
{
	@Id
	private String id;
	private String name;
	private int type;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String country;
	private String zip;
	private String userId;
	private String phone;
	private String email;
	private String password;
	private String modifiedBy;
	private String icon;
	private String emailOTP;
	private String phoneOTP;
	private String otp;
	private String token;
	private int activation; // 0 -- user create 1--verify OTP 2-- plan chosen
	private boolean businessData;
	private int status;
	private String countryCode;
	private String deviceID;
	private String osType;
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date otpExpireTime, modifiedTime, createdTime;

	public String getCountryCode()
	{
		return countryCode;
	}

	public void setCountryCode(String countryCode)
	{
		this.countryCode = countryCode;
	}

	public int getStatus()
	{
		return this.status;
	}

	public void setStatus(int status)
	{
		this.status = status;
	}

	public String getIcon()
	{
		return this.icon;
	}

	public void setIcon(String icon)
	{
		this.icon = icon;
	}

	public Date getCreatedTime()
	{
		return this.createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public int getType()
	{
		return this.type;
	}

	public void setType(int type)
	{
		this.type = type;
	}

	public String getPassword()
	{
		return this.password;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public String getEmail()
	{
		return this.email;
	}

	public String getUserId()
	{
		return userId;
	}

	public void setUserId(String userId)
	{
		this.userId = userId;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getId()
	{
		return this.id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getName()
	{
		return this.name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getAddress1()
	{
		return this.address1;
	}

	public void setAddress1(String address1)
	{
		this.address1 = address1;
	}

	public String getAddress2()
	{
		return this.address2;
	}

	public void setAddress2(String address2)
	{
		this.address2 = address2;
	}

	public String getCity()
	{
		return this.city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public String getState()
	{
		return this.state;
	}

	public String getDeviceID()
	{
		return deviceID;
	}

	public void setDeviceID(String deviceID)
	{
		this.deviceID = deviceID;
	}

	public Date getOtpExpireTime()
	{
		return otpExpireTime;
	}

	public void setOtpExpireTime(Date otpExpireTime)
	{
		this.otpExpireTime = otpExpireTime;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public String getCountry()
	{
		return this.country;
	}

	public String getEmailOTP()
	{
		return this.emailOTP;
	}

	public boolean isBusinessData()
	{
		return this.businessData;
	}

	public void setBusinessData(boolean businessData)
	{
		this.businessData = businessData;
	}

	public void setEmailOTP(String emailOTP)
	{
		this.emailOTP = emailOTP;
	}

	public String getPhoneOTP()
	{
		return this.phoneOTP;
	}

	public void setPhoneOTP(String phoneOTP)
	{
		this.phoneOTP = phoneOTP;
	}

	public String getOtp()
	{
		return this.otp;
	}

	public void setOtp(String otp)
	{
		this.otp = otp;
	}

	public String getToken()
	{
		return this.token;
	}

	public void setToken(String token)
	{
		this.token = token;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public String getZip()
	{
		return this.zip;
	}

	public void setZip(String zip)
	{
		this.zip = zip;
	}

	public String getPhone()
	{
		return this.phone;
	}

	public void setPhone(String phone)
	{
		this.phone = phone;
	}

	public String getModifiedBy()
	{
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy)
	{
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedTime()
	{
		return this.modifiedTime;
	}

	public void setModifiedTime(Date modifiedTime)
	{
		this.modifiedTime = modifiedTime;
	}

	public int getActivation()
	{
		return this.activation;
	}

	public void setActivation(int activation)
	{
		this.activation = activation;
	}

	public String getOsType()
	{
		return osType;
	}

	public void setOsType(String osType)
	{
		this.osType = osType;
	}

}

package com.businessApp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;

@Document(collection = "track-report")
@Component
public class TrackReport
{
	@Id
	private String id;
	private String type;
	private Object request;
	private Object responce;
	private Object result;
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date createdTime;

	public TrackReport()
	{
		super();
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public Object getRequest()
	{
		return request;
	}

	public void setRequest(Object request)
	{
		this.request = request;
	}

	public Object getResponce()
	{
		return responce;
	}

	public void setResponce(Object responce)
	{
		this.responce = responce;
	}

	public Date getCreatedTime()
	{
		return createdTime;
	}

	public void setCreatedTime(Date createdTime)
	{
		this.createdTime = createdTime;
	}

	public Object getResult()
	{
		return result;
	}

	public void setResult(Object result)
	{
		this.result = result;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

}

package com.businessApp.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;
@Component
@Document(collection = "userSubDetails")
public class UserSubDetails {
	
	@Id
	private String id;
	private String userSubId;
	private String planId;
	private String pubId;
	private List<String> businesses;
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date planStartTime,planEndTime;
	
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPubId() {
		return pubId;
	}
	public void setPubId(String pubId) {
		this.pubId = pubId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserSubId() {
		return userSubId;
	}
	public void setUserSubId(String userSubId) {
		this.userSubId = userSubId;
	}
	public List<String> getBusinesses() {
		return businesses;
	}
	public void setBusinesses(List<String> businesses) {
		this.businesses = businesses;
	}
	public Date getPlanStartTime() {
		return planStartTime;
	}
	public void setPlanStartTime(Date planStartTime) {
		this.planStartTime = planStartTime;
	}
	public Date getPlanEndTime() {
		return planEndTime;
	}
	public void setPlanEndTime(Date planEndTime) {
		this.planEndTime = planEndTime;
	}

}

package com.businessApp.model;

public class States
{
	private String region;
	private String country;
	public String getRegion()
	{
		return this.region;
	}
	public void setRegion(String region)
	{
		this.region = region;
	}
	public String getCountry()
	{
		return this.country;
	}
	public void setCountry(String country)
	{
		this.country = country;
	}

}

package com.businessApp.model;

public class Currency
{
	private String symbol;
	private String name;
	private int decimal_digits;
	private String code;

	public String getSymbol()
	{
		return this.symbol;
	}
	public void setSymbol(String symbol)
	{
		this.symbol = symbol;
	}
	public String getName()
	{
		return this.name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public int getDecimal_digits()
	{
		return this.decimal_digits;
	}
	public void setDecimal_digits(int decimal_digits)
	{
		this.decimal_digits = decimal_digits;
	}
	public String getCode()
	{
		return this.code;
	}
	public void setCode(String code)
	{
		this.code = code;
	}
}

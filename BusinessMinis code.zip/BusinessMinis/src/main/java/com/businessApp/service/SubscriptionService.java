package com.businessApp.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.types.ObjectId;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.businessApp.bean.UserPlanConfiguration;
import com.businessApp.bean.UserSubscriptionBean;
import com.businessApp.model.MenuDetails;
import com.businessApp.model.PlansDetails;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.model.Subscription;
import com.businessApp.model.User;
import com.businessApp.model.UserSubDetails;
import com.businessApp.model.UserSubscriptions;
import com.mongodb.WriteResult;

@Service
public class SubscriptionService
{
	private static org.slf4j.Logger logger = LoggerFactory.getLogger(SubscriptionService.class);

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	UserSubDetails userSubDetails;

	@Autowired
	UserService userService;

	@Autowired
	User user;

	@Autowired
	UserSubscriptions userSubscription;
	@Autowired
	UserPlanConfiguration config;

	public void subscriptionSave(Subscription sub)
	{
		this.mongoTemplate.save(sub);

	}

	public void subscriptionSettingsSave(PlansDetails sub)
	{
		this.mongoTemplate.save(sub);

	}

	public List<PlansDetails> listSubscriptionDetails()
	{

		Query query = new Query();
		List<PlansDetails> planDetails = this.mongoTemplate.find(query, PlansDetails.class);

		return planDetails;

	}

	public Object listSubscriptionDetailsforNetFixUI()
	{
		Map<String, Object> result = new HashMap<>();
		List<Map<String, String>> planNames = new ArrayList<>();
		List<Map<String, Object>> planSettings = new ArrayList<>();

		List<PlansDetails> planDetails = listSubscriptionDetails();

		if (planDetails != null && planDetails.size() > 0)
		{

			// plan Name & id
			for (int a = 0; a < planDetails.size(); a++)
			{
				Map<String, String> temp = new HashMap<>();
				temp.put("title", planDetails.get(a).getType());
				temp.put("id", planDetails.get(a).getId());
				planNames.add(temp);
			}

			// price
			Map<String, Object> map2 = new HashMap<>();

			map2.put("title", "Price");

			Map<String, Object> temp2 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp2.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getPrice());
			}
			map2.put("data", temp2);

			planSettings.add(map2);

			// duration
			Map<String, Object> map3 = new HashMap<>();

			map3.put("title", "Duration");

			Map<String, Object> temp3 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp3.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getDuration());
			}
			map3.put("data", temp3);

			planSettings.add(map3);

			// businessCount
			Map<String, Object> map4 = new HashMap<>();

			map4.put("title", "Business Count");

			Map<String, Object> temp4 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp4.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getBusinessCount());
			}
			map4.put("data", temp4);

			planSettings.add(map4);

			// trailVersion
			Map<String, Object> map5 = new HashMap<>();

			map5.put("title", "Trail Version");

			Map<String, Object> temp5 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				Object ob;
				if (planDetails.get(a).getTrailVersion() == 0)
				{
					ob = "Yes";
					temp5.put(planDetails.get(a).getType().toLowerCase(), ob);

				}
				else
				{
					ob = "No";
					temp5.put(planDetails.get(a).getType().toLowerCase(), ob);
				}
				temp5.put(planDetails.get(a).getType().toLowerCase(),
				 planDetails.get(a).getTrailVersion());
			}
			map5.put("data", temp5);

			planSettings.add(map5);

			// supportDevices
			Map<String, Object> map6 = new HashMap<>();

			map6.put("title", "Support Devices");

			Map<String, Object> temp6 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp6.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getSupportDevices());
			}
			map6.put("data", temp6);

			planSettings.add(map6);

			// reports
			Map<String, Object> map7 = new HashMap<>();

			map7.put("title", "Reports");

			Map<String, Object> temp7 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp7.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getReports());
			}
			map7.put("data", temp7);

			planSettings.add(map7);

			// employeeManServices
			Map<String, Object> map8 = new HashMap<>();

			map8.put("title", "Employee Management Services");

			Map<String, Object> temp8 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				Object ob1;
				if (planDetails.get(a).getEmployeeManServices() == 0)
				{
					ob1 = "Yes";
					temp8.put(planDetails.get(a).getType().toLowerCase(), ob1);

				}
				else
				{
					ob1 = "No";
					temp8.put(planDetails.get(a).getType().toLowerCase(), ob1);
				}

				 temp8.put(planDetails.get(a).getType().toLowerCase(),
				 planDetails.get(a).getEmployeeManServices());
			}
			map8.put("data", temp8);

			planSettings.add(map8);

			// notifications
			Map<String, Object> map9 = new HashMap<>();

			map9.put("title", "Notifications");

			Map<String, Object> temp9 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp9.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getNotifications());
			}
			map9.put("data", temp9);

			planSettings.add(map9);

			// serviceAllowed
			Map<String, Object> map10 = new HashMap<>();

			map10.put("title", "Service Allowed");

			Map<String, Object> temp10 = new HashMap<>();
			for (int a = 0; a < planDetails.size(); a++)
			{
				temp10.put(planDetails.get(a).getType().toLowerCase(), planDetails.get(a).getServiceAllowed());
			}
			map10.put("data", temp10);

			planSettings.add(map10);

			result.put("planSettings", planSettings);
			result.put("planNames", planNames);

		}

		return result;

	}

	public String updateSubscriptionDetails(PlansDetails updateSub)
	{

		if (updateSub.getId() != null)
		{
			Query updQry = new Query(Criteria.where("id").is(updateSub.getId()));
			Update upd = new Update();

			if (updateSub.getType() != null)
			{
				upd.set("type", updateSub.getType());
			}

			if (updateSub.getTrailVersion() != 0)
			{
				upd.set("trailVersion", updateSub.getTrailVersion());
			}

			if (updateSub.getSupportDevices() != 0)
			{
				upd.set("supportDevices", updateSub.getSupportDevices());
			}

			if (updateSub.getReports() != 0)
			{
				upd.set("reports", updateSub.getReports());
			}

			if (updateSub.getEmployeeManServices() != 0)
			{
				upd.set("employeeManServices", updateSub.getEmployeeManServices());
			}

			if (updateSub.getNotifications() != 0)
			{
				upd.set("notifications", updateSub.getNotifications());
			}

			if (updateSub.getServiceAllowed() != 0)
			{
				upd.set("serviceAllowed", updateSub.getServiceAllowed());
			}

			if (updateSub.getPrice() != 0)
			{
				upd.set("price", updateSub.getPrice());
			}

			if (updateSub.getDuration() != null)
			{
				upd.set("duration", updateSub.getDuration());
			}

			if (updateSub.getBusinessCount() != 0)
			{
				upd.set("businessCount", updateSub.getBusinessCount());
			}

			upd.set("modifiedTime", new java.util.Date());

			WriteResult tmp = this.mongoTemplate.upsert(updQry, upd, PlansDetails.class);

			if (tmp.getN() > 0)
			{
				return "SUCCESS";
			}
			else
			{
				return "UNSUCCESS";
			}

		}

		return "UNSUCCESS";
	}

	public String deleteSubScriptionSettings(String subId)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(subId));
		PlansDetails deletedEmp = this.mongoTemplate.findAndRemove(query, PlansDetails.class);

		if (deletedEmp != null)
		{
			return "SUCCESS";
		}

		else
		{
			return "UNSUCCESS";
		}
	}

	public PlansDetails getSubscriptionDetails(String subId)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(subId));
		PlansDetails tmp = this.mongoTemplate.findOne(query, PlansDetails.class);

		if (tmp != null)
		{
			return tmp;
		}

		else
		{
			return null;
		}

	}

	public void menuItemSave(MenuDetails menu)
	{
		this.mongoTemplate.save(menu);
	}

	public List<MenuDetails> menuList()
	{
		Query query = new Query();
		Order order = new Order(Direction.ASC, "order");
		Sort sort = new Sort(order);
		query.with(sort);

		return this.mongoTemplate.find(query, MenuDetails.class);

	}

	public Object saveUserSubscription(UserPlanConfiguration userSub) throws Exception
	{
		if (userSub != null)
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("uId").is(userSub.getuId()));

			UserSubscriptions uSub = this.mongoTemplate.findOne(query, UserSubscriptions.class);

			Query query2 = new Query();
			query2.addCriteria(Criteria.where("id").is(userSub.getSubId()));
			query2.fields().include("duration");
			PlansDetails sub = this.mongoTemplate.findOne(query2, PlansDetails.class);

			if (sub != null)
			{
				String[] words = sub.getDuration().split(" ");

				// setting plan start time and end time
				Date planStartTime = new java.util.Date();

				 logger.info("planStartTime -- "+planStartTime);

				Calendar cal = Calendar.getInstance();
				cal.setTime(planStartTime);
				cal.add(Calendar.MONTH, Integer.parseInt(words[0]));
				 logger.info("words ------- "+words[0]);
				Date planEndTime = cal.getTime();

				 logger.info("planEndTime -- "+planEndTime);

				// userSub.setPlanStartTime(planStartTime);
				// userSub.setPlanEndTime(planEndTime);

				String id = new ObjectId().toString();

				if (uSub != null)
				{
					Query query3 = new Query();
					query3.addCriteria(Criteria.where("uId").is(userSub.getuId()));

					Update update = new Update();
					update.set("subId", userSub.getSubId());
					update.set("planStartTime", planStartTime);
					update.set("planEndTime", planEndTime);

					this.mongoTemplate.findAndModify(query3, update, UserSubscriptions.class);

					Query query4 = new Query();
					query4.addCriteria(Criteria.where("pubId").is(uSub.getuId())
					        .andOperator(Criteria.where("planStartTime").is(uSub.getPlanStartTime())).and("planEndTime")
					        .is(uSub.getPlanEndTime()));
					query4.fields().include("businesses");

					UserSubDetails userCurrentSubDetails = this.mongoTemplate.findOne(query4, UserSubDetails.class);

					// List<String> businesses = userCurrentSubDetails.getBusinesses();

					List<String> businesses = new ArrayList<>();

					if (userCurrentSubDetails.getBusinesses() != null
					        && userCurrentSubDetails.getBusinesses().size() > 0)
					{
						businesses = userCurrentSubDetails.getBusinesses();
					}

					userSubDetails.setId(id);
					userSubDetails.setPubId(userSub.getuId());
					userSubDetails.setPlanId(userSub.getSubId());
					userSubDetails.setUserSubId(uSub.getId());
					userSubDetails.setPlanStartTime(planStartTime);
					userSubDetails.setPlanEndTime(planEndTime);
					if (businesses != null)
					{
						userSubDetails.setBusinesses(businesses);
					}

					this.mongoTemplate.save(userSubDetails);

					return "UPDATED";
				}
				else
				{

					String userSubsId = new ObjectId().toString();
					userSubscription.setId(userSubsId);
					userSubscription.setuId(userSub.getuId());
					userSubscription.setSubId(userSub.getSubId());
					userSubscription.setPlanStartTime(planStartTime);
					userSubscription.setPlanEndTime(planEndTime);

					this.mongoTemplate.save(userSubscription);

					List<String> businesses = new ArrayList<>();
					userSubDetails.setId(id);
					userSubDetails.setPubId(userSub.getuId());
					userSubDetails.setPlanId(userSub.getSubId());
					userSubDetails.setUserSubId(userSubscription.getId());
					userSubDetails.setBusinesses(businesses);
					userSubDetails.setPlanStartTime(planStartTime);
					userSubDetails.setPlanEndTime(planEndTime);

					this.mongoTemplate.save(userSubDetails);

					user.setId(userSub.getuId());
					user.setActivation(2);

					this.userService.updateUser(user);
					// ---- Add Device Id here -----
					String result = userService.addDeviceIdToLoginDevices(userSub.getuId(), userSub.getDeviceID(),
					        userSub.getOsType());

					if (result.equalsIgnoreCase("FAIL"))
					{
						return "UNABLE";
					}

					return "SAVED";
				}
			}
			else
			{
				return "INVALID";
			}

		}
		else
		{
			return null;
		}

	}

	public Object verifyUserCurrentPlan(UserSubscriptions userSub) throws Exception
	{

		UserSubscriptions details = getCurrentPlan(userSub.getuId());

		if (details != null)
		{
			return "SUCCESS";
		}
		else
		{
			return "UNSUCCESS";
		}

	}

	public UserSubscriptions getCurrentPlan(String uId) throws Exception
	{
		if (uId != null)
		{
			if (userService.getUserById(uId) != null)
			{
				Query query = new Query();
				query.addCriteria(Criteria.where("uId").is(uId)
				        .andOperator(Criteria.where("planEndTime").gt(new java.util.Date())));

				UserSubscriptions details = this.mongoTemplate.findOne(query, UserSubscriptions.class);
				if (details != null)
				{
					return details;
				}
				else
				{
					return null;
				}

			}
			else
			{
				return null;
			}

		}
		else
		{
			return null;
		}

	}

	public void removeBusinessFromCurrentPlan(PublisherBusiness pbData)
	{
		if (pbData.getPublisherId() != null && pbData.getId() != null)
		{
			Query qry = new Query();
			qry.addCriteria(Criteria.where("uId").is(pbData.getPublisherId()));

			UserSubscriptions userSub = this.mongoTemplate.findOne(qry, UserSubscriptions.class);

			Query query = new Query();

			query.addCriteria(Criteria.where("pubId").is(pbData.getPublisherId())
			        .andOperator(Criteria.where("businesses").in(pbData.getId())).and("planStartTime")
			        .is(userSub.getPlanStartTime()).and("planEndTime").is(userSub.getPlanEndTime()));

			UserSubDetails userSubDetails = this.mongoTemplate.findOne(query, UserSubDetails.class);

			if (userSubDetails != null)
			{
				 Query query2=new Query();
				 query2.addCriteria(Criteria.where("pubId").is(pbData.getPublisherId()));
				 userSubDetails.getBusinesses().remove(pbData.getId());

				Update update = new Update();

				 update.set("businesses", userSubDetails.getBusinesses());
				update.pull("businesses", pbData.getId());

				this.mongoTemplate.updateFirst(query, update, UserSubDetails.class);
			 this.mongoTemplate.upsert(query2, update, UserSubDetails.class);
			}
		}
	}

	public Object updateUserPlan(UserSubscriptionBean userSub) throws Exception
	{

		config.setuId(userSub.getPublisherId());
		config.setSubId(userSub.getPlanId());

		return saveUserSubscription(config);

		// Query query = new Query();
		// query.addCriteria(Criteria.where("uId").is(userSub.getPublisherId()));
		//
		// UserSubscriptions userSubscriptions = this.mongoTemplate.findOne(query,
		// UserSubscriptions.class);
		//
		// if (userSubscriptions != null)
		// {
		// // logger.info("userSubDetails" + userSubscriptions.getSubId());
		//
		// Update update = new Update();
		// update.set("subId", userSub.getPlanId());
		// WriteResult result = this.mongoTemplate.updateFirst(query, update,
		// UserSubscriptions.class);
		// if (result.getN() > 0)
		// {
		//
		// Query query2 = new Query();
		// query2.addCriteria(Criteria.where("userSubId").is(userSubscriptions.getId()));
		//
		// Update update2 = new Update();
		// update2.set("planId", userSub.getPlanId());
		// WriteResult result2 = this.mongoTemplate.updateFirst(query2, update2,
		// UserSubDetails.class);
		// if (result2.getN() > 0)
		// {
		// return "SUCCESS";
		// }
		// else
		// {
		// return "UNSUCCESS";
		// }
		//
		// }
		// else
		// {
		// return "UNSUCCESS";
		// }
		//
		// }
		//
		// else
		// {
		// return "UNSUCCESS";
		// }

	}

}

package com.businessApp.service;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.businessApp.model.Business;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.repositories.BusinessRepository;
import com.businessApp.repositories.SubscriptionSettingsRepository;
import com.mongodb.WriteResult;

@Service
public class BusinessService
{

	private static Logger logger = LoggerFactory.getLogger(BusinessService.class);
	@Autowired
	BusinessRepository businessRepo;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	SubscriptionSettingsRepository subRepo;

	@Autowired
	PublisherService pbService;

	public void save(Business business) throws Exception
	{
	   
		Random rand = new Random(); 
		ObjectId obj=new ObjectId(new Date(), rand.nextInt(1000)); 
		business.setId(obj.toString());
		this.businessRepo.save(business);
	}

	public String update(Business business) throws Exception
	{
		return this.businessRepo.updateBusiness(business);
	}
	
	public String deleteBusinessById(Business business) throws Exception
	{
		return this.businessRepo.removeBusinessById(business);
	}

	public List<Business> businessList() throws Exception
	{
		return this.businessRepo.listBusiness();
	}

	public Object listServiceCategories(String businessId) throws Exception
	{

		Business templateData = getTemplateBusinessDetails(businessId);

		if (templateData != null)
		{
			return templateData;
		}
		else
		{
			PublisherBusiness pbBusinessData1 = new PublisherBusiness();

			Query query = new Query(Criteria.where("id").is(businessId));

			PublisherBusiness pbBusinessData = this.mongoTemplate.findOne(query, PublisherBusiness.class);

			if (pbBusinessData != null)
			{
				this.pbService.addNaming(pbBusinessData);
				// }

				Query query1 = new Query(Criteria.where("id").is(pbBusinessData.getBusinessId()));

				Business businessData = this.mongoTemplate.findOne(query1, Business.class);

				for (int i = 0; i < pbBusinessData.getServiceCategory().size(); i++)
				{
					for (int j = 0; j < businessData.getServiceCategory().size(); j++)
					{

						if (pbBusinessData.getServiceCategory().get(i).getId()
						        .equals(businessData.getServiceCategory().get(j).getId()))
						{

							businessData.getServiceCategory().get(j)
							        .setColour(pbBusinessData.getServiceCategory().get(i).getColour());
							for (int x = 0; x < pbBusinessData.getServiceCategory().get(i).getService().size(); x++)
							{
								// pbBusinessData.getServiceCategory().get(i).getService().get(x).
								for (int y = 0; y < businessData.getServiceCategory().get(j).getService().size(); y++)
								{
									if (pbBusinessData.getServiceCategory().get(i).getService().get(x).getId().equals(
									        businessData.getServiceCategory().get(j).getService().get(y).getId()))
									{
										businessData.getServiceCategory().get(j).getService()
										        .remove(businessData.getServiceCategory().get(j).getService().get(y));
										logger.info("SERV ID EQUAL");
									}
								}
							}
						}
					}
				}

				pbBusinessData1.setId(pbBusinessData.getId());
				pbBusinessData1.setBusinessId(pbBusinessData.getBusinessId());
				pbBusinessData1.setPublisherId(pbBusinessData.getPublisherId());

				pbBusinessData1.setServiceCategory(businessData.getServiceCategory());

				for (int a = 0; a < businessData.getServiceCategory().size(); a++)
				{
					for (int b = 0; b < pbBusinessData.getServiceCategory().size(); b++)
					{
						if (businessData.getServiceCategory().get(a).getId()
						        .equals(pbBusinessData.getServiceCategory().get(b).getId()))
						{
							for (int c = 0; c < pbBusinessData1.getServiceCategory().size(); c++)
							{
								if (pbBusinessData1.getServiceCategory().get(c).getId()
								        .equals(businessData.getServiceCategory().get(a).getId()))
								{
									pbBusinessData1.getServiceCategory().get(c).getService()
									        .addAll(pbBusinessData.getServiceCategory().get(b).getService());
								}
							}
						}
					}
				}

			}

			else
			{
				return null;
			}

			return pbBusinessData1;
		}

	}

	public Business getTemplateBusinessDetails(String businessId)
	{
		Query sCatQry = new Query(Criteria.where("id").is(businessId).and("status").is(0));

		long count = this.mongoTemplate.count(sCatQry, Business.class);

		if (count > 0)
		{
			Business templateData = this.mongoTemplate.findOne(sCatQry, Business.class);
			return templateData;
		}
		else
		{
			return null;
		}

	}

	public List<Business> allBusinessServiceCategories() throws Exception
	{

		return this.businessRepo.allBusinessServiceCategories();
	}

	public List<Business> listServiceCategoriesByBId(String businessId)
	{

		Query sCatQry = new Query(Criteria.where("id").is(businessId).and("status").is(0));

		return this.mongoTemplate.find(sCatQry, Business.class);
	}

   public String deleteBusinessById(String businessId)
	{
       /*   Business business=new Business();*/
		/*Query query = new Query();*/
		Query delQry = new Query(Criteria.where("id").is(businessId));
		/*Update upd = new Update();

		upd.set("status", 1);*/

		WriteResult result = this.mongoTemplate.remove(delQry,Business.class);

		if (result.getN() > 0)
		{
			return "SUCCESS";
		}

		else
		{
			return "UNSUCCESS";
		}
	}

	public String getIcon(String bId)
	{
		Business templateData = getTemplateBusinessDetails(bId);

		if (templateData != null)
		{

			return templateData.getIcon();
		}

		else
		{
			return "INVALID";
		}

	}

	public String saveIcon(Business bId)
	{
		if (bId != null)
		{
			Query updQry = new Query(Criteria.where("id").is(bId.getId()));
			Update upd = new Update();

			if (bId.getIcon() != null)
			{
				upd.set("icon", bId.getIcon());
			}

			if (bId.getModifiedTime() == null)
			{
				Date date = new Date();

				upd.set("modifiedTime", date);
			}

			this.mongoTemplate.upsert(updQry, upd, Business.class);

			// return "Image has been successfully uploaded ";

			return "SUCCESS";

		}

		else
		{
			// return "Image has not been uploaded ! ";
			return "UNSUCCESS";
		}
	}

}

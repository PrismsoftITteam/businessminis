package com.businessApp.service;

import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.bson.types.ObjectId;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.businessApp.model.Messages;
import com.businessApp.repositories.MessagesRepository;

@Service
public class AndroidPushNotificationsService
{

	@Autowired
	MessagesRepository messageRep;
	@Autowired
	Messages messageObj;

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

	private static Logger logger = LoggerFactory.getLogger(AndroidPushNotificationsService.class);

	public final static String AUTH_KEY_FCM_MYBUSINESS = "AAAAuwHjTYI:APA91bEWI5-RWxlU_I5paf8Pzxe1Sy-YP6GhX2f8CJhvqF2AFqLx9UvLN2a25BQtsVmMCIZAL_HiFL--AjEkUrCTAQCKIwGqholYNrc6zhkbmtuRx8f2CX3Aruv7WoFdxvnv9aFkYAe7";
	public final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";
	public final static String AUTH_KEY_FCM_MYCONSUMER = "AAAAX0z1GxM:APA91bHTk-45MGqxWZPLShhZo2HWUxGsb9iPg0LkRckS45oyVL4J828dzxWmCah4Sqq1MeMCx7X4JPtm2uaEPXdGYif7SCE79olTZzuEOCY51hq8ncH_5xcYrHiyBLXFoDNDhOdjMMa6";

	public String sendNotification(List<String> tokenList, List<Messages> messageList, int type) throws Exception
	{
		String authKey = null;

		if (type == 0)
		{

			authKey = AUTH_KEY_FCM_MYBUSINESS; // You FCM AUTH key
		}
		else if (type == 1)
		{

			authKey = AUTH_KEY_FCM_MYCONSUMER;
		}

		String FMCurl = API_URL_FCM;

		boolean status = true;

		if (!(tokenList.isEmpty()) && !(messageList.isEmpty()))
		{
			for (int i = 0; i < tokenList.size(); i++)
			{
				JSONObject json = new JSONObject();
				json.put("to", tokenList.get(i).trim());

				JSONObject info = new JSONObject();

				ObjectId id = new ObjectId();
				messageList.get(i).setId(id.toString());
				info.put("title", messageList.get(i).getTitle()); // Notification title

				info.put("message", messageList.get(i).getMessage()); // Notification body
				// logger.info("Time Stamp ++--------" + messageList.get(i).getCreatedTime());

				info.put("timestamp", getUTCTimeFormate(messageList.get(i).getCreatedTime())); // timestamp
				info.put("is_background", false);
				// info.put("image", " ");

				json.put("data", info);

				try
				{

					URL url = new URL(FMCurl);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();

					conn.setUseCaches(false);
					conn.setDoInput(true);
					conn.setDoOutput(true);

					conn.setRequestMethod("POST");
					conn.setRequestProperty("Authorization", "key=" + authKey);
					conn.setRequestProperty("Content-Type", "application/json");

					OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

					wr.write(json.toString());
					System.out.println("JSON OBJECT -----" + json.toString());
					wr.flush();
					InputStream stream = conn.getInputStream();
					int responseCode = conn.getResponseCode();

					if (responseCode == 200)
					{
						if (type == 0)
						{
							if (status)
							{
								this.messageRep.save(messageList.get(0));
							}

							status = false;

						}
						else
						{
							this.messageRep.save(messageList.get(i));
						}

					}

				}

				catch (Exception e)
				{
					e.printStackTrace();

				}
				// }

			}
			return "SUCCESS";
		}

		return "Fail";

	}

	public String getUTCTimeFormate(Date dateNow)
	{

		DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC")); // UTC timezone
		return formatterUTC.format(dateNow);

	}

	// Not Usingggggg --------------------------
	public String sendAppointmentNotification(String userDeviceIdKey, Messages message, int type) throws Exception
	{
		String authKey = null;

		if (type == 0)
		{
			logger.info("AUTH_KEY_FCM_MYBUSINESS");
			authKey = AUTH_KEY_FCM_MYBUSINESS; // You FCM AUTH key
		}
		else if (type == 1)
		{
			logger.info("AUTH_KEY_FCM_MYCONSUMER");
			authKey = AUTH_KEY_FCM_MYCONSUMER;
		}

		if (message != null)
		{
			ObjectId id = new ObjectId();
			message.setId(id.toString());
		}

		String FMCurl = API_URL_FCM;

		URL url = new URL(FMCurl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();

		conn.setUseCaches(false);
		conn.setDoInput(true);
		conn.setDoOutput(true);

		conn.setRequestMethod("POST");
		conn.setRequestProperty("Authorization", "key=" + authKey);
		conn.setRequestProperty("Content-Type", "application/json");

		JSONObject json = new JSONObject();
		json.put("to", userDeviceIdKey.trim());

		JSONObject info = new JSONObject();

		info.put("title", message.getTitle()); // Notification title

		info.put("body", message.getMessage()); // Notification body

		logger.info("Time Stamp ++--------" + message.getCreatedTime());

		// info.put("timestamp", message.getCreatedTime()); // timestamp

		json.put("notification", info);

		try
		{

			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			// System.out.println(json.toString());
			wr.write(json.toString());
			// System.out.println("JSON OBJECT -----" + json.toString());
			wr.flush();
			InputStream stream = conn.getInputStream();
			int responseCode = conn.getResponseCode();
			if (responseCode == 200)
			{

				this.messageRep.save(message);
				return "SUCCESS";
			}
			else
			{

				return "Fail";
			}

		}

		catch (Exception e)
		{
			e.printStackTrace();

			return "Fail";

		}

	}

}

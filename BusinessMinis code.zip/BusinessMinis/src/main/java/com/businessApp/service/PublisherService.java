package com.businessApp.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.businessApp.bean.AppointmentBean;
import com.businessApp.bean.PublisherBusinessServices;
import com.businessApp.bean.QRCodeBean;
import com.businessApp.bean.SaveConsumerBusinessDetails;
import com.businessApp.bean.UpdatePBColor;
import com.businessApp.model.AppointmentCalendar;
import com.businessApp.model.Business;
import com.businessApp.model.BusinessBreakConfig;
import com.businessApp.model.ConsumerBusinessDetails;
import com.businessApp.model.Messages;
import com.businessApp.model.PlansDetails;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.model.PublisherBusinessEmployee;
import com.businessApp.model.QRCode;
import com.businessApp.model.RaiseRequest;
import com.businessApp.model.ServiceCategory;
import com.businessApp.model.ServiceType;
import com.businessApp.model.User;
import com.businessApp.model.UserSubDetails;
import com.businessApp.model.UserSubscriptions;
import com.businessApp.repositories.BusinessBreakConfigRepository;
import com.businessApp.repositories.BusinessRepository;
import com.businessApp.repositories.PublisherBusinessRepository;
import com.businessApp.repositories.QRCodeRepository;
import com.businessApp.repositories.RaiseRequestRepository;
import com.mongodb.BasicDBObject;
import com.mongodb.WriteResult;

@Service
public class PublisherService
{

	private static Logger logger = LoggerFactory.getLogger(PublisherService.class);

	@Autowired
	private PublisherBusinessRepository pubBusRepo;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	private QRCodeRepository qrCodeRep;

	@Autowired
	UserService userService;

	@Autowired
	BusinessRepository businessRepo;

	@Autowired
	BusinessService businessService;

	@Autowired
	BusinessBreakConfigRepository bussinessBreak;

	@Autowired
	PublisherBusinessEmployeeService pBEmpService;

	@Autowired
	SubscriptionService subService;
	// @Autowired
	// Messages message;

	@Autowired
	AndroidPushNotificationsService fcm;

	@Autowired
	RaiseRequestRepository raiseRequest;

	public String save(PublisherBusiness publBusiness) throws Exception
	{

		List<ServiceType> tmp = null;
		int k = 0;
		Random rand = new Random(); 
		ObjectId obj=new ObjectId(new Date(), rand.nextInt(1000)); 
		publBusiness.setId(obj.toString());
		this.pubBusRepo.save(publBusiness);

		User userData = this.userService.getUserById(publBusiness.getPublisherId());

		if (userData != null)
		{
			if (userData.getId().equals(publBusiness.getPublisherId()))
			{
				String response = AllowedToCreateBusiness(publBusiness.getPublisherId());

				if (response.equalsIgnoreCase("YES"))
				{
					this.pubBusRepo.save(publBusiness);

					this.addBusinessToCurrentplan(publBusiness.getId(), publBusiness.getPublisherId());

					tmp = new ArrayList<>();

					 for (int i = 0; i < publBusiness.getServiceCategory().size(); i++)
					{
					 for (int j = 0; j <
					 publBusiness.getServiceCategory().get(i).getService().size(); j++)
					 {
					
					 if (publBusiness.getServiceCategory().get(i).getService().get(j).getType() ==
					 1)
					 {
					
					 tmp.add(k, publBusiness.getServiceCategory().get(i).getService().get(j));
					
					 String bId = publBusiness.getBusinessId();
					 String SerCatId = publBusiness.getServiceCategory().get(i).getId();
					
					 addServiceToBusiness(bId, SerCatId, tmp);
					 tmp.remove(k);
					 }
					 }
					
					 }

					return publBusiness.getId();
				}
				else
				{
					return "NOTALLOWED";
				}

			}
			else
			{
				return "UNSUCCESS";
			}
		}

		else
		{
			return "UNSUCCESS";
		}

	}

	private void addBusinessToCurrentplan(String id, String publisherId)
	{
		Query query1 = new Query();
		query1.addCriteria(Criteria.where("uId").is(publisherId));
		UserSubscriptions pubSubdetail = this.mongoTemplate.findOne(query1, UserSubscriptions.class);

		Query query2 = new Query();
		query2.addCriteria(Criteria.where("userSubId").is(pubSubdetail.getId())
		        .andOperator(Criteria.where("planStartTime").is(pubSubdetail.getPlanStartTime())).and("planEndTime")
		        .is(pubSubdetail.getPlanEndTime()));
		UserSubDetails userPlanDetails = this.mongoTemplate.findOne(query2, UserSubDetails.class);

		userPlanDetails.getBusinesses().add(id);

		Update update = new Update();
		update.set("businesses", userPlanDetails.getBusinesses());

		this.mongoTemplate.upsert(query2, update, UserSubDetails.class);
	}

	private String AllowedToCreateBusiness(String publisherId)
	{
		String response = "NO";

		Query query1 = new Query();
		query1.addCriteria(Criteria.where("uId").is(publisherId));
		UserSubscriptions pubSubdetail = this.mongoTemplate.findOne(query1, UserSubscriptions.class);

		UserSubDetails userPlanDetails = null;
		if (pubSubdetail != null)
		{

			Query query2 = new Query();
			query2.addCriteria(Criteria.where("userSubId").is(pubSubdetail.getId())
			        .andOperator(Criteria.where("planStartTime").is(pubSubdetail.getPlanStartTime())).and("planEndTime")
			        .is(pubSubdetail.getPlanEndTime()));
			userPlanDetails = this.mongoTemplate.findOne(query2, UserSubDetails.class);

			if (userPlanDetails != null)
			{

				Query query3 = new Query();
				query3.addCriteria(Criteria.where("id").is(pubSubdetail.getSubId()));
				query3.fields().include("businessCount");
				PlansDetails planDetails = this.mongoTemplate.findOne(query3, PlansDetails.class);

				if (userPlanDetails.getBusinesses().size() < planDetails.getBusinessCount())
				{
					response = "YES";
				}
			}
		}

		return response;
	}

	// Not using this method
	private void addServiceToBusiness(String bId, String serCatId, List<ServiceType> sevr)
	{

		ObjectId ob = new ObjectId(serCatId);


		for (int i = 0; i < sevr.size(); i++)
		{
			if ((sevr.get(i).getName() != null) && (sevr.get(i).getDescription() != null))
			{

				sevr.get(i).setDuration(0);
				sevr.get(i).setPrice(0.0);
				sevr.get(i).setUnit(null);

				Query query = new Query();
				query.addCriteria(Criteria.where("serviceCategory.id").is(ob));

				Update update = new Update();

				update.addToSet("serviceCategory.$.service", sevr.get(i));

				this.mongoTemplate.findAndModify(query, update, Business.class);

			}
		}

	}

	public List<Object> businessListBypublisherId(String publisherId) throws Exception
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("publisherId").is(publisherId).andOperator(Criteria.where("status").is(0)));

		List<PublisherBusiness> tmpBusinessList = this.mongoTemplate.find(query, PublisherBusiness.class);

		List<Object> BusinessList = new ArrayList<>();
		PublisherBusiness tmp;

		if ((tmpBusinessList.size()) > 0 && (tmpBusinessList != null))
		{

			for (PublisherBusiness pb : tmpBusinessList)
			{
				tmp = addNaming(pb);

				UserSubscriptions userSubDetails = subService.getCurrentPlan(tmp.getPublisherId());
				if (userSubDetails != null)
				{
					tmp.setPlanId(userSubDetails.getSubId());
					// tmp.setPlanId(userSubDetails.getPlanId());
				}

				BusinessList.add(tmp);
			}
		}

		return BusinessList;

	}

	public PublisherBusiness addNaming(PublisherBusiness pb)
	{
		Query qr = new Query();
		qr.addCriteria(Criteria.where("id").is(pb.getBusinessId()));
		Business businessDATA = this.mongoTemplate.findOne(qr, Business.class);

		if (businessDATA != null)
		{

			for (int i = 0; i < pb.getServiceCategory().size(); i++)

			{

				for (int p = 0; p < businessDATA.getServiceCategory().size(); p++)

				{
					if (businessDATA.getServiceCategory().get(p).getId().equals(pb.getServiceCategory().get(i).getId()))

					{

						// Assign ServiceCategory Name
						pb.getServiceCategory().get(i).setName(businessDATA.getServiceCategory().get(p).getName());

						// Assign ServiceCategory Description
						pb.getServiceCategory().get(i)
						        .setDescription(businessDATA.getServiceCategory().get(p).getDescription());

						if (pb.getServiceCategory().get(i).getType() == 0)
						{
							pb.getServiceCategory().get(i)
							        .setColour(businessDATA.getServiceCategory().get(p).getColour());
						}

						// Check the sizes of services in Business and Publisher
						// Business

						for (int j = 0; j < pb.getServiceCategory().get(i).getService().size(); j++)
						{

							for (int q = 0; q < businessDATA.getServiceCategory().get(p).getService().size(); q++)
							{

								if (businessDATA.getServiceCategory().get(p).getService().get(q).getId()
								        .equals(pb.getServiceCategory().get(i).getService().get(j).getId()))
								{

									// Assign Service Name
									pb.getServiceCategory().get(i).getService().get(j).setName(
									        businessDATA.getServiceCategory().get(p).getService().get(q).getName());

									// Assign Service Description
									pb.getServiceCategory().get(i).getService().get(j).setDescription(businessDATA
									        .getServiceCategory().get(p).getService().get(q).getDescription());

								}

							}

						}

					}

				}

			}
		} // if null check

		return pb;

	}

	public String addServiceToPublisherBusiness(PublisherBusinessServices addService)
	{

		String report = "UnSuccess";

		if ((addService.getPublisherBusinessId() != null))
		{

			PublisherBusiness pubBussinessData = getPublisherBusinessData(addService.getPublisherBusinessId());

			if (pubBussinessData != null)
			{

				if (pubBussinessData.getServiceCategory().size() > 0)
				{
					report = addService(addService);
				}

			}

		}

		return report;

	}

	public PublisherBusiness getPublisherBusinessData(String publisherBusinessId)
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(publisherBusinessId).and("status").is(0));
		long count = this.mongoTemplate.count(query, PublisherBusiness.class);

		if (count > 0)
		{

			PublisherBusiness pbData = this.mongoTemplate.findOne(query, PublisherBusiness.class);

			return addNaming(pbData);
		}

		else
		{
			return null;
		}

	}

	private String addService(PublisherBusinessServices addService)
	{

		String s;
		ObjectId ob = addService.getServiceCatId();

		PublisherBusiness pbData = getPublisherBusinessData(addService.getPublisherBusinessId());

		 Query query1 = new Query();
		 query1.addCriteria(
		 Criteria.where("_id").is(addService.getPublisherBusinessId()));
		 PublisherBusiness pbData1 = this.mongoTemplate.findOne(query1, PublisherBusiness.class);

		int status = 0;
		for (int i = 0; i < pbData1.getServiceCategory().size(); i++)
		{
			if (pbData1.getServiceCategory().get(i).getId().equals(ob.toString()))
			{
				status = 1;
				break;
			}

		}
		if (status == 0)
		{

			ServiceCategory s1 = new ServiceCategory();

			s1.setId(ob);
			s1.setService(null);

			pbData1.getServiceCategory().add(s1);

			try
			{
				String reoprt = updatePublisherBusiness(pbData1);
			}
			catch (Exception e)
			{

				e.printStackTrace();
			}
		}

		Query query = new Query();
		query.addCriteria(Criteria.where("serviceCategory.id").is(ob)
		        .andOperator(Criteria.where("_id").is(addService.getPublisherBusinessId())));
		Update update = new Update();

		update.push("serviceCategory.$.service", addService.getService());
		PublisherBusiness add = this.mongoTemplate.findAndModify(query, update, PublisherBusiness.class);

		if (add != null)
		{
			s = "Success";
		}
		else
		{
			s = "UnSuccess";
		}

		return s;

	}

	public String deletePbBusinessById(String businessId) throws Exception
	{

		PublisherBusiness pbData = getPublisherBusinessData(businessId);

		if (pbData != null)
		{

			// 1) remove bId from consummer Bussiness List

			SaveConsumerBusinessDetails cBD = new SaveConsumerBusinessDetails();

			cBD.setbId(businessId);

			this.userService.removeConsumerBusiness(cBD);

			//
			this.subService.removeBusinessFromCurrentPlan(pbData);

			// 2) set employees status 1

			List<PublisherBusinessEmployee> empList = this.pBEmpService.employeeList(pbData.getId(),
			        pbData.getPublisherId());

			if (empList != null)
			{
				for (int i = 0; i < empList.size(); i++)
				{
					this.pBEmpService.deleteEmployeeById(empList.get(i).getId());
				}
			}

			// 3) set appointments status 4

			PublisherBusinessServices pbService = new PublisherBusinessServices();

			pbService.setPublisherBusinessId(businessId);

			// To get Appointments by pbID

			List<AppointmentCalendar> appData = this.pBEmpService.getAppointmentByPubId_ServId(pbService);
			if (appData != null)
			{
				this.pBEmpService.deleteAppointments(appData);
			}

			// this.pBEmpService.deleteAppointments(pbService);

			// 4) set Publisher Business status 1

			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(businessId));
			Update upd = new Update();

			upd.set("status", 1);

			WriteResult result = this.mongoTemplate.upsert(query, upd, PublisherBusiness.class);

			if (result.getN() > 0)
			{

				if (appData != null && appData.size() > 0)
				{
					String message = "";

					this.sendNotificationForAppointmentCancellation(pbData, appData, message);
				}

				return "SUCCESS";
			}

			else
			{
				return "UNSUCCESS";
			}

		}
		else
		{
			return "INVALID";
		}

	}

	public void sendNotificationForAppointmentCancellation(PublisherBusiness pbData, List<AppointmentCalendar> appData,
	        String msg) throws Exception
	{
		List<Messages> messageList = new ArrayList<>();
		List<String> tokenList = new ArrayList<>();
		List<User> consumerList = new ArrayList<>();
		String title = "Appointment got cancalled";
		String msgTest;
		String date;
		Messages message;

		List<String> msgList = new ArrayList<>();

		for (int i = 0; i < appData.size(); i++)
		{

			User user = userService.getUserById(appData.get(i).getConsumerId());
			List<String> serviceDetais = this.pBEmpService.getServiceDetails(pbData, appData.get(i).getServiceId());
			date = this.pBEmpService.toChangeDateToLocalFormat(appData.get(i).getStartScheduledTime().toString());
			msgTest = pbData.getName() + " : " + title + " for " + serviceDetais.get(0) + " at " + date + "."
			        + "\n due to " + msg;

			if (user != null)
			{

				for (int j = 1; j < appData.size(); j++)
				 {
				 if ((!appData.get(i).getId().equals(appData.get(j).getId())) && i != j)
				 {
				 consumerList.add(user);
				 break;
				 }
				 }

				msgList.add(msgTest);

				consumerList.add(user);

			}
			date = "";
			msgTest = "";

		}

		if (!consumerList.isEmpty())
		{

			 logger.info("consumerList --" + consumerList.size());

			for (int i = 0; i < consumerList.size(); i++)
			{
				message = new Messages();

				 logger.info("Generated Message ----" + msgList.get(i));

				if (consumerList.get(i).getToken() != null)
				{

					message.setType(0);
					Date dateNow = new Date();
					DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
					formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC"));

					message.setuId(pbData.getPublisherId());
					message.setbId(pbData.getId());
					message.setReceiverID(consumerList.get(i).getId());
					message.setTitle(title);
					message.setMessage(msgList.get(i));
					message.setFrom(pbData.getName());
					message.setTo(consumerList.get(i).getDeviceID());
					message.setCreatedTime(dateNow);
					messageList.add(message);
					tokenList.add(consumerList.get(i).getToken());
				}
			}

			fcm.sendNotification(tokenList, messageList, 1);

		}

	}

	public String removeServiceFromPublisherBusiness(PublisherBusinessServices removeService) throws Exception
	{

		String report = "UnSuccess";

		if ((removeService.getPublisherBusinessId() != null))
		{

			PublisherBusiness pbData = getPublisherBusinessData(removeService.getPublisherBusinessId());

			if (pbData != null)
			{

				// Step 1 ---- > Remove all Appointment Associated with that Service Id

				// To get Appointments by pbID and serviceID
				List<AppointmentCalendar> appData = this.pBEmpService.getAppointmentByPubId_ServId(removeService);

				if (appData != null)
				{
					this.pBEmpService.deleteAppointments(appData);

					String message = "service removed";
					// to send notifications for appointment cancelled
					this.sendNotificationForAppointmentCancellation(pbData, appData, message);
				}

				// Step 2 ---- > Remove that Service from Employees

				Query query2 = new Query();
				query2.addCriteria(Criteria.where("businessId").is(removeService.getPublisherBusinessId()));
				List<PublisherBusinessEmployee> empData = this.mongoTemplate.find(query2,
				        PublisherBusinessEmployee.class);

				if ((empData != null) && (empData.size() > 0))
				{

					for (PublisherBusinessEmployee emp : empData)
					{

						if (emp.getServiceCategory().size() > 0)
						{
							removeServiceFromEmployee(removeService, emp.getId());
						}

					}
				}

				// Step 3 ---- > Remove that Service from Publisher Business
				Query query = new Query();
				query.addCriteria(Criteria.where("id").is(removeService.getPublisherBusinessId()));
				PublisherBusiness pubBussinessData = this.mongoTemplate.findOne(query, PublisherBusiness.class);

				if (pubBussinessData != null)
				{

					if (pubBussinessData.getServiceCategory().size() > 0)
					{
						report = removeService(removeService);
					}
				}
				return report;
			}
			else
			{
				return "INVALID";
			}

		}

		return "INVALID";
	}

	private void removeServiceFromEmployee(PublisherBusinessServices removeService, String empId)
	{
		String s;
		Query query = Query.query(Criteria.where("serviceCategory.service.id").is(removeService.getServiceId())
		        .andOperator(Criteria.where("id").is(empId)));

		Update update = new Update().pull("serviceCategory.$.service",
		        new BasicDBObject("id", removeService.getServiceId()));

		WriteResult pB = this.mongoTemplate.updateFirst(query, update, PublisherBusinessEmployee.class);

		// if (pB.getN() == 1)
		// {
		//
		// s = "Success";
		// } else
		// {
		// s = "UnSuccess";
		// }
		//
		// return s;
	}

	private String removeService(PublisherBusinessServices removeService)
	{
		String s;
		Query query = Query.query(Criteria.where("serviceCategory.service.id").is(removeService.getServiceId())
		        .andOperator(Criteria.where("id").is(removeService.getPublisherBusinessId())));

		Update update = new Update().pull("serviceCategory.$.service",
		        new BasicDBObject("id", removeService.getServiceId()));

		WriteResult pB = this.mongoTemplate.updateFirst(query, update, PublisherBusiness.class);

		if (pB.getN() == 1)
		{

			s = "Success";
		}
		else
		{
			s = "UnSuccess";
		}

		return s;

	}

	public String updatePublisherBusiness(PublisherBusiness updatePublBusiness) throws Exception
	{

		return this.pubBusRepo.updateBusines(updatePublBusiness);

	}

	public List<Object> publisherBusinessListByAdminBId(String businessId) throws Exception
	{

		Query query = new Query();
		query.addCriteria(Criteria.where("businessId").is(businessId).and("status").is(0));

		List<PublisherBusiness> pubData = this.mongoTemplate.find(query, PublisherBusiness.class);

		List<Object> BusinessList = new ArrayList<>();
		PublisherBusiness tmp;

		int flag = 0;

		if ((pubData.size()) > 0 && (pubData != null))
		{

			for (int i = 0; i < pubData.size(); i++)
			{

				if (pubData.get(i).getServiceCategory().size() > 0)
				{

					for (int k = 0; k < pubData.get(i).getServiceCategory().size(); k++)
					{

						if (pubData.get(i).getServiceCategory().get(k).getService().size() > 0)
						{
							for (int j = 0; j < pubData.get(i).getServiceCategory().get(k).getService().size(); j++)
							{

								if (pubData.get(i).getServiceCategory().get(k).getService().size() > 0)
								{
									flag = 1;
								}

							}
						}

					}

				}

				if (flag == 1)
				{
					List<PublisherBusinessEmployee> empSize = this.pBEmpService.employeeList(pubData.get(i).getId(),
					        pubData.get(i).getPublisherId());

					if (empSize.size() > 0)
					{
						tmp = addNaming(pubData.get(i));
						BusinessList.add(tmp);
					}

					flag = 0;
				}

			}

		}

		return BusinessList;

	}

	public String updatePubisherBusinessServiceCatColor(UpdatePBColor updatePublBusinessColor)
	{
		String report = "UnSuccess";

		if ((updatePublBusinessColor.getId() != null) && (updatePublBusinessColor.getServCatId() != null))
		{

			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(updatePublBusinessColor.getId())
			        .andOperator(Criteria.where("serviceCategory.id").is(updatePublBusinessColor.getServCatId())));

			Update update = new Update();

			update.set("serviceCategory.$.colour", updatePublBusinessColor.getColour());
			update.set("serviceCategory.$.type", updatePublBusinessColor.getType());

			WriteResult tmp = this.mongoTemplate.updateFirst(query, update, PublisherBusiness.class);

			if (tmp.getN() == 1)
			{
				return "Success";

			}

			else
			{
				return "UnSuccess";
			}

		}

		else
		{
			report = "INVALID";
		}

		return report;
	}

	public void saveQRCode(QRCodeBean qrb) throws IOException
	{

		if ((qrb.getId() != null))
		{

			QRCode qr = new QRCode();

			qr.setId(qrb.getId());
			qr.setQrCode(new Binary(BsonBinarySubType.BINARY, qrb.getQrCode().getBytes("UTF-8")));

			this.qrCodeRep.save(qr);
		}

	}

	public Object getpublisherBusinessQRCode(String businessId) throws UnsupportedEncodingException

	{

		if (businessId != null)
		{
			Query query = new Query();
			query.addCriteria(Criteria.where("id").is(businessId));

			QRCode data = this.mongoTemplate.findOne(query, QRCode.class);

			String qrCodeString = new String(data.getQrCode().getData(), "UTF-8");

			return qrCodeString;

		}

		else
		{
			return null;
		}

	}

	public String saveBreakConfig(BusinessBreakConfig businesBreak)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("bId").is(businesBreak.getbId()));

		BusinessBreakConfig tmp = this.mongoTemplate.findOne(query, BusinessBreakConfig.class);

		if (tmp == null)
		{
			this.bussinessBreak.save(businesBreak);
			return "SUCCES";
		}

		else
		{
			return "UNSUCCES";
		}

	}

	public String updateBreakConfig(BusinessBreakConfig businesBreak)
	{
		String report = "UnSuccess";

		if ((businesBreak.getbId() != null) && (businesBreak.getId() != null))
		{

			Query query = new Query();

			query.addCriteria(Criteria.where("bId").is(businesBreak.getbId())
			        .andOperator(Criteria.where("id").is(businesBreak.getId())));

			Update update = new Update();

			if ((businesBreak.getFrequency() != null))
			{
				update.set("frequency", businesBreak.getFrequency());

			}

			if ((businesBreak.getInterval() > 0))
			{

				update.set("interval", businesBreak.getInterval());
			}

			if ((businesBreak.getBreakStatus() == 0) || (businesBreak.getBreakStatus() == 1))
			{

				update.set("breakStatus", businesBreak.getBreakStatus());
			}

			WriteResult tmp = this.mongoTemplate.upsert(query, update, BusinessBreakConfig.class);

			if (tmp.getN() == 1)
			{
				return "Success";

			}

			else
			{
				return "UnSuccess";
			}

		}

		else
		{
			report = "INVALID";
		}

		return report;

	}

	public Object getBreakConfigDetails(String businessId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("bId").is(businessId));

		return this.mongoTemplate.findOne(query, BusinessBreakConfig.class);
	}

	public Object publisherBusinessByBId(String businessId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(businessId).and("status").is(0));
		 query.fields().include("id");
		 query.fields().include("publisherId");
		 query.fields().include("businessId");
		 query.fields().include("name");
		 query.fields().include("serviceCategory");

		PublisherBusiness pbData = this.mongoTemplate.findOne(query, PublisherBusiness.class);

		if (pbData != null)
		{
			addNaming(pbData);
		}

		return pbData;

	}

	public String updateServicCategories(PublisherBusiness updatePublBusiness) throws Exception
	{

		return this.pubBusRepo.updateBusines(updatePublBusiness);

	}

	public String updateParticularService(PublisherBusinessServices updatePubService) throws Exception
	{

		String s = "SUCCESS";

		PublisherBusiness pbData = this.getPublisherBusinessData(updatePubService.getPublisherBusinessId());

		if (pbData != null)
		{
			if (pbData.getServiceCategory() != null && pbData.getServiceCategory().size() > 0)
			{
				for (int i = 0; i < pbData.getServiceCategory().size(); i++)
				{
					if (pbData.getServiceCategory().get(i).getId()
					        .equals(updatePubService.getServiceCatId().toString()))
					{
						if (pbData.getServiceCategory().get(i).getService() != null
						        && pbData.getServiceCategory().get(i).getService().size() > 0)
						{
							for (int j = 0; j < pbData.getServiceCategory().get(i).getService().size(); j++)
							{
								if (pbData.getServiceCategory().get(i).getService().get(j).getId()
								        .equals(updatePubService.getService().getId()))
								{

									if (pbData.getServiceCategory().get(i).getService().get(j)
									        .getDuration() < updatePubService.getService().getDuration())
									{
										// Get All Appointments of this serviceID with status =0
										// Delete all appointments
										// Send notifications to both publisher and consumer
									}

									if (updatePubService.getService().getDuration() > 0)
									{
										pbData.getServiceCategory().get(i).getService().get(j)
										        .setDuration(updatePubService.getService().getDuration());
									}

									if (updatePubService.getService().getPrice() != 0)
									{
										pbData.getServiceCategory().get(i).getService().get(j)
										        .setPrice(updatePubService.getService().getPrice());
									}
									if (updatePubService.getService().getUnit() != null)
									{
										pbData.getServiceCategory().get(i).getService().get(j)
										        .setUnit(updatePubService.getService().getUnit());
									}
									if (updatePubService.getService().getRenewalTime() != 0)
									{
										pbData.getServiceCategory().get(i).getService().get(j)
										        .setRenewalTime(updatePubService.getService().getRenewalTime());
									}

									if (updatePubService.getService().getType() == 1)
									{
										if (updatePubService.getService().getName() != null)
										{
											pbData.getServiceCategory().get(i).getService().get(j)
											        .setName(updatePubService.getService().getName());
										}
										if (updatePubService.getService().getDescription() != null)
										{
											pbData.getServiceCategory().get(i).getService().get(j)
											        .setDescription(updatePubService.getService().getDescription());
										}
									}

									this.updatePublisherBusiness(pbData);

								}
							}
						}
					}
				}
			}
		}
		else
		{
			s = "UNSUCCESS";
		}

		return s;

	}

	public String saveIcon(PublisherBusiness pBusiness)
	{
		if (pBusiness != null)
		{
			Query updQry = new Query(Criteria.where("id").is(pBusiness.getId()));
			Update upd = new Update();

			if (pBusiness.getIcon() != null)
			{
				upd.set("icon", pBusiness.getIcon());
			}

			if (pBusiness.getUpdateTime() == null)
			{
				Date date = new Date();

				upd.set("updateTime", date);
			}

			this.mongoTemplate.upsert(updQry, upd, PublisherBusiness.class);

			return "SUCCESS";

		}

		else
		{

			return "UNSUCCESS";
		}
	}

	public String getIcon(String businessId)
	{
		PublisherBusiness pubBussinessData = getPublisherBusinessData(businessId);
		if (pubBussinessData != null)
		{
			return pubBussinessData.getIcon();
		}

		else
		{
			return "INVALID";
		}

	}

	public Object getOnedayReport(AppointmentBean appointmentBean)
	{

		List<Integer> details = this.pBEmpService.getAppointmentDetails(appointmentBean);

		PublisherBusiness pbData = getPublisherBusinessData(appointmentBean.getBusinessId());

		if (pbData != null)
		{
			if (pbData.getBusinessHours().get(details.get(3).toString()).getHoliday() == 0)
			{

				Map<String, Object> report = new HashMap<>();

				report.put("name", new SimpleDateFormat("dd-MM-yyyy").format(appointmentBean.getStartScheduledTime()));
				report.put("businessName", pbData.getName());
				report.put("businessId", appointmentBean.getBusinessId());
				report.put("fromDate", appointmentBean.getStartScheduledTime());
				report.put("toDate", appointmentBean.getEndScheduledTime());

				Double totalRevenue = 0.00;

				List<Map<String, Object>> services = onedayReportBasedOnservicesOfBusiness(appointmentBean, pbData);

				if (services == null)
				{
					return "noService";
				}
				else
				{
					for (int i = 0; i < services.size(); i++)
					{
						totalRevenue = totalRevenue + (Double) services.get(i).get("totalRevenue");
					}

					report.put("totalRevenue", totalRevenue);

					return report;
				}
			}
			else
			{
				return "holiday";
			}
		}
		else
		{
			return "invalid";
		}

	}

	public Object reportFromDateToDate(AppointmentBean appointmentBean)
	{

		PublisherBusiness pbData = getPublisherBusinessData(appointmentBean.getBusinessId());
		logger.info("" + appointmentBean.getStartScheduledTime() + "-----" + appointmentBean.getEndScheduledTime());

		Map<String, Object> report = new HashMap<>();

		if (pbData != null)
		{

			if (appointmentBean.getType().equals("custom"))
			{
				report.put("name", "custom");
			}
			else if (appointmentBean.getType().equals("weekly"))
			{
				report.put("name", new SimpleDateFormat("dd-MM-yyyy").format(appointmentBean.getStartScheduledTime()));
			}
			else if (appointmentBean.getType().equals("monthly"))
			{
				report.put("name", new SimpleDateFormat("MMMM").format(appointmentBean.getStartScheduledTime()));
			}
			else if (appointmentBean.getType().equals("yearly"))
			{
				report.put("name", new SimpleDateFormat("yyyy").format(appointmentBean.getStartScheduledTime()));
			}

			report.put("businessName", pbData.getName());
			report.put("businessId", appointmentBean.getBusinessId());
			report.put("fromDate", appointmentBean.getStartScheduledTime());
			report.put("toDate", appointmentBean.getEndScheduledTime());
			Double totalRevenue = 0.00;

			List<Map<String, Object>> services = onedayReportBasedOnservicesOfBusiness(appointmentBean, pbData);

			if (services == null)
			{
				return "noService";
			}
			else
			{
				for (int i = 0; i < services.size(); i++)
				{
					totalRevenue = totalRevenue + (Double) services.get(i).get("totalRevenue");
				}

				report.put("totalRevenue", totalRevenue);

				return report;
			}

		}
		else
		{
			return "invalid";
		}
	}

	public List<Map<String, Object>> onedayReportBasedOnservicesOfBusiness(AppointmentBean appointmentBean,
	        PublisherBusiness pbData)
	{
		PublisherBusiness businessData = addNaming(pbData);

		List<Map<String, Object>> basedOnService = new ArrayList<>();

		int status = 0;

		if (businessData.getServiceCategory().size() > 0)
		{
			for (int i = 0; i < businessData.getServiceCategory().size(); i++)
			{
				if (businessData.getServiceCategory().get(i).getService().size() > 0)
				{
					status = status + 1;

					for (int j = 0; j < businessData.getServiceCategory().get(i).getService().size(); j++)
					{
						String serviceId = businessData.getServiceCategory().get(i).getService().get(j).getId();
						 Double serviceCost =
						 businessData.getServiceCategory()
						 .get(i).getService().get(j).getPrice();
						Query query2 = new Query();
						query2.addCriteria(Criteria.where("serviceId").is(serviceId)
						        .andOperator(Criteria.where("businessId").is(appointmentBean.getBusinessId()))
						        .and("startScheduledTime").gte(appointmentBean.getStartScheduledTime())
						        .and("endScheduledTime").lt(appointmentBean.getEndScheduledTime()));

						List<AppointmentCalendar> serviceAppointments = this.mongoTemplate.find(query2,
						        AppointmentCalendar.class);

						int performedAppointments = 0;
						int canceledAppointments = 0;
						double totalRevenue = 0.00;

						if (serviceAppointments != null && serviceAppointments.size() > 0)
						{
							for (int k = 0; k < serviceAppointments.size(); k++)
							{
								if (serviceAppointments.get(k).getStatus() == 2)
								{
									totalRevenue = totalRevenue + serviceAppointments.get(k).getPrice();
									performedAppointments = performedAppointments + 1;
								}
								if (serviceAppointments.get(k).getStatus() == 3)
								{
									canceledAppointments = canceledAppointments + 1;
								}
							}
						}

						Map<String, Object> serviceReport = new HashMap<>();
						serviceReport.put("serviceCategoryName", businessData.getServiceCategory().get(i).getName());
						serviceReport.put("serviceId", serviceId);
						serviceReport.put("serviceName",
						        businessData.getServiceCategory().get(i).getService().get(j).getName());

						if (serviceAppointments != null && serviceAppointments.size() > 0)
						{
							serviceReport.put("scheduledAppointmentsCount", serviceAppointments.size());
						}
						else
						{
							serviceReport.put("scheduledAppointmentsCount", 0);
						}

						serviceReport.put("performedAppointmentsCount", performedAppointments);
						serviceReport.put("canceledAppointmentsCount", canceledAppointments);
						serviceReport.put("totalRevenue", totalRevenue);

						basedOnService.add(serviceReport);
					}
				}
			}
			if (status == 0)
			{
				return null;
			}
			else
			{
				return basedOnService;
			}
		}
		else
		{
			return null;
		}

	}

	public Object weeklyReportofPublisher(AppointmentBean appointmentBean)
	{
		PublisherBusiness pbData = getPublisherBusinessData(appointmentBean.getBusinessId());

		Object result = null;

		if (pbData != null)
		{
			Calendar cal = Calendar.getInstance();
			cal.setTime(appointmentBean.getStartScheduledTime());
			cal.add(Calendar.DAY_OF_YEAR, -7);

			Date startDate = cal.getTime();
			Date endDate = null;

			List<Object> week = new ArrayList<>();

			for (int i = 0; i < 7; i++)
			{
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(startDate);
				calendar.add(Calendar.DATE, 1);

				endDate = calendar.getTime();
				appointmentBean.setStartScheduledTime(startDate);
				appointmentBean.setEndScheduledTime(endDate);

				logger.info(
				        "" + appointmentBean.getStartScheduledTime() + "-----" + appointmentBean.getEndScheduledTime());

				Object day = reportFromDateToDate(appointmentBean);

				if (day == "noService")
				{
					return "noService";
				}
				else
				{
					week.add(day);
				}

				startDate = endDate;
			}

			result = week;

			return result;
		}
		else
		{
			return result;
		}
	}

	public Object monthlyReportofPublisher(AppointmentBean appointmentBean)
	{
		PublisherBusiness pbData = getPublisherBusinessData(appointmentBean.getBusinessId());

		Object result = null;

		if (pbData != null)
		{
			List<Object> finalResult = new ArrayList<>();

			Calendar c1 = Calendar.getInstance();
			c1.setTime(appointmentBean.getStartScheduledTime());
			c1.set(Calendar.DAY_OF_MONTH, 1);

			Calendar c2 = Calendar.getInstance();

			for (int month = 0; month < 12; month++)
			{
				c1.set(Calendar.MONTH, month);
				Date startDate = c1.getTime();
				appointmentBean.setStartScheduledTime(startDate);

				logger.info("THE START DATE IS-----> " + startDate.toString());

				c2.setTime(startDate);
				c2.add(Calendar.MONTH, 1);

				Date endDate = c2.getTime();
				appointmentBean.setEndScheduledTime(endDate);

				logger.info("THE END DATE IS-----> " + endDate.toString());

				Object singleMonth = reportFromDateToDate(appointmentBean);

				if (singleMonth == "noService")
				{
					return "noService";
				}
				else
				{
					finalResult.add(singleMonth);
				}

			}
			result = finalResult;

			return result;
		}
		else
		{
			return result;
		}
	}

	public Object yearlyReportofPublisher(AppointmentBean appointmentBean)
	{
		PublisherBusiness pbData = getPublisherBusinessData(appointmentBean.getBusinessId());

		if (pbData != null)
		{
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(appointmentBean.getStartScheduledTime());

			int year = calendar.get(Calendar.YEAR);
			calendar.set(year, 0, 1, 0, 0);
			Date startDate = calendar.getTime();
			appointmentBean.setStartScheduledTime(startDate);
			logger.info("START DATE----->" + startDate.toString());

			Calendar calendar2 = Calendar.getInstance();
			calendar2.setTime(startDate);
			calendar2.add(Calendar.YEAR, 1);

			Date endDate = calendar2.getTime();
			appointmentBean.setEndScheduledTime(endDate);
			logger.info("END DATE------>" + endDate.toString());

			Object yearReport = reportFromDateToDate(appointmentBean);

			if (yearReport == "noService")
			{
				return "noService";
			}
			else
			{
				return yearReport;
			}

		}
		else
		{
			return "invalid";
		}
	}

	public Object pBusinessConsumerwiseBypbId(String pbId) throws Exception
	{

		PublisherBusiness pBData = getPublisherBusinessData(pbId);
		int flag = 0;
		// PublisherBusiness tmp = new PublisherBusiness();

		if (pBData != null)
		{

			List<PublisherBusinessEmployee> empList = this.pBEmpService.employeeList(pBData.getId(),
			        pBData.getPublisherId());

			if (empList.size() > 0)
			{

				List<ServiceCategory> tmp = null;

				if (pBData.getServiceCategory().size() > 0)
				{
					for (int i = 0; i < pBData.getServiceCategory().size(); i++)
					{
						tmp = toRemoveServiceCatAndService(pBData.getServiceCategory(), pBData.getId());
					}
				}

				if (tmp.size() > 0)
				{
					tmp = toRemoveServiceCatAndService(tmp, pBData.getId());
				}

				return pBData;
			}

			else
			{
				return "NOEMP";
			}

		}
		else
		{
			return "INVALID";
		}

	}

	private List<ServiceCategory> toRemoveServiceCatAndService(List<ServiceCategory> serviceCategory, String bId)
	{

		for (int i = 0; i < serviceCategory.size(); i++)
		{

			if (serviceCategory.get(i).getService().size() > 0)
			{

				logger.info("Service Size   : " + serviceCategory.get(i).getService().size());

				for (int j = 0; j < serviceCategory.get(i).getService().size(); j++)
				{

					List<PublisherBusinessEmployee> emp = this.pBEmpService.getEmpDetailsToPerformParticularService(bId,
					        serviceCategory.get(i).getService().get(j).getId());

					logger.info("Emp Count : " + emp.size() + " For thr service Id ---"
					        + serviceCategory.get(i).getService().get(j).getId());

					if (emp.size() <= 0)
					{
						serviceCategory.get(i).getService().remove(j);
					}

					logger.info("Service Size  after   : " + serviceCategory.get(i).getService().size());

				}
			}

			else
			{
				logger.info("Removed SerCat ---" + serviceCategory.get(i).getId());
				serviceCategory.remove(i);
			}
		}

		return serviceCategory;

	}

	public List<Messages> listOfMessagesByPId(PublisherBusiness messageOb)
	{
		Query query = new Query();

		query.addCriteria(Criteria.where("bId").is(messageOb.getBusinessId()).orOperator(
		        Criteria.where("uId").is(messageOb.getPublisherId()),
		        Criteria.where("receiverID").is(messageOb.getPublisherId())));

		query.with(new Sort(new Order(Direction.DESC, "createdTime")));

		return this.mongoTemplate.find(query, Messages.class);
	}

	public Object sendNotificationsToAllConsumerOfBusiness(Messages messageOb) throws Exception
	{

		if (messageOb != null)
		{
			if (messageOb.getuId() != null && messageOb.getbId() != null && messageOb.getMessage() != null)
			{

				if (messageOb.getMessage().length() > 0)
				{

					PublisherBusiness pbData = this.getPublisherBusinessData(messageOb.getbId());
					if (pbData != null)
					{

						List<ConsumerBusinessDetails> consumersList = toGetConsumerListBasedOnBusinesId(
						        messageOb.getbId());

						if (consumersList != null && consumersList.size() > 0)
						{

							// send notification to each consumer
							return this.sendNotificationToAllConsumers(pbData, consumersList, messageOb.getMessage());
						}
					}

				}
			}
		}

		return "Fail";

	}

	public List<ConsumerBusinessDetails> toGetConsumerListBasedOnBusinesId(String bId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("businesses").in(bId));

		return this.mongoTemplate.find(query, ConsumerBusinessDetails.class);

	}

	public String sendNotificationToAllConsumers(PublisherBusiness pbData, List<ConsumerBusinessDetails> consumers,
	        String message) throws Exception
	{
		List<Messages> messageList = new ArrayList<>();
		List<String> tokenList = new ArrayList<>();

		User consumerData = null;

		for (int i = 0, j = 0; i < consumers.size(); i++)
		{
			consumerData = userService.getUserById(consumers.get(i).getId());

			if (consumerData != null)
			{
				Messages msg = new Messages();
				if ((consumerData.getStatus() == 0) && (consumerData.getToken() != null))
				{

					String title = pbData.getName();

					msg.setTitle(title);
					msg.setType(0);

					Date dateNow = new Date();

					 DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
					 formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC")); // UTC timezone
					
					 logger.info("Date UTC ---" + formatterUTC.format(dateNow));

					msg.setuId(pbData.getPublisherId());
					msg.setbId(pbData.getId());
					msg.setReceiverID(consumers.get(i).getId());
					msg.setMessage(message);
					msg.setFrom(pbData.getName());
					msg.setTo(consumerData.getDeviceID());
					msg.setType(1);
					msg.setCreatedTime(dateNow);

					messageList.add(msg);
					tokenList.add(consumerData.getToken());

				}
			}

		}

		return fcm.sendNotification(tokenList, messageList, 1);

	}

	public Object raiseRequest(RaiseRequest raiseReq)
	{
		this.raiseRequest.save(raiseReq);
		return "SUCCESS";
	}

	public Object getServiceBasedRevenueReport(AppointmentBean appointmentBean)
	{
		Object result = null;

		if (appointmentBean != null)
		{
			if (appointmentBean.getBusinessId() != null && appointmentBean.getType() != null)
			{

				Query query = new Query();
				query.addCriteria(Criteria.where("id").is(appointmentBean.getBusinessId()).and("status").is(0));

				PublisherBusiness pbData = this.mongoTemplate.findOne(query, PublisherBusiness.class);

				if (pbData != null)
				{
					addNaming(pbData);

					if (appointmentBean.getType().equalsIgnoreCase("daily"))
					{
						result = serviceBasedDailyReport(pbData);
					}
					else if (appointmentBean.getType().equalsIgnoreCase("weekly"))
					{
						result = serviceBasedWeeklyReport(pbData);
					}
					else if (appointmentBean.getType().equalsIgnoreCase("monthly"))
					{
						result = serviceBasedMonthlyReport(pbData);
					}
					else if (appointmentBean.getType().equalsIgnoreCase("yearly"))
					{
						result = serviceBasedYearlyReport(pbData);
					}
					else
					{
						result = "INVALID_TYPE";
					}

					return result;
				}
				else
				{
					result = "INVALID_BUSINESSID";
				}

			}
			else
			{
				result = "INVALID";
			}
		}
		else
		{
			result = "INVALID";
		}

		return result;
	}

	private Object serviceBasedYearlyReport(PublisherBusiness pbData)
	{
		List<Object> result = new ArrayList<>();
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		int year = cal.get(Calendar.YEAR);
		cal.set(year, 0, 1, 0, 0);
		Date start = cal.getTime();

		for (int i = 0; i < 12; i++)
		{
			Map<String, Object> year1 = new HashMap<>();

			cal.add(Calendar.MONTH, 1);
			Date end = cal.getTime();

			if (pbData.getServiceCategory() != null && pbData.getServiceCategory().size() > 0)
			{
				List<Map<String, Object>> dayRevenue = getServiceBasedRevenue(start, end, pbData);

				year1.put("data", dayRevenue);
			}
			year1.put("name", new SimpleDateFormat("MMMM").format(start));
			year1.put("businessId", pbData.getId());

			result.add(year1);

			start = end;
		}

		return result;
	}

	private Object serviceBasedMonthlyReport(PublisherBusiness pbData)
	{
		List<Object> result = new ArrayList<>();

		Date date = new Date();
		Calendar cal2 = Calendar.getInstance();
		cal2.setTime(date);
		cal2.set(Calendar.DAY_OF_MONTH, 1);
		cal2.set(Calendar.HOUR_OF_DAY, 0);
		cal2.set(Calendar.MINUTE, 0);

		Calendar cal3 = Calendar.getInstance();

		int year = cal2.get(Calendar.YEAR);
		if (year % 4 == 0)
		{
			Date start1 = cal2.getTime();
			for (int i1 = 0; i1 < 4; i1++)
			{
				Map<String, Object> month = new HashMap<>();
				cal3.setTime(start1);
				cal3.add(Calendar.DAY_OF_MONTH, 7);

				Date end1;
				if (i1 == 3)
				{
					cal2.add(Calendar.MONTH, 1);
					end1 = cal2.getTime();
				}
				else
				{
					end1 = cal3.getTime();
				}
				logger.info("WEEK" + (i1 + 1) + "--->" + start1);
				logger.info("WEEK" + (i1 + 1) + "--->" + end1);

				if (pbData.getServiceCategory() != null && pbData.getServiceCategory().size() > 0)
				{
					List<Map<String, Object>> dayRevenue = getServiceBasedRevenue(start1, end1, pbData);

					month.put("data", dayRevenue);
				}
				month.put("name", "week" + (i1 + 1));
				month.put("businessId", pbData.getId());

				result.add(month);

				start1 = end1;
			}
		}
		else
		{
			Date start1 = cal2.getTime();
			for (int i1 = 0; i1 < 5; i1++)
			{
				Map<String, Object> month = new HashMap<>();
				cal3.setTime(start1);
				cal3.add(Calendar.DAY_OF_MONTH, 7);

				Date end1;
				if (i1 == 4)
				{
					cal2.add(Calendar.MONTH, 1);
					end1 = cal2.getTime();
				}
				else
				{
					end1 = cal3.getTime();
				}
				logger.info("WEEK" + (i1 + 1) + "--->" + start1);
				logger.info("WEEK" + (i1 + 1) + "--->" + end1);

				if (pbData.getServiceCategory() != null && pbData.getServiceCategory().size() > 0)
				{
					List<Map<String, Object>> dayRevenue = getServiceBasedRevenue(start1, end1, pbData);

					month.put("data", dayRevenue);
				}
				month.put("name", "week" + (i1 + 1));
				month.put("businessId", pbData.getId());

				result.add(month);

				start1 = end1;
			}
		}

		return result;
	}

	private Object serviceBasedDailyReport(PublisherBusiness pbData)
	{
		List<Object> result = new ArrayList<>();

		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		Date start = cal.getTime();

		cal.add(Calendar.DAY_OF_YEAR, 1);
		Date end = cal.getTime();

		logger.info("START DATE--->" + start);
		logger.info("END DATE--->" + end);

		Map<String, Object> day = new HashMap<>();

		String businessId = pbData.getId();
		if (pbData.getServiceCategory() != null && pbData.getServiceCategory().size() > 0)
		{
			List<Map<String, Object>> dayRevenue = new ArrayList<>();
			for (int i1 = 0; i1 < pbData.getServiceCategory().size(); i1++)
			{
				if (pbData.getServiceCategory().get(i1).getService() != null
				        && pbData.getServiceCategory().get(i1).getService().size() > 0)
				{
					for (int j = 0; j < pbData.getServiceCategory().get(i1).getService().size(); j++)
					{
						String serviceId = pbData.getServiceCategory().get(i1).getService().get(j).getId();
						Query query = new Query();
						query.addCriteria(Criteria.where("businessId").is(businessId)
						        .andOperator(Criteria.where("serviceId").is(serviceId).and("startScheduledTime")
						                .gte(start).and("endScheduledTime").lte(end).and("status").is(2)));
						List<AppointmentCalendar> appointments = this.mongoTemplate.find(query,
						        AppointmentCalendar.class);

						Double revenue = 0.0;
						if (appointments != null && appointments.size() > 0)
						{
							for (int k = 0; k < appointments.size(); k++)
							{
								revenue = revenue + appointments.get(k).getPrice();
							}
						}
						Map<String, Object> serviceRevenue = new HashMap<>();

						serviceRevenue.put("service",
						        pbData.getServiceCategory().get(i1).getService().get(j).getName());
						serviceRevenue.put("revenue", revenue);

						dayRevenue.add(serviceRevenue);
					}
				}
			}

			day.put("data", dayRevenue);

		}
		day.put("name", new SimpleDateFormat("dd-MM-yyyy").format(start));
		day.put("businessId", businessId);

		result.add(day);

		return result;
	}

	private Object serviceBasedWeeklyReport(PublisherBusiness pbData)
	{
		List<Object> result = new ArrayList<>();

		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		int day = cal.get(Calendar.DAY_OF_WEEK) - cal.getFirstDayOfWeek();
		cal.add(Calendar.DATE, -day);
		Date start = cal.getTime();

		for (int i = 0; i < 7; i++)
		{
			Map<String, Object> week = new HashMap<>();

			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(start);
			cal2.add(Calendar.DATE, 1);
			Date end = cal2.getTime();

			logger.info("START DATE--->" + start);
			logger.info("END DATE--->" + end);

			String businessId = pbData.getId();
			if (pbData.getServiceCategory() != null && pbData.getServiceCategory().size() > 0)
			{
				List<Map<String, Object>> dayRevenue = getServiceBasedRevenue(start, end, pbData);

				week.put("data", dayRevenue);
			}

			week.put("name", new SimpleDateFormat("dd-MM-yyyy").format(start));
			week.put("businessId", businessId);

			result.add(week);
			start = end;
		}

		return result;
	}

	private List<Map<String, Object>> getServiceBasedRevenue(Date start, Date end, PublisherBusiness pbData)
	{
		List<Map<String, Object>> dayRevenue = new ArrayList<>();

		String businessId = pbData.getId();
		for (int i1 = 0; i1 < pbData.getServiceCategory().size(); i1++)
		{
			if (pbData.getServiceCategory().get(i1).getService() != null
			        && pbData.getServiceCategory().get(i1).getService().size() > 0)
			{
				for (int j = 0; j < pbData.getServiceCategory().get(i1).getService().size(); j++)
				{
					String serviceId = pbData.getServiceCategory().get(i1).getService().get(j).getId();
					Query query = new Query();
					query.addCriteria(Criteria.where("businessId").is(businessId)
					        .andOperator(Criteria.where("serviceId").is(serviceId).and("startScheduledTime").gte(start)
					                .and("endScheduledTime").lte(end).and("status").is(2)));
					List<AppointmentCalendar> appointments = this.mongoTemplate.find(query, AppointmentCalendar.class);

					Double revenue = 0.0;
					if (appointments != null && appointments.size() > 0)
					{
						for (int k = 0; k < appointments.size(); k++)
						{
							revenue = revenue + appointments.get(k).getPrice();
						}
					}
					Map<String, Object> serviceRevenue = new HashMap<>();

					serviceRevenue.put("service", pbData.getServiceCategory().get(i1).getService().get(j).getName());
					serviceRevenue.put("revenue", revenue);

					dayRevenue.add(serviceRevenue);

				}
			}
		}

		return dayRevenue;
	}

	public Object getRaiseRequest()
	{
		Query query = new Query();

		return this.mongoTemplate.find(query, RaiseRequest.class);

	}

}

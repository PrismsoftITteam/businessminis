package com.businessApp.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;
import java.util.TreeMap;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.businessApp.bean.AddPto;
import com.businessApp.bean.Appointment;
import com.businessApp.bean.AppointmentBean;
import com.businessApp.bean.ConsumerAppointmentBean;
import com.businessApp.bean.Employees;
import com.businessApp.bean.GetAppoinmentPublisherBean;
import com.businessApp.bean.GetAppointmentConsumerBean;
import com.businessApp.bean.Hours;
import com.businessApp.bean.PublisherBusinessServices;
import com.businessApp.bean.Services;
import com.businessApp.model.AppointmentCalendar;
import com.businessApp.model.BusinessBreakConfig;
import com.businessApp.model.BusinessHours;
import com.businessApp.model.ConsumerBusinessDetails;
import com.businessApp.model.EmployeePto;
import com.businessApp.model.Messages;
import com.businessApp.model.Pto;
import com.businessApp.model.PublisherBusiness;
import com.businessApp.model.PublisherBusinessEmployee;
import com.businessApp.model.TrackReport;
import com.businessApp.model.User;
import com.businessApp.model.UserLoginDevices;
import com.businessApp.repositories.PublisherAppointmentCalenderRepository;
import com.businessApp.repositories.PublisherBusinessEmpPtoRepository;
import com.businessApp.repositories.PublisherBusinessEmployeeRepository;
import com.mongodb.BasicDBObject;
import com.mongodb.WriteResult;

@Service
public class PublisherBusinessEmployeeService
{
	private static Logger logger = LoggerFactory.getLogger(PublisherBusinessEmployeeService.class);

	List<Integer> details = new ArrayList<>();

	@Autowired
	PublisherBusinessEmployeeRepository pubBusEmpRepo;
	@Autowired
	PublisherAppointmentCalenderRepository pubAppCal;

	@Autowired
	PublisherBusinessEmpPtoRepository pubPto;

	@Autowired
	GetAppointmentConsumerBean getAppBean;

	@Autowired
	PublisherService pubService;

	@Autowired
	UserService userService;

	@Autowired
	MongoTemplate mongoTemplate;

	@Autowired
	AndroidPushNotificationsService fcm;

	@Autowired
	Messages message;
	@Autowired
	AppointmentBean appBean;

	@Autowired
	TrackReport trackReport;

	/**
	 * To Create the Publisher Employee to the given employee Object
	 * 
	 * @param publBusinessEmployee
	 */
	public PublisherBusinessEmployee save(PublisherBusinessEmployee publBusinessEmployee)
	{
		return this.pubBusEmpRepo.save(publBusinessEmployee);

	}

	/**
	 * @param PublisherBusinessEmployee
	 * @return List of Employees based on BussId and PublisherId
	 * @throws Exception
	 */
	public List<PublisherBusinessEmployee> employeeList(String bId, String pubId) throws Exception

	{

		PublisherBusiness pbData = getBusinessDetails(bId, pubId);

		if (pbData != null)
		{
			Query query = new Query(Criteria.where("publisherId").is(pubId)
			        .andOperator(Criteria.where("businessId").is(bId).and("status").is(0)));

			List<PublisherBusinessEmployee> pBEmpList = this.mongoTemplate.find(query, PublisherBusinessEmployee.class);

			List<PublisherBusinessEmployee> employeeList = new ArrayList<>();

			PublisherBusinessEmployee tmp;

			if ((pBEmpList.size()) > 0 && (pBEmpList != null))
			{

				for (PublisherBusinessEmployee pBEmp : pBEmpList)
				{
					tmp = addServiceNaming(pBEmp);
					employeeList.add(tmp);
				}
			}

			return employeeList;

		}

		else
		{
			return null;
		}

	}

	private PublisherBusinessEmployee addServiceNaming(PublisherBusinessEmployee pBEmp)
	{

		Query qr = new Query();
		qr.addCriteria(Criteria.where("publisherId").is(pBEmp.getPublisherId())
		        .andOperator(Criteria.where("id").is(pBEmp.getBusinessId())));
		PublisherBusiness pbBus = this.mongoTemplate.findOne(qr, PublisherBusiness.class);

		PublisherBusiness tmp;

		if (pbBus != null)
		{

			tmp = this.pubService.addNaming(pbBus);

			if (tmp.getServiceCategory().size() > 0)
			{

				for (int i = 0; i < pBEmp.getServiceCategory().size(); i++)
				{

					for (int p = 0; p < tmp.getServiceCategory().size(); p++)

					{

						if (pBEmp.getServiceCategory().get(i).getId().equals(tmp.getServiceCategory().get(p).getId()))
						{

							// Assign Service Category Name

							pBEmp.getServiceCategory().get(i).setName(tmp.getServiceCategory().get(p).getName());

							// Assign Service Category Description

							pBEmp.getServiceCategory().get(i)
							        .setDescription(tmp.getServiceCategory().get(p).getDescription());

							for (int j = 0; j < pBEmp.getServiceCategory().get(i).getService().size(); j++)
							{

								for (int q = 0; q < tmp.getServiceCategory().get(p).getService().size(); q++)
								{

									if (tmp.getServiceCategory().get(p).getService().get(q).getId()
									        .equals(pBEmp.getServiceCategory().get(i).getService().get(j).getId()))
									{
										pBEmp.getServiceCategory().get(i).getService().get(j)
										        .setName(tmp.getServiceCategory().get(p).getService().get(q).getName());

										pBEmp.getServiceCategory().get(i).getService().get(j).setDescription(
										        tmp.getServiceCategory().get(p).getService().get(q).getDescription());

										pBEmp.getServiceCategory().get(i).getService().get(j).setDuration(
										        tmp.getServiceCategory().get(p).getService().get(q).getDuration());

										pBEmp.getServiceCategory().get(i).getService().get(j).setPrice(
										        tmp.getServiceCategory().get(p).getService().get(q).getPrice());

									}

								}

							}
						}

					}

				}

			}

		}

		return pBEmp;
	}

	public PublisherBusinessEmployee getEmployeeById(String id)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id).andOperator(Criteria.where("status").is(0)));

		return this.mongoTemplate.findOne(query, PublisherBusinessEmployee.class);
	}

	public List<AppointmentCalendar> getEmpAppointmentsByServiceID(PublisherBusinessEmployee empData, String serviceId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("employeeId").is(empData.getId())
		        .andOperator(Criteria.where("businessId").is(empData.getBusinessId()).and("serviceId").is(serviceId))
		        .and("status").is(0).and("startScheduledTime").gte(new java.util.Date()));
		return this.mongoTemplate.find(query, AppointmentCalendar.class);
	}

	/**
	 * To Update The PublisherBusinessEmployee
	 * 
	 * @param PublisherBusinessEmployee
	 * @return
	 * @throws Exception
	 */

	public String updateEmployee(PublisherBusinessEmployee employeeUpObj) throws Exception
	{
		PublisherBusinessEmployee empData = this.getEmployeeById(employeeUpObj.getId());

		PublisherBusiness pbData = pubService.getPublisherBusinessData(employeeUpObj.getBusinessId());

		if (empData != null)
		{
			if (employeeUpObj != null)
			{
				if (employeeUpObj.getServiceCategory() != null && employeeUpObj.getServiceCategory().size() > 0)
				{
					if (empData.getServiceCategory() != null && empData.getServiceCategory().size() > 0)
					{
						for (int i = 0; i < empData.getServiceCategory().size(); i++)
						{
							for (int j = 0; j < employeeUpObj.getServiceCategory().size(); j++)
							{
								if (empData.getServiceCategory().get(i).getId()
								        .equals(employeeUpObj.getServiceCategory().get(j).getId()))
								{
									if (empData.getServiceCategory().get(i).getService() != null
									        && empData.getServiceCategory().get(i).getService().size() > 0)
									{

										// Remove the employee service

										empData.getServiceCategory().get(i).getService()
										        .removeAll(employeeUpObj.getServiceCategory().get(j).getService());

										// if (empData.getServiceCategory().get(i).getService() != null
										// && empData.getServiceCategory().get(i).getService().size() > 0)
										// {
										// for (int k = 0; k < empData.getServiceCategory().get(i).getService()
										// .size(); k++)
										// {
										// String serviceId = empData.getServiceCategory().get(i).getService()
										// .get(k).getId();
										// List<AppointmentCalendar> appData = this
										// .getEmpAppointmentsByServiceID(empData, serviceId);
										// String message = "Services updated to employee";
										// if (appData != null && appData.size() > 0)
										// {
										// this.deleteAppointments(appData);
										// pubService.sendNotificationForAppointmentCancellation(pbData,
										// appData, message);

										// }
										// }

										// }
									}
								}
							}
						}
					}
				}
			}
		}

		return this.pubBusEmpRepo.updateEmployee(employeeUpObj);
	}

	/**
	 * To delete the particular Employee based on employeeId
	 * 
	 * @param employeeId
	 * @return
	 * @throws Exception
	 */
	public String deleteEmployeeById(String employeeId) throws Exception
	{

		if (employeeId != null)
		{

			PublisherBusinessEmployee empData = getEmpDeatils(employeeId);

			if (empData != null)
			{

				// To Get All Appointments for an employee

				List<AppointmentCalendar> appData = getAllAppointmentForEmployee(empData.getId());

				if (appData != null)
				{
					deleteAppointments(appData);

					// to send notification
					PublisherBusiness pbData = pubService.getPublisherBusinessData(empData.getBusinessId());

					String message = "employee deleted";

					pubService.sendNotificationForAppointmentCancellation(pbData, appData, message);

				}

				// To delete Employee , so we set status=1
				Query query2 = new Query();
				query2.addCriteria(Criteria.where("id").is(employeeId));
				Update upd = new Update();

				upd.set("status", 1);
				WriteResult result = this.mongoTemplate.upsert(query2, upd, PublisherBusinessEmployee.class);

				if (result.getN() > 0)
				{
					return "SUCCESS";
				}

				else
				{
					return "UNSUCCESS";
				}

			}
			else
			{
				return "INVALID";
			}

		}
		else
		{
			return "INVALID";
		}

	}

	public List<AppointmentCalendar> getAllAppointmentForEmployee(String id)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("employeeId").is(id).and("status").is(0));
		return this.mongoTemplate.find(query, AppointmentCalendar.class);
	}

	// public List<AppointmentCalendar>
	// getAllAppointmentForEmployeeFrom_ToDates(String id, List<Date> dates)
	// {
	// Query query = new Query();
	//
	// query.addCriteria(Criteria.where("startScheduledTime").gte(dates.get(0)).and("endScheduledTime")
	// .lt(dates.get(1)).andOperator(Criteria.where("status").is(0).and("employeeId").is(id)));
	// query.with(new Sort(new Order(Direction.ASC, "startScheduledTime")));
	// return this.mongoTemplate.find(query, AppointmentCalendar.class);
	// }

	/**
	 * To save AppointmentCalendar entries
	 * 
	 * @param AppointmentCalendar
	 */
	public void save(AppointmentCalendar calender)
	{
		this.pubAppCal.save(calender);

	}

	/**
	 * 
	 * To Add PTO Details to Particular Employee
	 * 
	 * @param PublisherBusinessEmployee
	 * @throws Exception
	 */
	public Object saveEmployeeTimeOff(EmployeePto pto) throws Exception
	{

		EmployeePto ptoList = EmployeeTimeOffList(pto.getEmpId());

		if (ptoList == null)
		{
			List<Date> dates = new ArrayList<>();
			dates.add(0, pto.getPto().get(0).getStartDate());
			dates.add(1, pto.getPto().get(0).getEndDate());

			List<AppointmentCalendar> appData = getAppoinmentForSeletedDates(pto.getEmpId(), dates);

			if (!appData.isEmpty() && appData.size() > 0)
			{

				PublisherBusiness pbData = pubService.getPublisherBusinessData(appData.get(0).getBusinessId());

				if (pbData != null)
				{
					// logger.info("Business Info ---" + pbData.getName());

					// delete Appointments
					deleteAppointments(appData);

					String message = "employee time off";

					// To send notification
					pubService.sendNotificationForAppointmentCancellation(pbData, appData, message);
				}

			}

			this.pubPto.save(pto);

			return "SUCCESS";
		}
		else
		{

			return ptoList;
		}

	}

	public String addEmployeeTimeOff(AddPto pto)
	{
		String report = "UNSUCCESS";

		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(pto.getId()));

		EmployeePto ptoData = this.mongoTemplate.findOne(query, EmployeePto.class);

		if (ptoData != null)
		{
			report = addPtoToEmployee(pto);
		}

		return report;
	}

	public String updateEmployeeTimeOff(EmployeePto pto) throws Exception
	{

		List<Date> dates = new ArrayList<>();
		dates.add(0, pto.getPto().get(0).getStartDate());
		dates.add(1, pto.getPto().get(0).getEndDate());

		List<AppointmentCalendar> appData = getAppoinmentForSeletedDates(pto.getEmpId(), dates);

		if (!appData.isEmpty() && appData.size() > 0)
		{

			PublisherBusiness pbData = pubService.getPublisherBusinessData(appData.get(0).getBusinessId());

			if (pbData != null)
			{
				// logger.info("Business Info ---" + pbData.getName());

				// delete Appointments
				deleteAppointments(appData);

				String message = "Employee time off";

				// To send notification
				pubService.sendNotificationForAppointmentCancellation(pbData, appData, message);
			}

		}

		return this.pubBusEmpRepo.updateEmployeePto(pto);
	}

	private String addPtoToEmployee(AddPto addPto)
	{

		String s;
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(addPto.getId()));
		Update update = new Update();
		update.addToSet("pto", addPto.getPto());
		EmployeePto add = this.mongoTemplate.findAndModify(query, update, EmployeePto.class);

		if (add != null)
		{
			s = "SUCCESS";
		}
		else
		{
			s = "UNSUCCESS";
		}

		return s;

	}

	public Object listOfServicesBasedAppointmentByDate(AppointmentBean appCla) throws ParseException
	{

		if ((appCla.getPublisherId() != null) && (appCla.getBusinessId() != null)
		        && (appCla.getStartScheduledTime() != null))
		{

			List<PublisherBusinessEmployee> busEempList, finalEmpList;

			List<Integer> details = getAppointmentDetails(appCla);

			PublisherBusiness pbData = getBusinessDetails(appCla.getBusinessId(), appCla.getPublisherId());

			if (pbData != null)
			{

				if (pbData.getBusinessHours().get(this.details.get(3).toString()).getHoliday() == 0)
				{

					// getEmpDetailsToPerformParticularService(appCla);

					busEempList = toCheckEmpWorkingHours(
					        getEmpDetailsToPerformParticularService(appCla.getBusinessId(), appCla.getServiceId()),
					        details);

					if ((busEempList != null) && (busEempList.size() > 0))
					{

						List<Date> date = toConvertDateForPTO(appCla, details);

						finalEmpList = checkPtoDetails(busEempList, date, appCla);

						if ((finalEmpList != null) && (finalEmpList.size() > 0))
						{

							GetAppointmentConsumerBean getApps = getServiceBasedAppointmentDetails(pbData, appCla,
							        details, finalEmpList);

							return getApps;

						}
						else
						{
							return "No_Employee_Found";

						}

					}

					else
					{
						return "No_Employee_Found";

					}

				}

				else
				{
					return "Holiday";
				}

			}

			else
			{
				return "INVALID_BUSINESS";
			}

		}

		else
		{
			return "DETAILS_REQUIRED";

		}
	}

	private List<PublisherBusinessEmployee> toCheckEmpWorkingHours(List<PublisherBusinessEmployee> empData,
	        List<Integer> details)
	{
		List<PublisherBusinessEmployee> empData1 = new ArrayList<>();

		for (int i = 0; i < empData.size(); i++)
		{

			if (empData.get(i).getEmployeeHours().get(this.details.get(3).toString()).getHoliday() == 0)
			{
				empData1.add(empData.get(i));
			}
		}

		return empData1;

	}

	private GetAppointmentConsumerBean getServiceBasedAppointmentDetails(PublisherBusiness pbData,
	        AppointmentBean appCla, List<Integer> details, List<PublisherBusinessEmployee> empList)
	        throws ParseException
	{
		Map<String, ConsumerAppointmentBean> map = new HashMap<>();
		ConsumerAppointmentBean appointments;

		GetAppointmentConsumerBean setBean = new GetAppointmentConsumerBean();

		int open = pbData.getBusinessHours().get(this.details.get(3).toString()).getOpen();

		int close = pbData.getBusinessHours().get(this.details.get(3).toString()).getClose();

		getServiceDetails(pbData, appCla.getServiceId());

		Integer sHour;

		setBean.setBusinessId(pbData.getId());
		setBean.setBusinessStartTime(open);
		setBean.setBusinessEndTime(close);
		setBean.setDate(appCla.getStartScheduledTime());

		logger.info("EMP SIZE---> " + empList.size());

		for (int i = 0; i < empList.size(); i++)
		{
			logger.info(" EMP - " + i + "--->" + empList.get(i).getId() + " AND " + empList.get(i).getFirstName());
		}

		List<String> serviceDetais = getServiceDetails(pbData, appCla.getServiceId());

		for (Integer pbStart = open; pbStart <= close;)
		{

			appointments = new ConsumerAppointmentBean();

			appointments.setAppointmentStartTime(pbStart.toString());
			Integer et = pbStart + Integer.parseInt(serviceDetais.get(1)) - 1;
			appointments.setAppointmentEndTime(et.toString());

			appointments.setServiceId(appCla.getServiceId());

			appointments.setServiceName(serviceDetais.get(0));
			appointments.setEmpCount(empList.size());

			Integer availEmpCount = empAvailCheck(appointments, appCla, empList);

			appointments.setSlots(availEmpCount.toString());

			sHour = pbStart / 60;

			if (sHour < 10)
			{
				map.put("0" + sHour.toString() + ":" + pbStart % 60, appointments);
			}
			else
			{
				map.put(sHour.toString() + ":" + pbStart % 60, appointments);
			}

			pbStart = pbStart + Integer.parseInt(serviceDetais.get(1));

		}

		Map<String, ConsumerAppointmentBean> sortedMap = new TreeMap<>(map);

		setBean.setAppointments(sortedMap);

		return setBean;
	}

	private Integer empAvailCheck(ConsumerAppointmentBean appointments, AppointmentBean appCla,
	        List<PublisherBusinessEmployee> empList) throws ParseException
	{
		Integer count = 0;

		GetAppoinmentPublisherBean empAppointments = (GetAppoinmentPublisherBean) listOfEmpAppointmentsByDate(appCla);

		for (int i = 0; i < empList.size(); i++)
		{

			String sEid = empList.get(i).getId();

			// logger.info("EMP ID----> " + empList.get(i).getId());

			List<Appointment> singleEmpAppointments = new ArrayList<>();

			for (Integer sh = empAppointments.getBusinessStartTime(); sh <= empAppointments.getBusinessEndTime(); sh++)
			{
				empAppointments.getHours().get(sh).getEmployees();
				for (int j = 0; j < empAppointments.getHours().get(sh).getEmployees().size(); j++)
				{
					if (empAppointments.getHours().get(sh).getEmployees().get(j).getEmpId().equals(sEid))
					{

						singleEmpAppointments
						        .addAll(empAppointments.getHours().get(sh).getEmployees().get(j).getAppointment());
					}
				}
			}

			// logger.info("NO. OF APPOINTMENTS OF " + sEid + " ARE----> "
			// + singleEmpAppointments.size());

			List<Integer> availTime = new ArrayList<>();

			for (int k = 0; k < singleEmpAppointments.size(); k++)
			{
				// logger.info("APPOINTMENT TYPE---> "
				// + singleEmpAppointments.get(k).getType() + "@@@@@ "
				// + singleEmpAppointments.get(k).getAppointmentStartTime()
				// + " "
				// + singleEmpAppointments.get(k).getAppointmentEndTime());

				if (singleEmpAppointments.get(k).getType().equals("NoBooking"))
				{
					int temp1 = singleEmpAppointments.get(k).getAppointmentStartTime();
					while (temp1 <= singleEmpAppointments.get(k).getAppointmentEndTime())
					{
						availTime.add(temp1);

						temp1++;
					}
				}
			}

			List<Integer> aptTime = new ArrayList<>();

			int temp2 = Integer.parseInt(appointments.getAppointmentStartTime());
			int aptEnd = Integer.parseInt(appointments.getAppointmentEndTime());

			while (temp2 <= aptEnd)
			{
				aptTime.add(temp2);
				temp2++;
			}

			logger.info("" + availTime.size());
			aptTime.removeAll(availTime);

			logger.info("" + aptTime.size());
			if (aptTime.size() == 0)
			{
				count = count + 1;
			}
			else
			{
				count = count + 0;
			}

			aptTime.clear();
			availTime.clear();
		}

		return count;
	}

	public List<PublisherBusinessEmployee> getEmpDetailsToPerformParticularService(String bId, String serviceIds)
	{

		ObjectId serviceId = new ObjectId(serviceIds);

		Query query = new Query();
		query.addCriteria(Criteria.where("businessId").is(bId)
		        .andOperator(Criteria.where("serviceCategory.service.id").is(serviceId).and("status").is(0)));
		List<PublisherBusinessEmployee> empData = this.mongoTemplate.find(query, PublisherBusinessEmployee.class);

		return empData;

	}

	/**
	 * 
	 * To Listing all Appointments details based on Date and publisherId
	 * 
	 * @param AppointmentCalendar
	 * @return List of Appointments
	 * @throws ParseException
	 */
	public Object listOfEmpAppointmentsByDate(AppointmentBean appCla) throws ParseException
	{

		if ((appCla.getPublisherId() != null) && (appCla.getBusinessId() != null)
		        && (appCla.getStartScheduledTime() != null))
		{

			List<PublisherBusinessEmployee> busEempList, finalPTOList;

			List<Integer> details = getAppointmentDetails(appCla);

			PublisherBusiness pbData = getBusinessDetails(appCla.getBusinessId(), appCla.getPublisherId());

			if (pbData != null)
			{

				if (pbData.getBusinessHours().get(this.details.get(3).toString()).getHoliday() == 0)
				{

					busEempList = employeeCount(appCla.getBusinessId(), appCla.getPublisherId(), details);

					if ((busEempList != null) && (busEempList.size() > 0))
					{

						List<Date> date = toConvertDateForPTO(appCla, details);

						finalPTOList = checkPtoDetails(busEempList, date, appCla);

						if ((finalPTOList != null) && (finalPTOList.size() > 0))
						{

							BusinessBreakConfig breakConfig = getBusinessBreakDetails(pbData.getId());

							List<AppointmentCalendar> apponitments = getAppoinmentsOfADay(appCla, pbData);
							if ((apponitments != null))
							{

								if (breakConfig != null)
								{

									if (breakConfig.getBreakStatus() == 1)
									{
										List<AppointmentCalendar> empBreaks = empBreakConfiguration(pbData,
										        finalPTOList, details, appCla, breakConfig);
										if (!(empBreaks.isEmpty()))
										{
											apponitments.addAll(empBreaks);
										}
									}
								}

								List<AppointmentCalendar> dummyObject = toFillEmpGapBusinessHourToEmpStartHourWithEmptyObjects(
								        finalPTOList, pbData, appCla);

								apponitments.addAll(dummyObject);

								List<AppointmentCalendar> splitList = splitAppointmentList(apponitments);

								Collections.sort(finalPTOList,
								        PublisherBusinessEmployee.PublisherBusinessEmployeePriority);

								GetAppoinmentPublisherBean getApps = getEmpAppointmentDetails(splitList, pbData, appCla,
								        details, finalPTOList);

								return getApps;

							}
							else
							{
								return "NO_APPOINTMENTS";
							}
						}
						else
						{

							return "No_Employee_Found";

						}

					}

					else
					{

						return "No_Employee_Found";

					}

				}

				else
				{
					return "Holiday";
				}

			}

			else
			{
				return "INVALID_BUSINESS";
			}

		}

		else
		{
			return "DETAILS_REQUIRED";

		}

	}

	private BusinessBreakConfig getBusinessBreakDetails(String id)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("bId").is(id));
		return this.mongoTemplate.findOne(query, BusinessBreakConfig.class);

	}

	private List<AppointmentCalendar> empBreakConfiguration(PublisherBusiness pbData,
	        List<PublisherBusinessEmployee> empList, List<Integer> details, AppointmentBean appCla,
	        BusinessBreakConfig breakConfig)
	{

		List<AppointmentCalendar> temp1 = new ArrayList<>();

		AppointmentCalendar aapp, aapp1;

		List<AppointmentCalendar> appointment = null;

		String brTemp = breakConfig.getFrequency();

		String frq[] = brTemp.split(":");

		int frequency = Integer.parseInt(frq[0]) * 60 + Integer.parseInt(frq[1]);

		int interval = breakConfig.getInterval();

		int empCount = empList.size();

		int breakCase = interval * empCount;

		Integer day = getAppointmentDetails(appCla).get(3);
		int startTime = empList.get(0).getEmployeeHours().get(day.toString()).getOpen();

		int statusForEqual = 0; // to configure break
		int statusForUnequal = 0;

		for (int a = 0; a < empList.size(); a++)
		{

			HashMap<String, BusinessHours> empHours = empList.get(a).getEmployeeHours();

			int empOpen = empHours.get(day.toString()).getOpen();

			if (empOpen != startTime)
			{
				statusForUnequal = statusForUnequal + 1;
			}
			else
			{
				statusForEqual = statusForEqual + 1;
			}
		}

		if (statusForUnequal > statusForEqual)
		{
			if (breakCase <= 60)
			{
				appointment = new ArrayList<>();

				int breakStart;

				int breakEnd;

				int breakStart1;

				int breakEnd1;

				for (int i = 0; i < empList.size(); i++)
				{

					HashMap<String, BusinessHours> eopen = empList.get(i).getEmployeeHours();

					int open = eopen.get(day.toString()).getOpen();
					int close = eopen.get(day.toString()).getClose();

					breakStart = open + frequency;

					aapp = new AppointmentCalendar();

					breakEnd = breakStart + interval - 1;

					Date sDate = appCla.getStartScheduledTime();
					Date eDate = appCla.getStartScheduledTime();

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(eDate);

					calendar.add(Calendar.MINUTE, breakStart);
					Date dateStart = calendar.getTime();

					calendar2.add(Calendar.MINUTE, breakEnd);
					Date dateEnd = calendar2.getTime();

					aapp.setId("");
					aapp.setServiceId("");
					aapp.setBusinessId(pbData.getId());
					aapp.setColour("#FFC7BF");
					aapp.setPublisherId(pbData.getPublisherId());
					aapp.setEmployeeId(empList.get(i).getId());
					aapp.setStatus(-2);
					aapp.setStart(breakStart);
					aapp.setEnd(breakEnd);
					aapp.setStartScheduledTime(dateStart);
					aapp.setEndScheduledTime((dateEnd));

					if (breakStart >= open && breakEnd <= close)
					{
						logger.info("BREAK-1---->" + breakStart + " TO " + breakEnd);
						temp1.add(aapp);
					}

					// second break
					aapp1 = new AppointmentCalendar();

					breakStart1 = breakEnd + frequency + 1;
					breakEnd1 = breakStart1 + interval - 1;

					Date sDate1 = appCla.getStartScheduledTime();
					Date eDate1 = appCla.getStartScheduledTime();

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(sDate1);

					Calendar calendar4 = Calendar.getInstance();
					calendar4.setTime(eDate1);

					calendar3.add(Calendar.MINUTE, breakStart1);
					Date dateStart1 = calendar3.getTime();

					calendar4.add(Calendar.MINUTE, breakEnd1);
					Date dateEnd1 = calendar4.getTime();

					aapp1.setId("");
					aapp1.setServiceId("");
					aapp1.setBusinessId(pbData.getId());
					aapp1.setColour("#FFC7BF");
					aapp1.setPublisherId(pbData.getPublisherId());
					aapp1.setEmployeeId(empList.get(i).getId());
					aapp1.setStatus(-2);
					aapp1.setStart(breakStart1);
					aapp1.setEnd(breakEnd1);
					aapp1.setStartScheduledTime(dateStart1);
					aapp1.setEndScheduledTime(dateEnd1);

					if (breakStart1 >= open && breakEnd1 <= close)
					{
						logger.info("BREAK-2---->" + breakStart1 + " TO " + breakEnd1);
						temp1.add(aapp1);

					}

				}

				appointment.addAll(temp1);

				temp1.clear();

			}

			else
			{

				appointment = new ArrayList<>();

				int breakStart;

				int breakEnd = 0;

				int breakStart1;

				int breakEnd1;

				for (int i = 0; i < empList.size();)
				{

					HashMap<String, BusinessHours> eopen = empList.get(i).getEmployeeHours();

					int open = eopen.get(day.toString()).getOpen();
					int close = eopen.get(day.toString()).getClose();

					breakStart = open + frequency;

					aapp = new AppointmentCalendar();

					breakEnd = breakStart + interval - 1;

					Date sDate = appCla.getStartScheduledTime();
					Date eDate = appCla.getStartScheduledTime();

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(eDate);

					calendar.add(Calendar.MINUTE, breakStart);
					Date dateStart = calendar.getTime();

					calendar2.add(Calendar.MINUTE, breakEnd);
					Date dateEnd = calendar2.getTime();

					aapp.setId("");
					aapp.setServiceId("");
					aapp.setBusinessId(pbData.getId());
					aapp.setColour("#FFC7BF");
					aapp.setPublisherId(pbData.getPublisherId());
					aapp.setEmployeeId(empList.get(i).getId());
					aapp.setStatus(-2);
					aapp.setStart(breakStart);
					aapp.setEnd(breakEnd);
					aapp.setStartScheduledTime(dateStart);
					aapp.setEndScheduledTime((dateEnd));

					if (breakStart >= open && breakEnd <= close)
					{
						logger.info("EMP NAME---->" + empList.get(i).getFirstName());
						logger.info("BREAK-1---->" + breakStart + " TO " + breakEnd);
						temp1.add(aapp);

					}

					aapp1 = new AppointmentCalendar();

					breakStart1 = breakEnd + frequency + 1;
					breakEnd1 = breakStart1 + interval - 1;

					Date sDate1 = appCla.getStartScheduledTime();
					Date eDate1 = appCla.getStartScheduledTime();

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(sDate1);

					Calendar calendar4 = Calendar.getInstance();
					calendar4.setTime(eDate1);

					calendar3.add(Calendar.MINUTE, breakStart1);
					Date dateStart1 = calendar3.getTime();

					calendar4.add(Calendar.MINUTE, breakEnd1);
					Date dateEnd1 = calendar4.getTime();

					aapp1.setId("");
					aapp1.setServiceId("");
					aapp1.setBusinessId(pbData.getId());
					aapp1.setColour("#FFC7BF");
					aapp1.setPublisherId(pbData.getPublisherId());
					aapp1.setEmployeeId(empList.get(i).getId());
					aapp1.setStatus(-2);
					aapp1.setStart(breakStart1);
					aapp1.setEnd(breakEnd1);
					aapp1.setStartScheduledTime(dateStart1);
					aapp1.setEndScheduledTime(dateEnd1);

					if (breakStart1 >= open && breakEnd1 <= close)
					{

						logger.info("BREAK-2---->" + breakStart1 + " TO " + breakEnd1);
						temp1.add(aapp1);

					}

					i = i + 2;

				}

				for (int i = 1; i < empList.size();)
				{

					HashMap<String, BusinessHours> eopen = empList.get(i).getEmployeeHours();

					int open = eopen.get(day.toString()).getOpen();
					int close = eopen.get(day.toString()).getClose();

					breakStart = open + frequency;

					aapp = new AppointmentCalendar();

					breakEnd = breakStart + interval - 1;

					Date sDate = appCla.getStartScheduledTime();
					Date eDate = appCla.getStartScheduledTime();

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(eDate);

					calendar.add(Calendar.MINUTE, breakStart);
					Date dateStart = calendar.getTime();

					calendar2.add(Calendar.MINUTE, breakEnd);
					Date dateEnd = calendar2.getTime();

					aapp.setId("");
					aapp.setServiceId("");
					aapp.setBusinessId(pbData.getId());
					aapp.setColour("#FFC7BF");
					aapp.setPublisherId(pbData.getPublisherId());
					aapp.setEmployeeId(empList.get(i).getId());
					aapp.setStatus(-2);
					aapp.setStart(breakStart);
					aapp.setEnd(breakEnd);
					aapp.setStartScheduledTime(dateStart);
					aapp.setEndScheduledTime((dateEnd));

					if (breakStart >= open && breakEnd <= close)
					{
						logger.info("EMP NAME---->" + empList.get(i).getFirstName());
						logger.info("BREAK-1---->" + breakStart + " TO " + breakEnd);
						temp1.add(aapp);

					}

					aapp1 = new AppointmentCalendar();

					breakStart1 = breakEnd + frequency + 1;
					breakEnd1 = breakStart1 + interval - 1;

					Date sDate1 = appCla.getStartScheduledTime();
					Date eDate1 = appCla.getStartScheduledTime();

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(sDate1);

					Calendar calendar4 = Calendar.getInstance();
					calendar4.setTime(eDate1);

					calendar3.add(Calendar.MINUTE, breakStart1);
					Date dateStart1 = calendar3.getTime();

					calendar4.add(Calendar.MINUTE, breakEnd1);
					Date dateEnd1 = calendar4.getTime();

					aapp1.setId("");
					aapp1.setServiceId("");
					aapp1.setBusinessId(pbData.getId());
					aapp1.setColour("#FFC7BF");
					aapp1.setPublisherId(pbData.getPublisherId());
					aapp1.setEmployeeId(empList.get(i).getId());
					aapp1.setStatus(-2);
					aapp1.setStart(breakStart1);
					aapp1.setEnd(breakEnd1);
					aapp1.setStartScheduledTime(dateStart1);
					aapp1.setEndScheduledTime(dateEnd1);

					if (breakStart1 >= open && breakEnd1 <= close)
					{
						logger.info("BREAK-2---->" + breakStart1 + " TO " + breakEnd1);
						temp1.add(aapp1);

					}

					i = i + 2;

				}

				appointment.addAll(temp1);

				temp1.clear();

			}
		}
		else
		{
			if (breakCase <= 60)
			{
				appointment = new ArrayList<>();

				int breakStart = empList.get(0).getEmployeeHours().get(day.toString()).getOpen() + frequency;
				int breakEnd;
				int breakStart1;
				int breakEnd1;

				for (int i = 0; i < empList.size(); i++)
				{

					HashMap<String, BusinessHours> eopen = empList.get(i).getEmployeeHours();

					int open = eopen.get(day.toString()).getOpen();
					int close = eopen.get(day.toString()).getClose();

					aapp = new AppointmentCalendar();

					breakEnd = breakStart + interval - 1;

					Date sDate = appCla.getStartScheduledTime();
					Date eDate = appCla.getStartScheduledTime();

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(eDate);

					calendar.add(Calendar.MINUTE, breakStart);
					Date dateStart = calendar.getTime();

					calendar2.add(Calendar.MINUTE, breakEnd);
					Date dateEnd = calendar2.getTime();

					aapp.setId("");
					aapp.setServiceId("");
					aapp.setBusinessId(pbData.getId());
					aapp.setColour("#FFC7BF");
					aapp.setPublisherId(pbData.getPublisherId());
					aapp.setEmployeeId(empList.get(i).getId());
					aapp.setStatus(-2);
					aapp.setStart(breakStart);
					aapp.setEnd(breakEnd);
					aapp.setStartScheduledTime(dateStart);
					aapp.setEndScheduledTime((dateEnd));

					if (breakStart >= open && breakEnd <= close)
					{
						logger.info("BREAK-1---->" + breakStart + " TO " + breakEnd);
						temp1.add(aapp);
					}

					// second break
					aapp1 = new AppointmentCalendar();

					breakStart1 = breakEnd + frequency + 1;
					breakEnd1 = breakStart1 + interval - 1;

					Date sDate1 = appCla.getStartScheduledTime();
					Date eDate1 = appCla.getStartScheduledTime();

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(sDate1);

					Calendar calendar4 = Calendar.getInstance();
					calendar4.setTime(eDate1);

					calendar3.add(Calendar.MINUTE, breakStart1);
					Date dateStart1 = calendar3.getTime();

					calendar4.add(Calendar.MINUTE, breakEnd1);
					Date dateEnd1 = calendar4.getTime();

					aapp1.setId("");
					aapp1.setServiceId("");
					aapp1.setBusinessId(pbData.getId());
					aapp1.setColour("#FFC7BF");
					aapp1.setPublisherId(pbData.getPublisherId());
					aapp1.setEmployeeId(empList.get(i).getId());
					aapp1.setStatus(-2);
					aapp1.setStart(breakStart1);
					aapp1.setEnd(breakEnd1);
					aapp1.setStartScheduledTime(dateStart1);
					aapp1.setEndScheduledTime(dateEnd1);

					if (breakStart1 >= open && breakEnd1 <= close)
					{
						logger.info("BREAK-2---->" + breakStart1 + " TO " + breakEnd1);
						temp1.add(aapp1);

					}

					breakStart = breakEnd + 1;

				}

				appointment.addAll(temp1);

				temp1.clear();

			}

			else
			{

				appointment = new ArrayList<>();

				int breakStart = empList.get(0).getEmployeeHours().get(day.toString()).getOpen() + frequency;

				int breakEnd = 0;

				int breakStart1;

				int breakEnd1;

				for (int i = 0; i < empList.size();)
				{
					HashMap<String, BusinessHours> eopen = empList.get(i).getEmployeeHours();

					int open = eopen.get(day.toString()).getOpen();
					int close = eopen.get(day.toString()).getClose();

					aapp = new AppointmentCalendar();

					breakEnd = breakStart + interval - 1;

					Date sDate = appCla.getStartScheduledTime();
					Date eDate = appCla.getStartScheduledTime();

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(eDate);

					calendar.add(Calendar.MINUTE, breakStart);
					Date dateStart = calendar.getTime();

					calendar2.add(Calendar.MINUTE, breakEnd);
					Date dateEnd = calendar2.getTime();

					aapp.setId("");
					aapp.setServiceId("");
					aapp.setBusinessId(pbData.getId());
					aapp.setColour("#FFC7BF");
					aapp.setPublisherId(pbData.getPublisherId());
					aapp.setEmployeeId(empList.get(i).getId());
					aapp.setStatus(-2);
					aapp.setStart(breakStart);
					aapp.setEnd(breakEnd);
					aapp.setStartScheduledTime(dateStart);
					aapp.setEndScheduledTime((dateEnd));

					if (breakStart >= open && breakEnd <= close)
					{
						logger.info("NAME--->" + empList.get(i).getFirstName());
						logger.info("BREAK-1---->" + breakStart + " TO " + breakEnd);
						temp1.add(aapp);

					}

					aapp1 = new AppointmentCalendar();

					breakStart1 = breakEnd + frequency + 1;
					breakEnd1 = breakStart1 + interval - 1;

					Date sDate1 = appCla.getStartScheduledTime();
					Date eDate1 = appCla.getStartScheduledTime();

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(sDate1);

					Calendar calendar4 = Calendar.getInstance();
					calendar4.setTime(eDate1);

					calendar3.add(Calendar.MINUTE, breakStart1);
					Date dateStart1 = calendar3.getTime();

					calendar4.add(Calendar.MINUTE, breakEnd1);
					Date dateEnd1 = calendar4.getTime();

					aapp1.setId("");
					aapp1.setServiceId("");
					aapp1.setBusinessId(pbData.getId());
					aapp1.setColour("#FFC7BF");
					aapp1.setPublisherId(pbData.getPublisherId());
					aapp1.setEmployeeId(empList.get(i).getId());
					aapp1.setStatus(-2);
					aapp1.setStart(breakStart1);
					aapp1.setEnd(breakEnd1);
					aapp1.setStartScheduledTime(dateStart1);
					aapp1.setEndScheduledTime(dateEnd1);

					if (breakStart1 >= open && breakEnd1 <= close)
					{
						logger.info("BREAK-2---->" + breakStart1 + " TO " + breakEnd1);
						temp1.add(aapp1);

					}

					i = i + 2;

				}

				for (int i = 1; i < empList.size();)
				{

					HashMap<String, BusinessHours> eopen = empList.get(i).getEmployeeHours();

					int open = eopen.get(day.toString()).getOpen();
					int close = eopen.get(day.toString()).getClose();

					breakStart = empList.get(0).getEmployeeHours().get(day.toString()).getOpen() + frequency + interval
					        + 1;

					aapp = new AppointmentCalendar();

					breakEnd = breakStart + interval - 1;

					Date sDate = appCla.getStartScheduledTime();
					Date eDate = appCla.getStartScheduledTime();

					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(eDate);

					calendar.add(Calendar.MINUTE, breakStart);
					Date dateStart = calendar.getTime();

					calendar2.add(Calendar.MINUTE, breakEnd);
					Date dateEnd = calendar2.getTime();

					aapp.setId("");
					aapp.setServiceId("");
					aapp.setBusinessId(pbData.getId());
					aapp.setColour("#FFC7BF");
					aapp.setPublisherId(pbData.getPublisherId());
					aapp.setEmployeeId(empList.get(i).getId());
					aapp.setStatus(-2);
					aapp.setStart(breakStart);
					aapp.setEnd(breakEnd);
					aapp.setStartScheduledTime(dateStart);
					aapp.setEndScheduledTime((dateEnd));

					if (breakStart >= open && breakEnd <= close)
					{
						logger.info("NAME--->" + empList.get(i).getFirstName());
						logger.info("BREAK-1---->" + breakStart + " TO " + breakEnd);
						temp1.add(aapp);

					}

					aapp1 = new AppointmentCalendar();

					breakStart1 = breakEnd + frequency + 1;
					breakEnd1 = breakStart1 + interval - 1;

					Date sDate1 = appCla.getStartScheduledTime();
					Date eDate1 = appCla.getStartScheduledTime();

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(sDate1);

					Calendar calendar4 = Calendar.getInstance();
					calendar4.setTime(eDate1);

					calendar3.add(Calendar.MINUTE, breakStart1);
					Date dateStart1 = calendar3.getTime();

					calendar4.add(Calendar.MINUTE, breakEnd1);
					Date dateEnd1 = calendar4.getTime();

					aapp1.setId("");
					aapp1.setServiceId("");
					aapp1.setBusinessId(pbData.getId());
					aapp1.setColour("#FFC7BF");
					aapp1.setPublisherId(pbData.getPublisherId());
					aapp1.setEmployeeId(empList.get(i).getId());
					aapp1.setStatus(-2);
					aapp1.setStart(breakStart1);
					aapp1.setEnd(breakEnd1);
					aapp1.setStartScheduledTime(dateStart1);
					aapp1.setEndScheduledTime(dateEnd1);

					if (breakStart1 >= open && breakEnd1 <= close)
					{
						logger.info("BREAK-2---->" + breakStart1 + " TO " + breakEnd1);
						temp1.add(aapp1);

					}

					i = i + 2;

				}

				appointment.addAll(temp1);

				temp1.clear();

			}
		}

		return appointment;

	}

	// private List<AppointmentCalendar> empBreakConfiguration(
	// PublisherBusiness pbData, List<PublisherBusinessEmployee> empList,
	// List<Integer> details, AppointmentBean appCla,
	// BusinessBreakConfig breakConfig)
	// {
	//
	// List<AppointmentCalendar> temp1 = new ArrayList<>();
	//
	// AppointmentCalendar aapp, aapp1;
	//
	// List<AppointmentCalendar> appointment = null;
	//
	// // String tmp = details.get(3).toString();
	//
	// String brTemp = breakConfig.getFrequency();
	//
	// String frq[] = brTemp.split(":");
	//
	// int frequency = Integer.parseInt(frq[0]) * 60
	// + Integer.parseInt(frq[1]);
	//
	// // int frequency = Integer.parseInt(breakConfig.getFrequency());
	//
	// int interval = breakConfig.getInterval();
	//
	// int empCount = empList.size();
	//
	// int breakCase = interval * empCount;
	//
	// if (breakCase <= 60)
	// {
	// appointment = new ArrayList<>();
	//
	// int breakStart;
	//
	// int breakEnd;
	//
	// int breakStart1;
	//
	// int breakEnd1;
	//
	// for (int i = 0; i < empList.size(); i++)
	// {
	//
	// Integer wd = getAppointmentDetails(appCla).get(3);
	//
	// HashMap<String, BusinessHours> eopen = empList.get(i)
	// .getEmployeeHours();
	//
	// int open = eopen.get(wd.toString()).getOpen();
	// int close = eopen.get(wd.toString()).getClose();
	//
	// breakStart = open + frequency;
	//
	// aapp = new AppointmentCalendar();
	//
	// breakEnd = breakStart + interval - 1;
	//
	// Date sDate = appCla.getStartScheduledTime();
	// Date eDate = appCla.getStartScheduledTime();
	//
	// Calendar calendar = Calendar.getInstance();
	// calendar.setTime(sDate);
	//
	// Calendar calendar2 = Calendar.getInstance();
	// calendar2.setTime(eDate);
	//
	// calendar.add(Calendar.MINUTE, breakStart);
	// Date dateStart = calendar.getTime();
	//
	// calendar2.add(Calendar.MINUTE, breakEnd);
	// Date dateEnd = calendar2.getTime();
	//
	// aapp.setId("");
	// aapp.setServiceId("");
	// aapp.setBusinessId(pbData.getId());
	// aapp.setColour("#FFC7BF");
	// aapp.setPublisherId(pbData.getPublisherId());
	// aapp.setEmployeeId(empList.get(i).getId());
	// aapp.setStatus(-2);
	// aapp.setStart(breakStart);
	// aapp.setEnd(breakEnd);
	// aapp.setStartScheduledTime(dateStart);
	// aapp.setEndScheduledTime((dateEnd));
	//
	// if (breakStart >= open && breakEnd <= close)
	// {
	// temp1.add(aapp);
	//
	// }
	//
	// // second break
	// aapp1 = new AppointmentCalendar();
	//
	// breakStart1 = breakEnd + frequency + 1;
	// breakEnd1 = breakStart1 + interval - 1;
	//
	// Date sDate1 = appCla.getStartScheduledTime();
	// Date eDate1 = appCla.getStartScheduledTime();
	//
	// Calendar calendar3 = Calendar.getInstance();
	// calendar3.setTime(sDate1);
	//
	// Calendar calendar4 = Calendar.getInstance();
	// calendar4.setTime(eDate1);
	//
	// calendar3.add(Calendar.MINUTE, breakStart1);
	// Date dateStart1 = calendar3.getTime();
	//
	// calendar4.add(Calendar.MINUTE, breakEnd1);
	// Date dateEnd1 = calendar4.getTime();
	//
	// aapp1.setId("");
	// aapp1.setServiceId("");
	// aapp1.setBusinessId(pbData.getId());
	// aapp1.setColour("#FFC7BF");
	// aapp1.setPublisherId(pbData.getPublisherId());
	// aapp1.setEmployeeId(empList.get(i).getId());
	// aapp1.setStatus(-2);
	// aapp1.setStart(breakStart1);
	// aapp1.setEnd(breakEnd1);
	// aapp1.setStartScheduledTime(dateStart1);
	// aapp1.setEndScheduledTime(dateEnd1);
	//
	// if (breakStart1 >= open && breakEnd1 <= close)
	// {
	// temp1.add(aapp1);
	//
	// }
	//
	// }
	//
	// appointment.addAll(temp1);
	//
	// temp1.clear();
	//
	// }
	//
	// else
	// {
	//
	// appointment = new ArrayList<>();
	//
	// int breakStart;
	//
	// int breakEnd = 0;
	//
	// int breakStart1;
	//
	// int breakEnd1;
	//
	// for (int i = 0; i < empList.size();)
	// {
	//
	// Integer wd = getAppointmentDetails(appCla).get(3);
	//
	// HashMap<String, BusinessHours> eopen = empList.get(i)
	// .getEmployeeHours();
	//
	// int open = eopen.get(wd.toString()).getOpen();
	// int close = eopen.get(wd.toString()).getClose();
	//
	// breakStart = open + frequency;
	//
	// aapp = new AppointmentCalendar();
	//
	// breakEnd = breakStart + interval - 1;
	//
	// Date sDate = appCla.getStartScheduledTime();
	// Date eDate = appCla.getStartScheduledTime();
	//
	// Calendar calendar = Calendar.getInstance();
	// calendar.setTime(sDate);
	//
	// Calendar calendar2 = Calendar.getInstance();
	// calendar2.setTime(eDate);
	//
	// calendar.add(Calendar.MINUTE, breakStart);
	// Date dateStart = calendar.getTime();
	//
	// calendar2.add(Calendar.MINUTE, breakEnd);
	// Date dateEnd = calendar2.getTime();
	//
	// aapp.setId("");
	// aapp.setServiceId("");
	// aapp.setBusinessId(pbData.getId());
	// aapp.setColour("#FFC7BF");
	// aapp.setPublisherId(pbData.getPublisherId());
	// aapp.setEmployeeId(empList.get(i).getId());
	// aapp.setStatus(-2);
	// aapp.setStart(breakStart);
	// aapp.setEnd(breakEnd);
	// aapp.setStartScheduledTime(dateStart);
	// aapp.setEndScheduledTime((dateEnd));
	//
	// if (breakStart >= open && breakEnd <= close)
	// {
	// temp1.add(aapp);
	//
	// }
	//
	// aapp1 = new AppointmentCalendar();
	//
	// breakStart1 = breakEnd + frequency + 1;
	// breakEnd1 = breakStart1 + interval - 1;
	//
	// Date sDate1 = appCla.getStartScheduledTime();
	// Date eDate1 = appCla.getStartScheduledTime();
	//
	// Calendar calendar3 = Calendar.getInstance();
	// calendar3.setTime(sDate1);
	//
	// Calendar calendar4 = Calendar.getInstance();
	// calendar4.setTime(eDate1);
	//
	// calendar3.add(Calendar.MINUTE, breakStart1);
	// Date dateStart1 = calendar3.getTime();
	//
	// calendar4.add(Calendar.MINUTE, breakEnd1);
	// Date dateEnd1 = calendar4.getTime();
	//
	// aapp1.setId("");
	// aapp1.setServiceId("");
	// aapp1.setBusinessId(pbData.getId());
	// aapp1.setColour("#FFC7BF");
	// aapp1.setPublisherId(pbData.getPublisherId());
	// aapp1.setEmployeeId(empList.get(i).getId());
	// aapp1.setStatus(-2);
	// aapp1.setStart(breakStart1);
	// aapp1.setEnd(breakEnd1);
	// aapp1.setStartScheduledTime(dateStart1);
	// aapp1.setEndScheduledTime(dateEnd1);
	//
	// if (breakStart1 >= open && breakEnd1 <= close)
	// {
	// temp1.add(aapp1);
	//
	// }
	//
	// i = i + 2;
	//
	// }
	//
	// for (int i = 1; i < empList.size();)
	// {
	//
	// Integer wd = getAppointmentDetails(appCla).get(3);
	//
	// HashMap<String, BusinessHours> eopen = empList.get(i)
	// .getEmployeeHours();
	//
	// int open = eopen.get(wd.toString()).getOpen();
	// int close = eopen.get(wd.toString()).getClose();
	//
	// breakStart = open + frequency;
	//
	// aapp = new AppointmentCalendar();
	//
	// breakEnd = breakStart + interval - 1;
	//
	// Date sDate = appCla.getStartScheduledTime();
	// Date eDate = appCla.getStartScheduledTime();
	//
	// Calendar calendar = Calendar.getInstance();
	// calendar.setTime(sDate);
	//
	// Calendar calendar2 = Calendar.getInstance();
	// calendar2.setTime(eDate);
	//
	// calendar.add(Calendar.MINUTE, breakStart);
	// Date dateStart = calendar.getTime();
	//
	// calendar2.add(Calendar.MINUTE, breakEnd);
	// Date dateEnd = calendar2.getTime();
	//
	// aapp.setId("");
	// aapp.setServiceId("");
	// aapp.setBusinessId(pbData.getId());
	// aapp.setColour("#FFC7BF");
	// aapp.setPublisherId(pbData.getPublisherId());
	// aapp.setEmployeeId(empList.get(i).getId());
	// aapp.setStatus(-2);
	// aapp.setStart(breakStart);
	// aapp.setEnd(breakEnd);
	// aapp.setStartScheduledTime(dateStart);
	// aapp.setEndScheduledTime((dateEnd));
	//
	// if (breakStart >= open && breakEnd <= close)
	// {
	// temp1.add(aapp);
	//
	// }
	//
	// aapp1 = new AppointmentCalendar();
	//
	// breakStart1 = breakEnd + frequency + 1;
	// breakEnd1 = breakStart1 + interval - 1;
	//
	// Date sDate1 = appCla.getStartScheduledTime();
	// Date eDate1 = appCla.getStartScheduledTime();
	//
	// Calendar calendar3 = Calendar.getInstance();
	// calendar3.setTime(sDate1);
	//
	// Calendar calendar4 = Calendar.getInstance();
	// calendar4.setTime(eDate1);
	//
	// calendar3.add(Calendar.MINUTE, breakStart1);
	// Date dateStart1 = calendar3.getTime();
	//
	// calendar4.add(Calendar.MINUTE, breakEnd1);
	// Date dateEnd1 = calendar4.getTime();
	//
	// aapp1.setId("");
	// aapp1.setServiceId("");
	// aapp1.setBusinessId(pbData.getId());
	// aapp1.setColour("#FFC7BF");
	// aapp1.setPublisherId(pbData.getPublisherId());
	// aapp1.setEmployeeId(empList.get(i).getId());
	// aapp1.setStatus(-2);
	// aapp1.setStart(breakStart1);
	// aapp1.setEnd(breakEnd1);
	// aapp1.setStartScheduledTime(dateStart1);
	// aapp1.setEndScheduledTime(dateEnd1);
	//
	// if (breakStart1 >= open && breakEnd1 <= close)
	// {
	// temp1.add(aapp1);
	//
	// }
	//
	// i = i + 2;
	//
	// }
	//
	// appointment.addAll(temp1);
	//
	// temp1.clear();
	//
	// }
	//
	// return appointment;
	//
	// }

	private List<AppointmentCalendar> toFillEmpGapBusinessHourToEmpStartHourWithEmptyObjects(
	        List<PublisherBusinessEmployee> empList, PublisherBusiness pbData, AppointmentBean appCla)
	        throws ParseException
	{
		AppointmentCalendar aapp;
		AppointmentCalendar aapp2;
		List<AppointmentCalendar> appointment = null;
		List<AppointmentCalendar> temp1 = new ArrayList<>();
		List<AppointmentCalendar> temp2 = new ArrayList<>();

		int open = pbData.getBusinessHours().get(this.details.get(3).toString()).getOpen();

		int close = pbData.getBusinessHours().get(this.details.get(3).toString()).getClose();

		open = open - (open % 60);
		close = close + (60 - (close % 60));

		// logger.info("Business Start Time : " + open);
		// logger.info("Business End Time : " + close);
		appointment = new ArrayList<>();

		for (int i = 0; i < empList.size(); i++)
		{
			aapp2 = new AppointmentCalendar();
			aapp = new AppointmentCalendar();
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

			sdf2.setTimeZone(TimeZone.getTimeZone("UTC"));

			if ((empList.get(i).getEmployeeHours().get(this.details.get(3).toString()).getOpen() > open))

			{

				Date sDate = appCla.getStartScheduledTime();
				Date eDate = appCla.getStartScheduledTime();

				Calendar calendar = Calendar.getInstance();
				calendar.setTime(sDate);

				Calendar calendar2 = Calendar.getInstance();
				calendar2.setTime(eDate);

				// logger.info("Dates ---" + sDate);

				calendar.add(Calendar.MINUTE, open);
				Date dateStart = calendar.getTime();

				// logger.info("dateStart ---" + dateStart);

				calendar2.add(Calendar.MINUTE,
				        empList.get(i).getEmployeeHours().get(this.details.get(3).toString()).getOpen() - 1);
				Date dateEnd = calendar2.getTime();

				aapp.setId("");
				aapp.setServiceId("");
				aapp.setBusinessId(pbData.getId());
				aapp.setColour("#B4CAE9");
				aapp.setPublisherId(pbData.getPublisherId());
				aapp.setEmployeeId(empList.get(i).getId());
				aapp.setStatus(-3);
				aapp.setStart(open);
				aapp.setEnd(empList.get(i).getEmployeeHours().get(this.details.get(3).toString()).getOpen() - 1);
				aapp.setStartScheduledTime(dateStart);
				aapp.setEndScheduledTime((dateEnd));
				temp1.add(aapp);

			}

			if (empList.get(i).getEmployeeHours().get(this.details.get(3).toString()).getClose() < close)
			{

				Date sDate = appCla.getStartScheduledTime();
				Date eDate = appCla.getStartScheduledTime();

				Calendar calendar = Calendar.getInstance();
				calendar.setTime(sDate);

				Calendar calendar2 = Calendar.getInstance();
				calendar2.setTime(eDate);
				// logger.info("Dates ---" + sDate);

				calendar.add(Calendar.MINUTE,
				        empList.get(i).getEmployeeHours().get(this.details.get(3).toString()).getClose() + 1);
				Date dateStart = calendar.getTime();

				// logger.info("dateStart ---" + dateStart);

				calendar2.add(Calendar.MINUTE, close - 1);
				Date dateEnd = calendar2.getTime();

				// logger.info("dateEnd ---" + dateEnd);

				aapp2.setId("");
				aapp2.setServiceId("");
				aapp2.setBusinessId(pbData.getId());
				aapp2.setColour("#B4CAE9");
				aapp2.setPublisherId(pbData.getPublisherId());
				aapp2.setEmployeeId(empList.get(i).getId());
				aapp2.setStatus(-3);
				aapp2.setStart(empList.get(i).getEmployeeHours().get(this.details.get(3).toString()).getClose() + 1);
				aapp2.setEnd(close - 1);
				aapp2.setStartScheduledTime(dateStart);
				aapp2.setEndScheduledTime(dateEnd);

				temp2.add(aapp2);

				// logger.info("EMP Close Time -------" + empList.get(i)
				// .getEmployeeHours().get(this.details.get(3).toString())
				// .getClose());
				// logger.info("Business close -----" + close);
			}

		}

		appointment.addAll(temp1);
		appointment.addAll(temp2);

		temp1.clear();
		temp2.clear();

		// logger.info(
		// "Dummy Object --------------------------------------------");
		//
		// for (AppointmentCalendar dummy : appointment)
		// {
		// logger.info("Dummy Object ----" + dummy.getEmployeeId() + "------"
		// + dummy.getStart() + "-----" + dummy.getEnd());
		// logger.info("Dates ----" + dummy.getEmployeeId() + "------"
		// + dummy.getStartScheduledTime() + "-----"
		// + dummy.getEndScheduledTime());
		// }

		return appointment;

	}

	private GetAppoinmentPublisherBean getEmpAppointmentDetails(List<AppointmentCalendar> apponitments,
	        PublisherBusiness pbData, AppointmentBean appCla, List<Integer> details,
	        List<PublisherBusinessEmployee> busEempList)
	{
		HashMap<Integer, Hours> map = new HashMap<>();
		Hours hours;

		List<Employees> empList = new ArrayList<>();

		GetAppoinmentPublisherBean setBean = new GetAppoinmentPublisherBean();

		int open = pbData.getBusinessHours().get(this.details.get(3).toString()).getOpen();

		int close = pbData.getBusinessHours().get(this.details.get(3).toString()).getClose();

		int sHour = open / 60;

		int eHour = close / 60;

		int hoursDiff = eHour - sHour;
		int hrr = sHour;
		int hStart = sHour;

		setBean.setBusinessId(pbData.getId());
		setBean.setBusinessStartTime(sHour);
		setBean.setBusinessEndTime(eHour);
		setBean.setNoOfemployee(busEempList.size());
		setBean.setDate(appCla.getStartScheduledTime());

		for (int hour = 0; hour <= hoursDiff; hour++)
		{

			hours = new Hours();
			hours.setTime(Integer.toString(hrr));

			empList = null;
			empList = new ArrayList<>();

			for (int emp = 0; emp < busEempList.size(); emp++)
			{
				Employees employee = new Employees();
				employee.setEmployeeName(busEempList.get(emp).getFirstName());
				employee.setEmpId(busEempList.get(emp).getId());
				empList.add(employee);
			}

			hours.setEmployees(empList);

			map.put(hStart, hours);
			hrr++;
			hStart++;
		}
		setBean.setHours(map);

		GetAppoinmentPublisherBean finalObject = toSetEmpAppoinments(setBean, apponitments);

		toFillEmpNullWithEmptyObjects(finalObject);

		return finalObject;
	}

	private void toFillEmpNullWithEmptyObjects(GetAppoinmentPublisherBean finalObject)
	{

		Appointment aapp = null;
		List<Appointment> appointment = null;

		Map<Integer, Hours> sortedMap = new TreeMap<>(finalObject.getHours());

		for (int hour : sortedMap.keySet())
		{
			Hours hr = sortedMap.get(hour);

			int startTime = hour * 60;
			int endTime = startTime + 59;

			for (int j = 0; j < hr.getEmployees().size(); j++)
			{
				appointment = new ArrayList<>();

				if (hr.getEmployees().get(j).getAppointment() != null)
				{

					if (hr.getEmployees().get(j).getAppointment().isEmpty())
					{
						aapp = new Appointment();

						aapp.setId("");
						aapp.setServiceId("");

						aapp.setType("NoBooking");
						aapp.setAppointmentStartTime(startTime);
						aapp.setAppointmentEndTime(endTime);
						aapp.setColour("#FFFFFF");
						aapp.setEmpId(hr.getEmployees().get(j).getEmpId());
						aapp.setStatus(-1);
						appointment.add(aapp);

						hr.getEmployees().get(j).setAppointment(appointment);
					}
					else
					{

						List<Integer> hourList = new ArrayList<>();
						for (int p = startTime; p <= endTime; p++)
						{
							hourList.add(p);
						}

						List<Integer> appList = new ArrayList<>();
						for (int i = 0; i < hr.getEmployees().get(j).getAppointment().size(); i++)
						{

							if (hr.getEmployees().get(j).getAppointment().get(i).getStatus() == -3)
							{
								hr.getEmployees().get(j).getAppointment().get(i).setType("NoService");
							}

							if (hr.getEmployees().get(j).getAppointment().get(i).getStatus() == -2)
							{
								hr.getEmployees().get(j).getAppointment().get(i).setType("Break");
							}

							int min = hr.getEmployees().get(j).getAppointment().get(i).getAppointmentStartTime();
							int max = hr.getEmployees().get(j).getAppointment().get(i).getAppointmentEndTime();

							for (int q = hr.getEmployees().get(j).getAppointment().get(i)
							        .getAppointmentStartTime(); q <= hr.getEmployees().get(j).getAppointment().get(i)
							                .getAppointmentEndTime(); q++)
							{

								appList.add(q);
							}

						}

						hourList.removeAll(appList);

						if (hourList.size() > 0)
						{

							int lmin = hourList.get(0);
							int lmax;

							for (int k = 0; k < hourList.size(); k++)
							{

								if (k > 0) // k started at index 1
								{
									if (hourList.get(k) - hourList.get(k - 1) > 1)
									{
										lmax = hourList.get(k - 1);

										aapp = new Appointment();
										aapp.setId("");
										aapp.setServiceId("");

										aapp.setType("NoBooking");
										aapp.setAppointmentStartTime(lmin);
										aapp.setAppointmentEndTime(lmax);
										aapp.setColour("#FFFFFF");
										aapp.setEmpId(hr.getEmployees().get(j).getEmpId());
										aapp.setStatus(-1);

										sortedMap.get(hour).getEmployees().get(j).getAppointment().add(0, aapp);

										lmin = hourList.get(k);
									}

									if (k == (hourList.size() - 1))
									{
										lmax = hourList.get(k);

										aapp = new Appointment();
										aapp.setId("");
										aapp.setServiceId("");

										aapp.setType("NoBooking");
										aapp.setAppointmentStartTime(lmin);
										aapp.setAppointmentEndTime(lmax);
										aapp.setColour("#FFFFFF");
										aapp.setEmpId(hr.getEmployees().get(j).getEmpId());
										aapp.setStatus(-1);

										// getAppointment().size()

										sortedMap.get(hour).getEmployees().get(j).getAppointment().add(0, aapp);
									}
								}

							}

						}

					}

				}

				else
				{

					aapp = new Appointment();
					aapp.setId("");
					aapp.setServiceId("");

					aapp.setType("NoBooking");
					aapp.setAppointmentStartTime(startTime);
					aapp.setAppointmentEndTime(endTime);
					aapp.setColour("#FFFFFF");
					aapp.setEmpId(hr.getEmployees().get(j).getEmpId());
					aapp.setStatus(-1);
					appointment.add(aapp);
					hr.getEmployees().get(j).setAppointment(appointment);

				}
				Collections.sort(hr.getEmployees().get(j).getAppointment(), Appointment.AppointmentsSorting);
			}

		}

	}

	private GetAppoinmentPublisherBean toSetEmpAppoinments(GetAppoinmentPublisherBean setBean,
	        List<AppointmentCalendar> apponitments)
	{
		try
		{

			Map<Integer, Hours> sortedMap = new TreeMap<>(setBean.getHours());

			Map<Integer, Map<String, List<Appointment>>> apps = empTimeBasedAppointment(apponitments,
			        setBean.getHours());

			for (int hour : setBean.getHours().keySet())
			{
				Hours hr = setBean.getHours().get(hour);

				for (Employees emps : hr.getEmployees())
				{
					// logger.info("For emps code " + emps.hashCode()
					// + " In the Hour ---" + hour + " EMps " + emps);
					String key = String.valueOf(hour) + ":" + emps.getEmpId();
					if (apps.containsKey(hour))
					{

						Map<String, List<Appointment>> apList = apps.get(hour);

						if (apList.containsKey(key))
						{
							// logger.info("Key ---" + key + "apList --- "
							// + apList.get(key));
							emps.setAppointment(apList.get(key));

						}
					}
					else
					{
						// logger.info("In else block is "+emps.hashCode());
						emps.setAppointment(null);
					}
				}
			}

			// logger.info("After sortedMap " + setBean.getHours());
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return setBean;

	}

	private Map<Integer, Map<String, List<Appointment>>> empTimeBasedAppointment(List<AppointmentCalendar> apponitments,
	        Map<Integer, Hours> hoursMap)
	{

		Map<Integer, Map<String, List<Appointment>>> finalMap = new HashMap<>();

		Map<String, List<Appointment>> appMap = null;

		List<Appointment> appointment = null;

		Appointment aapp = null;

		for (Entry<Integer, Hours> hour : hoursMap.entrySet())
		{
			appMap = new HashMap<>();

			for (int emp = 0; emp < hour.getValue().getEmployees().size(); emp++)
			{

				String key = hour.getKey().toString() + ":" + hour.getValue().getEmployees().get(emp).getEmpId();
				appointment = new ArrayList<>();

				for (int app = 0; app < apponitments.size(); app++)
				{

					int start = apponitments.get(app).getStart() / 60;

					int end = apponitments.get(app).getEnd() / 60;

					if ((start == hour.getKey()) && (end == hour.getKey()))
					{

						if (hour.getValue().getEmployees().get(emp).getEmpId()
						        .equals(apponitments.get(app).getEmployeeId()))
						{
							int startTime = 0, endTime = 0;
							aapp = new Appointment();

							Date sDate = apponitments.get(app).getStartScheduledTime();
							Calendar calendar = Calendar.getInstance();
							calendar.setTime(sDate);

							int hr = calendar.get(Calendar.HOUR_OF_DAY);
							int minute = calendar.get(Calendar.MINUTE);

							startTime = hr * 60 + minute;

							Date eDate = apponitments.get(app).getEndScheduledTime();
							Calendar calendar2 = Calendar.getInstance();
							calendar2.setTime(eDate);

							int hr2 = calendar2.get(Calendar.HOUR_OF_DAY);
							int minute2 = calendar2.get(Calendar.MINUTE);

							endTime = hr2 * 60 + minute2;

							aapp.setId(apponitments.get(app).getId());
							aapp.setServiceId(apponitments.get(app).getServiceId());

							aapp.setType("Booked");
							aapp.setConsumerName(apponitments.get(app).getName());
							aapp.setConsumerPhoneNo(apponitments.get(app).getPhone());
							aapp.setAppointmentStartTime(startTime);
							aapp.setAppointmentEndTime(endTime);
							aapp.setColour(apponitments.get(app).getColour());
							aapp.setServiceName(apponitments.get(app).getServiceName());
							aapp.setStatus(apponitments.get(app).getStatus());
							aapp.setEmpId(apponitments.get(app).getEmployeeId());
							appointment.add(aapp);

						}
						appMap.put(key, appointment);
					}

				}

				if (!appMap.isEmpty())
				{

					finalMap.put(hour.getKey(), appMap);
				}

			}

		}

		Map<Integer, Map<String, List<Appointment>>> sortMap = new TreeMap<>(finalMap);

		removeNulls(sortMap);

		// for (Entry<Integer, Map<String, List<Appointment>>> entry : sortMap
		// .entrySet())
		// {
		//
		// System.out.print("Key" + entry.getKey());
		// for (Entry<String, List<Appointment>> entry2 : entry.getValue()
		// .entrySet())
		// {
		//
		// for (Appointment p : entry2.getValue())
		// {
		// System.out.println(entry2.getKey() + " | Id -- " + p.getId()
		// + " ConsumerName :---" + p.getConsumerName()
		// + " Start Time --" + p.getAppointmentStartTime()
		// + " End Time --" + p.getAppointmentEndTime());
		// }
		//
		// }
		//
		// }
		return sortMap;

	}

	private static <K, V> void removeNulls(Map<Integer, Map<String, List<Appointment>>> sortMap)
	{
		Iterator<Entry<Integer, Map<String, List<Appointment>>>> itr = sortMap.entrySet().iterator();

		while (itr.hasNext())
		{
			Entry<Integer, Map<String, List<Appointment>>> cur = itr.next();
			if (cur.getValue() == null)
			{
				itr.remove();
			}
		}

	}

	private List<AppointmentCalendar> splitAppointmentList(List<AppointmentCalendar> apponitments)
	{
		List<AppointmentCalendar> finalList = new ArrayList<>();

		AppointmentCalendar newApp = null;

		for (int i = 0; i < apponitments.size(); i++)
		{
			int startHour = apponitments.get(i).getStart() / 60;
			int endHour = apponitments.get(i).getEnd() / 60;

			// logger.info(
			// "StarHour : ==" + startHour + " End Hour ---" + endHour);

			int MAX = 59, startRemain = 0;

			int hoursDiff = endHour - startHour;

			if (hoursDiff > 0)
			{

				Date sDate = apponitments.get(i).getStartScheduledTime();

				Date eDate = apponitments.get(i).getEndScheduledTime();

				for (int j = 0; j < hoursDiff; j++)
				{
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(sDate);

					int startMinute = calendar.get(Calendar.MINUTE);
					startRemain = MAX - startMinute;

					calendar.add(Calendar.MINUTE, startRemain);
					Date newDate = calendar.getTime();

					newApp = splitobjects(apponitments.get(i), sDate, newDate);
					finalList.add(newApp);

					Calendar calendar2 = Calendar.getInstance();
					calendar2.setTime(newDate);
					calendar2.add(Calendar.MINUTE, 1);
					Date newDate2 = calendar2.getTime();
					sDate = newDate2;

					Calendar calendar3 = Calendar.getInstance();
					calendar3.setTime(newDate2);

					int hr2 = calendar3.get(Calendar.HOUR_OF_DAY);

					if (hr2 == endHour)
					{
						newApp = splitobjects(apponitments.get(i), sDate, eDate);
						finalList.add(newApp);

					}

				}

			}
			else
			{
				finalList.add(apponitments.get(i));
			}

		}

		// for (AppointmentCalendar app : finalList)
		// {
		// logger.info("Appoit Start Date Time : ----"
		// + app.getStartScheduledTime());
		// logger.info(
		// "Appoit End Date Time : ----" + app.getEndScheduledTime());
		// }

		return finalList;
	}

	private AppointmentCalendar splitobjects(AppointmentCalendar appointment, Date sDate, Date newDate)
	{
		AppointmentCalendar app = new AppointmentCalendar();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(sDate);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(newDate);

		int sHour = calendar.get(Calendar.HOUR_OF_DAY);
		int sminute = calendar.get(Calendar.MINUTE);

		int eHour = calendar2.get(Calendar.HOUR_OF_DAY);
		int eminute = calendar2.get(Calendar.MINUTE);

		int start = sHour * 60 + sminute;
		int end = eHour * 60 + eminute;

		app.setColour(appointment.getColour());
		app.setServiceName(appointment.getServiceName());
		app.setId(appointment.getId());
		app.setServiceId(appointment.getServiceId());
		app.setName(appointment.getName());
		app.setStatus(appointment.getStart());

		app.setBusinessId(appointment.getBusinessId());
		app.setPublisherId(appointment.getPublisherId());
		app.setEmployeeId(appointment.getEmployeeId());
		app.setPhone(appointment.getPhone());
		app.setEmail(appointment.getEmail());
		app.setStartScheduledTime(sDate);
		app.setEndScheduledTime(newDate);
		app.setStart(start);
		app.setEnd(end);
		app.setStatus(appointment.getStatus());

		return app;
	}

	private List<PublisherBusinessEmployee> employeeCount(String businessId, String publisherId, List<Integer> details)
	{

		List<PublisherBusinessEmployee> empList = new ArrayList<>();

		String tmp = details.get(3).toString();

		Query query = new Query();
		query.addCriteria(Criteria.where("businessId").is(businessId).and("publisherId").is(publisherId)
		        .andOperator(Criteria.where("status").is(0)));

		List<PublisherBusinessEmployee> empData = this.mongoTemplate.find(query, PublisherBusinessEmployee.class);

		if ((empData != null) && (empData.size() > 0))
		{

			int status = 0;
			for (PublisherBusinessEmployee emp : empData)
			{

				// logger.info("Employee_Found ---" + emp.getFirstName());

				if (emp.getEmployeeHours().get(tmp).getHoliday() == 0)
				{

					if (emp.getServiceCategory().size() > 0)
					{

						for (int i = 0; i < emp.getServiceCategory().size(); i++)
						{

							for (int j = 0; j < emp.getServiceCategory().get(i).getService().size(); j++)
							{
								status = 1;

							}

						}

					}

					if (status == 1)
					{
						empList.add(emp);
						status = 0;
					}

				}
			}
		}
		return empList;

	}

	private List<AppointmentCalendar> getAppoinmentsOfADay(AppointmentBean appCla, PublisherBusiness pbData)
	{

		Query query = new Query();

		query.addCriteria(Criteria.where("publisherId").is(appCla.getPublisherId()).and("status").nin(3, 4)
		        .andOperator(Criteria.where("startScheduledTime").gte(appCla.getStartScheduledTime())
		                .and("endScheduledTime").lt(appCla.getEndScheduledTime())));
		query.with(new Sort(new Order(Direction.ASC, "startScheduledTime")));

		List<AppointmentCalendar> appList = this.mongoTemplate.find(query, AppointmentCalendar.class);

		for (int ap = 0; ap < appList.size(); ap++)
		{
			for (int i = 0; i < pbData.getServiceCategory().size(); i++)
			{

				for (int j = 0; j < pbData.getServiceCategory().get(i).getService().size(); j++)
				{

					if (appList.get(ap).getServiceId()
					        .equals(pbData.getServiceCategory().get(i).getService().get(j).getId()))
					{

						appList.get(ap).setColour(pbData.getServiceCategory().get(i).getColour());

						appList.get(ap)
						        .setServiceName(pbData.getServiceCategory().get(i).getService().get(j).getName());

					}
				}

			}

		}

		return appList;
	}

	public PublisherBusiness getBusinessDetails(String bId, String pId)
	{
		PublisherBusiness pBData = null;
		int flag = 0;

		Query query = new Query();

		query.addCriteria(
		        Criteria.where("id").is(bId).and("publisherId").is(pId).andOperator(Criteria.where("status").is(0)));

		pBData = this.mongoTemplate.findOne(query, PublisherBusiness.class);

		if (pBData != null)
		{

			if (pBData.getServiceCategory().size() > 0)
			{

				for (int i = 0; i < pBData.getServiceCategory().size(); i++)
				{

					if (pBData.getServiceCategory().get(i).getService().size() > 0)
					{
						for (int j = 0; j < pBData.getServiceCategory().get(i).getService().size(); j++)
						{
							if (pBData.getServiceCategory().get(i).getService().size() >= 1)
							{
								flag = 1;
							}
						}
					}
				}
			}

			if (flag == 1)
			{
				this.pubService.addNaming(pBData);
				flag = 0;
				return pBData;
			}

			else
			{
				return null;
			}

		}

		return null;

	}

	/**
	 * To Create Appointment
	 * 
	 * @param AppointmentBean
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> createAppointment(AppointmentBean appointBean, String appType) throws Exception
	{

		Map<String, String> trackData = new HashMap<>();
		// Tracking Start for appointment Object
		ObjectId id = new ObjectId();
		this.trackReport.setId(id.toString());
		this.trackReport.setCreatedTime(new Date());
		this.trackReport.setRequest(appointBean);
		// Tracking Close

		if ((appointBean.getBusinessId() != null) && (appointBean.getPublisherId() != null)
		        && (appointBean.getServiceId() != null))
		{

			List<PublisherBusinessEmployee> finalEmpServiceList, finalPTOList;

			List<Integer> details = getAppointmentDetails(appointBean);
			List<Date> date = toConvertDateForPTO(appointBean, details);

			PublisherBusiness pbData = getBusinessDetails(appointBean.getBusinessId(), appointBean.getPublisherId());

			if (pbData != null)
			{
				String businessHoursReport = checkBusinessHours(appointBean, details, pbData);

				BusinessBreakConfig breakConfig = getBusinessBreakDetails(appointBean.getBusinessId());

				if ("WorkingDay".equals(businessHoursReport))
				{
					finalEmpServiceList = checkEmployeeServiceDetails(appointBean, details);

					if (finalEmpServiceList != null)
					{
						finalPTOList = checkPtoDetails(finalEmpServiceList, date, appointBean);
						if ((finalPTOList != null) && (finalPTOList.size() > 0))
						{
							Collections.sort(finalPTOList, PublisherBusinessEmployee.PublisherBusinessEmployeePriority);

							List<AppointmentCalendar> empBreaks = new ArrayList<>();

							if (breakConfig.getBreakStatus() == 1)
							{
								empBreaks = empBreakConfiguration(pbData, finalPTOList, details, appointBean,
								        breakConfig);
							}

							List<AppointmentCalendar> noServiceList = toFillEmpGapBusinessHourToEmpStartHourWithEmptyObjects(
							        finalPTOList, pbData, appointBean);

							if (appointBean.getEmpId() == null)
							{

								// String report = null;
								for (PublisherBusinessEmployee emp : finalPTOList)
								{

									trackData = toCheckEmpAvailabilityAtThatTime(emp, appointBean, date, details,
									        empBreaks, noServiceList, this.trackReport);

									if (trackData.containsKey("message"))
									{

										if ("SUCCESS".equals(trackData.get("message")))
										{

											trackData = saveAppointment(emp.getId(), appointBean, details, pbData,
											        this.trackReport);

											break;
										}
									}

								}
								return trackData;

								// return report;
							} // empId Check

							else
							{
								// String report = null;
								List<PublisherBusinessEmployee> empList = new ArrayList<>();

								Query query = new Query();
								query.addCriteria(Criteria.where("id").is(appointBean.getEmpId()));

								PublisherBusinessEmployee emp = this.mongoTemplate.findOne(query,
								        PublisherBusinessEmployee.class);
								empList.add(emp);

								if (emp != null)
								{

									trackData = toCheckEmpAvailabilityAtThatTime(emp, appointBean, date, details,
									        empBreaks, noServiceList, this.trackReport);

									if (trackData.containsKey("message"))
									{
										if ("SUCCESS".equals(trackData.get("message")))
										{
											trackData = saveAppointment(appointBean.getEmpId(), appointBean, details,
											        pbData, this.trackReport);
										}

									}

								}

								return trackData;
								// return report;

							}

						} // finalPTOList ckeck

						else
						{
							trackData.put("message", "LIST_EMPTY");
							trackData.put("trackId", id.toString());
							this.mongoTemplate.save(this.trackReport);
							return trackData;

							// return "LIST_EMPTY";
						}

					}

					else
					{
						trackData.put("message", "LIST_EMPTY");
						trackData.put("trackId", id.toString());
						this.mongoTemplate.save(this.trackReport);
						return trackData;
						// return "LIST_EMPTY";
					}

				}

				else if (businessHoursReport.equals("Holiday"))
				{
					trackData.put("message", "HOLI_DAY");
					trackData.put("trackId", id.toString());
					this.mongoTemplate.save(this.trackReport);
					return trackData;
					// return "HOLI_DAY";
				}

				else if (businessHoursReport.equals("NotWorkingHours"))
				{
					trackData.put("message", "NotWorkingHours");
					trackData.put("trackId", id.toString());
					this.mongoTemplate.save(this.trackReport);
					return trackData;
					// return "NotWorkingHours";
				}

				else if (businessHoursReport.equals("TimesMismatched"))
				{
					trackData.put("message", "TimesMismatched");
					trackData.put("trackId", id.toString());
					this.mongoTemplate.save(this.trackReport);
					return trackData;
					// return "TimesMismatched";
				}

				else
				{
					trackData.put("message", "INVALID_DETAILS");
					trackData.put("trackId", id.toString());
					this.mongoTemplate.save(this.trackReport);
					return trackData;
					// return "INVALID_DETAILS";
				}

			} // Check Business Data Valid

			else
			{
				trackData.put("message", "INVALID_DETAILS");
				trackData.put("trackId", id.toString());
				this.mongoTemplate.save(this.trackReport);
				return trackData;
				// return "INVALID_DETAILS";
			}
		}

		else
		{
			trackData.put("message", "INVALID_DETAILS");
			trackData.put("trackId", id.toString());
			this.mongoTemplate.save(this.trackReport);
			return trackData;
			// return "INVALID_DETAILS";
		}

	}

	/**
	 * To Check The Employee PTO for Particular Service
	 * 
	 * @param details
	 * 
	 * @param AppointmentBean
	 *            object
	 * @return
	 * @throws ParseException
	 */

	private List<PublisherBusinessEmployee> checkEmployeeServiceDetails(AppointmentBean appointBean,
	        List<Integer> details) throws ParseException
	{
		List<PublisherBusinessEmployee> empList = new ArrayList<>();
		String tmp = details.get(3).toString();
		ObjectId serviceId = new ObjectId(appointBean.getServiceId());
		Query query = new Query();
		query.addCriteria(Criteria.where("businessId").is(appointBean.getBusinessId()).and("publisherId")
		        .is(appointBean.getPublisherId())
		        .andOperator(Criteria.where("serviceCategory.service.id").is(serviceId).and("status").is(0)));

		List<PublisherBusinessEmployee> empServiceList = this.mongoTemplate.find(query,
		        PublisherBusinessEmployee.class);

		if (empServiceList != null)
		{
			for (PublisherBusinessEmployee emp : empServiceList)
			{
				if (emp.getEmployeeHours().get(tmp).getHoliday() == 0)
				{
					empList.add(emp);
				}
			}
		}

		return empList;
	}

	private List<Date> toConvertDateForPTO(AppointmentBean appointBean, List<Integer> details) throws ParseException
	{

		List<Date> date = new ArrayList<>();
		int syear = this.details.get(9);
		int smonthIn = this.details.get(10) + 1;
		int sday = this.details.get(11);
		int eday = sday + 1;

		String start = syear + "-" + smonthIn + "-" + sday + "T00:00:00.000+0000";

		String end = syear + "-" + smonthIn + "-" + eday + "T00:00:00.000+0000";

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		date.add(0, sdf.parse(start));
		date.add(1, sdf.parse(end));

		return date;
	}

	private Map<String, String> toCheckEmpAvailabilityAtThatTime(PublisherBusinessEmployee emp,
	        AppointmentBean appointBean, List<Date> date, List<Integer> details, List<AppointmentCalendar> empBreaks,
	        List<AppointmentCalendar> noServiceList, TrackReport tReport)
	{

		Map<String, String> trackData = new HashMap<>();

		List<Integer> empMinutes = new ArrayList<>();
		List<Integer> empAptMinutes = new ArrayList<>();
		List<Integer> empBrkMinutes = new ArrayList<>();
		List<Integer> tmpBrkMinutes = new ArrayList<>();

		List<Integer> empAvailMinutes = new ArrayList<>();
		List<Integer> newAptMinutes = new ArrayList<>();

		// Tracking Start for appointment Object
		// ObjectId id = new ObjectId();
		// this.trackReport.setId(id.toString());
		// this.trackReport.setCreatedTime(new Date());
		// this.trackReport.setRequest(appointBean);
		// Tracking Close

		if ((emp.getEmployeeHours().get(details.get(3).toString()).getOpen() <= details.get(4))
		        && (emp.getEmployeeHours().get(details.get(3).toString()).getClose() >= details.get(4)))
		{

			// Emp start to end Minutes
			for (int i = emp.getEmployeeHours().get(details.get(3).toString()).getOpen(); i <= emp.getEmployeeHours()
			        .get(details.get(3).toString()).getClose(); i++)
			{
				empMinutes.add(i);
			}

			// Emp No Service List
			for (int br = 0; br < noServiceList.size(); br++)
			{
				if (noServiceList.get(br).getEmployeeId().equals(emp.getId()))
				{

					for (int p = noServiceList.get(br).getStart(); p <= noServiceList.get(br).getEnd(); p++)
					{
						empAptMinutes.add(p);
					}
				}
			}

			// Emp Breaks

			if (empBreaks.size() > 0)
			{
				for (int br = 0; br < empBreaks.size(); br++)
				{
					if (empBreaks.get(br).getEmployeeId().equals(emp.getId()))
					{

						for (int p = empBreaks.get(br).getStart(); p <= empBreaks.get(br).getEnd(); p++)
						{
							empAptMinutes.add(p);
							empBrkMinutes.add(p);
						}
					}
				}
			}

			// logger.info("Break ----------" + empBrkMinutes);

			Query query = new Query();

			query.addCriteria(Criteria.where("employeeId").is(emp.getId()).and("status").in(0, 1, 2).andOperator(
			        Criteria.where("startScheduledTime").gte(date.get(0)).and("endScheduledTime").lt(date.get(1))));
			query.with(new Sort(new Order(Direction.ASC, "startScheduledTime")));

			List<AppointmentCalendar> appList = this.mongoTemplate.find(query, AppointmentCalendar.class);

			// Emp Booked Appointments
			for (int q = 0; q < appList.size(); q++)
			{

				for (int p = appList.get(q).getStart(); p <= appList.get(q).getEnd(); p++)
				{
					empAptMinutes.add(p);
				}

			}

			// logger.info("empAptMinutes " + empAptMinutes);

			empMinutes.removeAll(empAptMinutes);

			empAvailMinutes = empMinutes;

			// logger.info("empAvailMinutes " + empAvailMinutes);

			int start = details.get(0) * 60 + details.get(1);
			int end = details.get(5) * 60 + details.get(6);

			int count = end - start;

			// New Appointment Start, End Minutes

			for (int r = start; r <= end; r++)
			{

				newAptMinutes.add(r);
				tmpBrkMinutes.add(r);
			}

			// logger.info("newAptMinutes " + newAptMinutes);
			// logger.info("tmpBrkMinutes " + tmpBrkMinutes);

			tmpBrkMinutes.removeAll(empBrkMinutes);

			// logger.info("tmpBrkMinutes " + tmpBrkMinutes);

			newAptMinutes.removeAll(empAvailMinutes);

			// logger.info("newAptMinutes " + newAptMinutes);

			if (newAptMinutes.size() == 0)
			{

				trackData.put("message", "SUCCESS");
				return trackData;
			}

			else if (tmpBrkMinutes.size() < newAptMinutes.size())
			{

				trackData.put("message", "NO_FIT");
				trackData.put("trackId", tReport.getId());
				// Tracking Start for appointment Object NO_FIT
				this.mongoTemplate.save(tReport);
				// Tracking Close

				// return "NO_FIT";
				return trackData;
			}

			else if (tmpBrkMinutes.size() == 0)
			{
				trackData.put("message", "BREAK");
				trackData.put("trackId", tReport.getId());

				// Tracking Start for appointment Object BREAK
				this.mongoTemplate.save(tReport);
				// Tracking Close
				return trackData;
			}

			else if (newAptMinutes.size() < count)
			{
				trackData.put("message", "NO_FIT");
				trackData.put("trackId", tReport.getId());

				// Tracking Start for appointment Object NO_FIT
				this.mongoTemplate.save(tReport);
				// Tracking Close
				return trackData;
			}

			else
			{
				trackData.put("message", "ALL_BOOKED");
				trackData.put("trackId", tReport.getId());

				// Tracking Start for appointment Object ALL_BOOKED
				this.mongoTemplate.save(tReport);
				// Tracking Close
				return trackData;
			}

		}
		else
		{
			trackData.put("message", "NO_SERVICE");
			trackData.put("trackId", tReport.getId());

			// Tracking Start for appointment Object NO_SERVICE
			this.mongoTemplate.save(tReport);
			// Tracking Close
			return trackData;
		}

	}

	private List<PublisherBusinessEmployee> checkPtoDetails(List<PublisherBusinessEmployee> empServiceList,
	        List<Date> date, AppointmentBean appointBean) throws ParseException
	{

		List<PublisherBusinessEmployee> empPtoTemp = new ArrayList<>();

		for (int i = 0; i < empServiceList.size(); i++)
		{

			Query query = new Query();
			query.addCriteria(Criteria.where("empId").is(empServiceList.get(i).getId()).orOperator(
			        Criteria.where("pto.startDate").in(date.get(0)), Criteria.where("pto.endDate").in(date.get(0))));

			EmployeePto ptoCheck = this.mongoTemplate.findOne(query, EmployeePto.class);

			if ((ptoCheck == null))
			{
				// logger.info("AVAIL EMP---->" +
				// empServiceList.get(i).getId());

				Query query1 = new Query();

				query1.addCriteria(Criteria.where("empId").is(empServiceList.get(i).getId()));

				List<EmployeePto> ptoList = this.mongoTemplate.find(query1, EmployeePto.class);

				// logger.info("SIZE--->" + ptoList.size());

				if (ptoList.size() > 0)
				{
					int ps = 0;
					for (Pto p : ptoList.get(0).getPto())
					{
						if (p.getStartDate().compareTo(appointBean.getStartScheduledTime())
						        * appointBean.getStartScheduledTime().compareTo(p.getEndDate()) > 0)
						{
							ps = 1;
						}
					}

					if (ps != 1)
					{
						empPtoTemp.add(empServiceList.get(i));
					}
				}
				else
				{
					empPtoTemp.add(empServiceList.get(i));
				}
			}

		}

		return empPtoTemp;

	}

	// InCompleted
	public Object checkCalenderEntry(PublisherBusinessEmployee emp, AppointmentBean appointBean)
	{
		return appointBean;

	}

	public Map<String, String> saveAppointment(String empId, AppointmentBean appointBean, List<Integer> details,
	        PublisherBusiness pbData, TrackReport tReport) throws Exception
	{

		Map<String, String> trackData = new HashMap<>();

		int start = details.get(4);
		int end = details.get(8);

		int status = 0;
		Date dt = new java.util.Date();
		AppointmentCalendar appointment = new AppointmentCalendar();
		appointment.setBusinessId(appointBean.getBusinessId());
		appointment.setPublisherId(appointBean.getPublisherId());
		appointment.setServiceId(appointBean.getServiceId());
		appointment.setName(appointBean.getName());
		appointment.setEmail(appointBean.getEmail());
		appointment.setPhone(appointBean.getPhone());
		appointment.setStartScheduledTime(appointBean.getStartScheduledTime());
		appointment.setEndScheduledTime(appointBean.getEndScheduledTime());
		appointment.setEmployeeId(empId);
		appointment.setNumberOfPeople(1);
		appointment.setConsumerId(appointBean.getConsumerId());
		appointment.setStatus(status);
		appointment.setStart(start);
		appointment.setEnd(end);
		appointment.setCouponId(appointBean.getCouponId());
		appointment.setCreateDate(dt);
		appointment.setUpdateDate(dt);
		appointment.setPrice(appointBean.getPrice());
		appointment.setRenewalTime(appointBean.isRenewalTime());
		appointment.setServiceDuration(appointBean.getServiceDuration());
		appointment.setRenewalDays(appointBean.getRenewalDays());

		this.pubAppCal.save(appointment);

		// Tracking Start for appointment Object
		this.trackReport.setResult(appointment);
		this.mongoTemplate.save(tReport);
		// Tracking Close

		// for Sending notifications

		if (appointBean.getConsumerId() != null)
		{
			UserLoginDevices device = userService.getDeviceDetails(appointBean.getPublisherId());

			String date = toChangeDateToLocalFormat(appointBean.getStartScheduledTime().toString());

			if (device != null)
			{

				List<Messages> messageList = new ArrayList<>();
				List<String> tokenList = new ArrayList<>();
				List<String> serviceDetais = getServiceDetails(pbData, appointBean.getServiceId());

				String message = pbData.getName() + ": Appointment got scheduled for " + serviceDetais.get(0) + " at "
				        + date + ".";
				String title = "Appointment Created";

				if (device.getDevices().size() > 0)
				{
					for (int i = 0; i < device.getDevices().size(); i++)
					{
						Messages msg = new Messages();
						msg.setMessage(message);
						msg.setTitle(title);
						msg.setType(0);
						msg.setFrom(appointBean.getName());
						msg.setTo(pbData.getName());
						msg.setCreatedTime(dt);
						msg.setuId(appointBean.getConsumerId());
						msg.setbId(pbData.getId());
						msg.setReceiverID(pbData.getPublisherId());
						tokenList.add(device.getDevices().get(i).getToken());
						messageList.add(msg);
					}
				}

				if ((tokenList != null) && !(tokenList.isEmpty()))
				{

					fcm.sendNotification(tokenList, messageList, 0);

				}
			}
		}

		trackData.put("message", "SUCCESS");
		trackData.put("trackId", tReport.getId());

		return trackData;

	}

	public String toChangeDateToLocalFormat(String date) throws ParseException
	{
		// DateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
		// utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date d = formatter.parse(date);
		DateFormat f2 = new SimpleDateFormat("dd/MM/yyyy h:mma");

		return f2.format(d).toLowerCase();
	}

	/**
	 * @param PublisherBusinessEmployee
	 *            Object
	 * @param AppointmentBean
	 *            Object
	 * 
	 * 
	 * @return
	 */
	public List<AppointmentCalendar> checkInCalendorEntry(PublisherBusinessEmployee employee,
	        AppointmentBean appointBean)
	{

		MatchOperation matchStage = Aggregation.match(Criteria.where("employeeId").is(employee.getId())
		        .andOperator(Criteria.where("startScheduledTime").is(appointBean.getStartScheduledTime())
		                .and("endScheduledTime").is(appointBean.getEndScheduledTime()).and("status").in(0, 1)));

		ProjectionOperation projectStage2 = Aggregation.project("id");

		Aggregation aggregation = Aggregation.newAggregation(matchStage, projectStage2);

		AggregationResults<AppointmentCalendar> result = this.mongoTemplate.aggregate(aggregation,
		        "appointmentCalender", AppointmentCalendar.class);

		List<AppointmentCalendar> calendarList = result.getMappedResults();

		return calendarList;

	}

	/**
	 * 
	 * To Check The Business Hours
	 * 
	 * @param details
	 * @param businessDetails
	 * 
	 * @param AppointmentBean
	 * @return
	 * @throws ParseException
	 */
	private String checkBusinessHours(AppointmentBean appointBean, List<Integer> details,
	        PublisherBusiness businessDetails) throws ParseException
	{
		// To Compare the Dates
		// flag=1 OK
		// flag=0 StartDates lesser than EndDate

		String flag = DateCompare(appointBean, details);

		if (flag.equals("1"))
		{

			if (businessDetails != null)
			{

				// Check the given day is working day or Holiday ?
				if (businessDetails.getBusinessHours().get(details.get(3).toString()).getHoliday() == 0)
				{

					// Check End Time greater than Start Time
					if ((details.get(8) > details.get(4)))
					{

						// Check Working Hours
						if ((businessDetails.getBusinessHours().get(details.get(3).toString()).getOpen() <= details
						        .get(4))
						        && (businessDetails.getBusinessHours().get(details.get(3).toString())
						                .getClose() >= details.get(8)))
						{
							return "WorkingDay";
						}

						else
						{

							details.add(businessDetails.getBusinessHours().get(details.get(3).toString()).getOpen());
							details.add(businessDetails.getBusinessHours().get(details.get(3).toString()).getClose());
							return "NotWorkingHours";
						}

					} // Check End Time greater than Start Time close

					else
					{
						return "TimesMismatched";
					}

				} // Check the given day is working day or Holiday close

				else
				{
					// day is Holiday
					return "Holiday";
				}

			} // if business Data != null close

			else
			{
				return "Empty";
			} // else business Data = null close

		} // if flag close

		else
		{
			return "TimesMismatched";
		} // else flag close

	}

	public List<Integer> getAppointmentDetails(AppointmentBean appointBean)
	{
		Date openScheduledTime = appointBean.getStartScheduledTime();

		Date endScheduledTime = appointBean.getEndScheduledTime();

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(openScheduledTime);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(endScheduledTime);

		this.details.add(0, calendar.get(Calendar.HOUR_OF_DAY));
		this.details.add(1, calendar.get(Calendar.MINUTE));
		this.details.add(2, calendar.get(Calendar.SECOND));
		this.details.add(3, calendar.get(Calendar.DAY_OF_WEEK));

		this.details.add(4, this.details.get(0) * 60 + this.details.get(1));

		this.details.add(5, calendar2.get(Calendar.HOUR_OF_DAY));
		this.details.add(6, calendar2.get(Calendar.MINUTE));
		this.details.add(7, calendar2.get(Calendar.SECOND));

		this.details.add(8, this.details.get(5) * 60 + this.details.get(6));

		this.details.add(9, calendar.get(Calendar.YEAR));
		this.details.add(10, calendar.get(Calendar.MONTH));
		this.details.add(11, calendar.get(Calendar.DAY_OF_MONTH));

		this.details.add(12, calendar2.get(Calendar.YEAR));
		this.details.add(13, calendar2.get(Calendar.MONTH));
		this.details.add(14, calendar2.get(Calendar.DAY_OF_MONTH));

		return this.details;

	}

	private String DateCompare(AppointmentBean appointBean, List<Integer> details) throws ParseException
	{
		// List<Integer> details = getAppointmentDetails(appointBean);
		int syear = details.get(9);
		int smonthIn = details.get(10) + 1;
		int sday = details.get(11);

		int eyear = details.get(12);
		int emonthIn = details.get(13) + 1;
		int eday = details.get(14);

		String end = eyear + "-" + emonthIn + "-" + eday;
		String start = syear + "-" + smonthIn + "-" + sday;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		String t = compareDatesByCompareTo(formatter, formatter.parse(start), formatter.parse(end));

		return t;
	}

	public static String compareDatesByCompareTo(DateFormat df, Date oldDate, Date newDate)
	{

		String flag = null;

		// how to check if date1 is equal to date2
		if (oldDate.compareTo(newDate) == 0)
		{
			flag = "1";
		}

		// checking if date1 is less than date 2
		if (oldDate.compareTo(newDate) < 0)
		{
			flag = "1";
		}

		// how to check if date1 is greater than date2 in java
		if (oldDate.compareTo(newDate) > 0)
		{
			flag = "0";
		}
		return flag;
	}

	public String removeEmployeeTimeOff(EmployeePto removePto)
	{
		String report = "UnSuccess";

		if ((removePto.getEmpId() != null))
		{

			ObjectId id = new ObjectId(removePto.getId());

			Query query = new Query();
			query.addCriteria(Criteria.where("empId").is(removePto.getEmpId()).and("pto.id").is(id));
			EmployeePto pubEmpData = this.mongoTemplate.findOne(query, EmployeePto.class);

			if (pubEmpData != null)
			{
				System.out.println("REmove PTO" + pubEmpData.getEmpId());
				report = removeService(removePto);
			}
		}

		return report;
	}

	private String removeService(EmployeePto removePto)
	{
		String s;
		ObjectId id = new ObjectId(removePto.getId());

		Query query = Query.query(Criteria.where("empId").is(removePto.getEmpId()));

		Update update = new Update().pull("pto", new BasicDBObject("id", id));

		WriteResult pB = this.mongoTemplate.updateFirst(query, update, EmployeePto.class);

		if (pB.getN() == 1)
		{
			s = "Success";
		}
		else
		{
			s = "UnSuccess";
		}

		return s;
	}

	public EmployeePto EmployeeTimeOffList(String empId)
	{
		Query listQry = new Query();

		listQry.addCriteria(Criteria.where("empId").is(empId));
		listQry.fields().include("empId");
		listQry.fields().include("pto");
		return this.mongoTemplate.findOne(listQry, EmployeePto.class);
	}

	public List<Services> publisherBusinessServiceListByEmpId(String empId)
	{

		List<Services> serList = new ArrayList<>();
		Services serv;

		PublisherBusinessEmployee emp;
		if ((empId != null))
		{

			emp = getEmpDeatils(empId);
			PublisherBusiness pbData = pubService.getPublisherBusinessData(emp.getBusinessId());

			if (emp != null)
			{
				emp = addServiceNaming(emp);

				for (int i = 0; i < emp.getServiceCategory().size(); i++)
				{
					for (int j = 0; j < emp.getServiceCategory().get(i).getService().size(); j++)
					{
						serv = new Services();

						serv.setServiceId(emp.getServiceCategory().get(i).getService().get(j).getId());
						serv.setServiceName(emp.getServiceCategory().get(i).getService().get(j).getName());
						serv.setDescription(emp.getServiceCategory().get(i).getService().get(j).getDescription());

						serv.setDuration(emp.getServiceCategory().get(i).getService().get(j).getDuration());
						serv.setPrice(emp.getServiceCategory().get(i).getService().get(j).getPrice());
						for (int k = 0; k < pbData.getServiceCategory().size(); k++)
						{
							if (emp.getServiceCategory().get(i).getId()
							        .equals(pbData.getServiceCategory().get(k).getId()))
							{
								for (int k1 = 0; k1 < pbData.getServiceCategory().get(k).getService().size(); k1++)
								{
									if (emp.getServiceCategory().get(i).getService().get(j).getId()
									        .equals(pbData.getServiceCategory().get(k).getService().get(k1).getId()))
									{
										serv.setRenewalTime(pbData.getServiceCategory().get(k).getService().get(k1)
										        .getRenewalTime());
									}
								}
							}

						}
						serList.add(serv);
					}

				}

			}

			return serList;
		}

		else
		{
			return null;
		}

	}

	private PublisherBusinessEmployee getEmpDeatils(String empId)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(empId));
		long count = this.mongoTemplate.count(query, PublisherBusinessEmployee.class);

		if (count > 0)
		{

			return this.mongoTemplate.findOne(query, PublisherBusinessEmployee.class);
		}

		else
		{
			return null;
		}

	}

	public String updateStatus(AppointmentCalendar updateStatus) throws Exception
	{

		if ((updateStatus.getId() != null) && (updateStatus.getStatus() != -1))
		{

			AppointmentCalendar appData = null;

			Query query = new Query(Criteria.where("id").is(updateStatus.getId()));

			appData = this.mongoTemplate.findOne(query, AppointmentCalendar.class);

			if (appData != null)
			{

				Update update = new Update();

				if (updateStatus.getStatus() != -1)
				{
					update.set("status", updateStatus.getStatus());
				}

				update.set("updateDate", new java.util.Date());

				this.mongoTemplate.findAndModify(query, update, AppointmentCalendar.class);

				Date dateNow = new Date();
				String date = toChangeDateToLocalFormat(appData.getStartScheduledTime().toString());
				PublisherBusiness pbData = getBusinessDetails(appData.getBusinessId(), appData.getPublisherId());
				List<String> serviceDetais = getServiceDetails(pbData, appData.getServiceId());

				String message = null;
				String msgInitial = null;
				String title = null;
				User sender = userService.getUserById(updateStatus.getuId());
				int type = 0;
				User receiver = null;
				List<Messages> messageList = new ArrayList<>();
				List<String> tokenList = new ArrayList<>();
				if (updateStatus.getStatus() == 3)
				{

					message = null;
					title = "Appointment Cancled";
					msgInitial = ": Appointment got canceled for ";

					Messages msg = new Messages();
					msg.setTitle(title);
					msg.setType(0);
					msg.setCreatedTime(dateNow);

					// Cancle appoinememt by Publisher
					if (sender.getType() == 2)
					{
						logger.info("Cancle appoinememt by Publisher");
						if (appData.getConsumerId() != null)
						{
							receiver = userService.getUserById(appData.getConsumerId());

							if (receiver.getToken() != null)
							{

								logger.info("receiver -----" + receiver.getToken());

								type = 1;
								message = pbData.getName() + msgInitial + serviceDetais.get(0) + " at " + date + ".";
								msg.setuId(pbData.getPublisherId());
								msg.setbId(pbData.getId());
								msg.setReceiverID(appData.getConsumerId());
								msg.setMessage(message);
								msg.setFrom(pbData.getName());
								msg.setTo(appData.getName());
								tokenList.add(receiver.getToken());
								messageList.add(msg);

								fcm.sendNotification(tokenList, messageList, type);

							}
						}

					}

					else if (sender.getType() == 3) // Cancle appoinememt by Consumer
					{

						UserLoginDevices device = userService.getDeviceDetails(appData.getPublisherId());

						if (device != null)
						{

							message = pbData.getName() + msgInitial + serviceDetais.get(0) + " at " + date + " from "
							        + appData.getName() + "," + appData.getPhone();
							msg.setuId(appData.getConsumerId());
							msg.setbId(pbData.getId());
							msg.setReceiverID(pbData.getPublisherId());
							msg.setMessage(message);
							msg.setFrom(appData.getName());
							msg.setTo(pbData.getName());

							if (device.getDevices().size() > 0)
							{
								for (int i = 0; i < device.getDevices().size(); i++)
								{

									tokenList.add(device.getDevices().get(i).getToken());
									messageList.add(msg);
								}
							}

							if ((tokenList != null) && !(tokenList.isEmpty()))
							{

								fcm.sendNotification(tokenList, messageList, 0);

							}

						}

					}

				}

				// Appointment got performed
				else if (updateStatus.getStatus() == 2)
				{

					title = "Appointment Performed";
					msgInitial = ": Appointment successfully performed for ";

					if (sender.getType() == 2)
					{
						if (appData.getConsumerId() != null)
						{
							receiver = userService.getUserById(appData.getConsumerId());

							if (receiver.getToken() != null)
							{

								Messages msg = new Messages();

								type = 1;
								message = pbData.getName() + msgInitial + serviceDetais.get(0) + " at " + date
								        + ". Thank you, visit again";
								msg.setCreatedTime(dateNow);
								msg.setuId(pbData.getPublisherId());
								msg.setbId(pbData.getId());
								msg.setReceiverID(appData.getConsumerId());
								msg.setMessage(message);
								msg.setFrom(pbData.getName());
								msg.setTo(appData.getName());
								msg.setTitle(title);

								tokenList.add(receiver.getToken());
								messageList.add(msg);

								fcm.sendNotification(tokenList, messageList, type);

								if ((appData.isRenewalTime() == true) && (appData.getRenewalDays()) > 0)
								{
									// Renewal Appoinemt
									renewalAppointment(appData);
								}

							}
						}

					}

				}

				return "Success";

			}

			else

			{
				return "INVALID";
			}
		}

		else

		{

			return "INVALID";
		}

	}

	private void renewalAppointment(AppointmentCalendar appData) throws Exception
	{
		String appType = "RENEWAL";

		List<Date> renewalDates = toPrepareAppStartAndEndDate(appData.getStartScheduledTime(),
		        appData.getEndScheduledTime(), appData.getRenewalDays());

		appBean.setBusinessId(appData.getBusinessId());
		appBean.setPublisherId(appData.getPublisherId());
		appBean.setServiceId(appData.getServiceId());
		appBean.setServiceId(appData.getServiceId());
		appBean.setConsumerId(appData.getConsumerId());
		appBean.setEmail(appData.getEmail());
		appBean.setName(appData.getName());
		appBean.setServiceDuration(appData.getServiceDuration());
		appBean.setPhone(appData.getPhone());
		appBean.setPrice(appData.getPrice());
		appBean.setStartScheduledTime(renewalDates.get(0));
		appBean.setEndScheduledTime(renewalDates.get(1));

		Map<String, String> result = createAppointment(appBean, appType);

		if (result.containsKey("message"))
		{
			if ("HOLI_DAY".equals(result.get("message")))
			{
				List<Date> renewalDates_H = toPrepareAppStartAndEndDate(appData.getStartScheduledTime(),
				        appData.getEndScheduledTime(), appData.getRenewalDays() + 1);
				appBean.setStartScheduledTime(renewalDates_H.get(0));
				appBean.setEndScheduledTime(renewalDates_H.get(1));
				createAppointment(appBean, appType);
			}
		}

		// logger.info("Renewal Appointment --------------------" + result);

	}

	public List<Date> toPrepareAppStartAndEndDate(Date sDate, Date eDate, int renewalDays)
	{
		List<Date> renewalDates = new ArrayList<>();

		Date previousStartDate = sDate;

		Date previousEndDate = eDate;

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(previousStartDate);
		calendar.add(Calendar.DATE, renewalDays);
		Date startDate = calendar.getTime();

		// logger.info("previousStartDate-------------" + previousStartDate);
		// logger.info("startDate --------------------" + startDate);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(previousEndDate);
		calendar2.add(Calendar.DATE, renewalDays);
		Date endDate = calendar2.getTime();

		// logger.info("previousEndDate-------------" + previousEndDate);
		// logger.info("EndDate --------------------" + endDate);

		DateFormat formatterUTC = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		formatterUTC.setTimeZone(TimeZone.getTimeZone("UTC")); // UTC timezone

		// logger.info("startDate UTC --------------------" +
		// formatterUTC.format(renewalDates.get(0)));
		// logger.info("EndDate UTC --------------------" +
		// formatterUTC.format(renewalDates.get(1)));

		renewalDates.add(0, startDate);
		renewalDates.add(1, endDate);

		return renewalDates;

	}

	public void sendNotificationToPublisher(PublisherBusiness pbData, String serviceName)
	{

	}

	public List<AppointmentCalendar> consumerAppoinmentList(String macId)
	{

		// First checked Consumer Business Details
		ConsumerBusinessDetails tmp = this.userService.getConsumerBusinessDetails(macId);

		if (tmp != null)
		{

			Query query = new Query();
			query.fields().exclude("createDate");
			query.fields().exclude("updateDate");
			query.fields().exclude("uId");
			query.fields().exclude("colour");
			query.fields().exclude("couponId");
			query.fields().exclude("start");
			query.fields().exclude("end");
			query.fields().exclude("start");

			query.addCriteria(
			        Criteria.where("consumerId").is(tmp.getId()).andOperator(Criteria.where("status").nin(3, 4)));

			query.with(new Sort(new Order(Direction.DESC, "startScheduledTime")));

			List<AppointmentCalendar> appointmentData = this.mongoTemplate.find(query, AppointmentCalendar.class);

			for (int i = 0; i < appointmentData.size(); i++)
			{
				PublisherBusiness pbData = getBusinessDetails(appointmentData.get(i).getBusinessId(),
				        appointmentData.get(i).getPublisherId());

				appointmentData.get(i).setIcon(pbData.getIcon());
				logger.info("icno----" + pbData.getIcon());

				if ((getServiceDetails(pbData, appointmentData.get(i).getServiceId()).get(0) != null)
				        && (getServiceDetails(pbData, appointmentData.get(i).getServiceId()).size() > 0))
				{
					appointmentData.get(i)
					        .setServiceName(getServiceDetails(pbData, appointmentData.get(i).getServiceId()).get(0));
				}

			}

			return appointmentData;
		}

		else
		{
			return null;
		}

	}

	public List<String> getServiceDetails(PublisherBusiness pbData, String serviceId)
	{

		List<String> serviceDetails = new ArrayList<>();

		for (int i = 0; i < pbData.getServiceCategory().size(); i++)
		{

			for (int j = 0; j < pbData.getServiceCategory().get(i).getService().size(); j++)
			{

				if (pbData.getServiceCategory().get(i).getService().get(j).getId().equals(serviceId))
				{

					serviceDetails.add(pbData.getServiceCategory().get(i).getService().get(j).getName());

					serviceDetails.add(
					        Integer.toString(pbData.getServiceCategory().get(i).getService().get(j).getDuration()));

				}
			}
		}

		return serviceDetails;
	}

	public String saveIcon(PublisherBusinessEmployee pBEmp)
	{

		if (pBEmp != null)
		{
			Query updQry = new Query(Criteria.where("id").is(pBEmp.getId()));
			Update upd = new Update();

			if (pBEmp.getIcon() != null)
			{
				upd.set("icon", pBEmp.getIcon());
			}

			if (pBEmp.getUpdatedTime() == null)
			{
				Date date = new Date();

				upd.set("updatedTime", date);
			}

			this.mongoTemplate.upsert(updQry, upd, PublisherBusinessEmployee.class);

			return "SUCCESS";

		}

		else
		{

			return "UNSUCCESS";
		}
	}

	public String getIcon(String empId)
	{
		PublisherBusinessEmployee emp = getEmpDeatils(empId);
		if (emp != null)
		{

			return emp.getIcon();
		}

		else
		{
			return "INVALID";
		}
	}

	public void deleteAppointments(List<AppointmentCalendar> appData)
	{

		// List<AppointmentCalendar> appData = getAppointmentByPubId_ServId(busData);

		if (appData.size() > 0)
		{
			for (int i = 0; i < appData.size(); i++)
			{
				Query query2 = new Query();
				query2.addCriteria(Criteria.where("id").is(appData.get(i).getId()));
				Update upd = new Update();
				upd.set("status", 4);
				this.mongoTemplate.upsert(query2, upd, AppointmentCalendar.class);
			}

		}

	}

	public List<AppointmentCalendar> getAppointmentByPubId_ServId(PublisherBusinessServices busData)
	{

		Query query = new Query();

		if (busData.getServiceId() != null)
		{

			query.addCriteria(Criteria.where("serviceId").is(busData.getServiceId().toString())
			        .andOperator(Criteria.where("businessId").is(busData.getPublisherBusinessId().toString())));

		}

		else
		{

			query.addCriteria(Criteria.where("businessId").is(busData.getPublisherBusinessId()));
		}

		return this.mongoTemplate.find(query, AppointmentCalendar.class);
	}

	public List<AppointmentCalendar> getAppoinmentForSeletedDates(String empId, List<Date> dates) throws ParseException
	{

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dates.get(0));

		int sYear = calendar.get(Calendar.YEAR);
		int sMonthIn = 1 + calendar.get(Calendar.MONTH);
		int sDay = calendar.get(Calendar.DAY_OF_MONTH);

		Calendar calendar2 = Calendar.getInstance();
		calendar2.setTime(dates.get(1));

		int eYear = calendar2.get(Calendar.YEAR);
		int eMonthIn = 1 + calendar2.get(Calendar.MONTH);
		int eday = calendar2.get(Calendar.DAY_OF_MONTH);
		eday = eday + 1;

		String start = sYear + "-" + sMonthIn + "-" + sDay + "T00:00:00.000+0000";

		String end = eYear + "-" + eMonthIn + "-" + eday + "T00:00:00.000+0000";

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date sDate = sdf.parse(start);
		Date eDate = sdf.parse(end);

		Query query = new Query();

		query.addCriteria(Criteria.where("startScheduledTime").gte(sDate).and("endScheduledTime").lt(eDate)
		        .andOperator(Criteria.where("status").is(0)).and("employeeId").is(empId));
		query.with(new Sort(new Order(Direction.ASC, "startScheduledTime")));
		return this.mongoTemplate.find(query, AppointmentCalendar.class);

	}

}
